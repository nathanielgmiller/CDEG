(*  CDEG -- Computerized Diagramatic Euclidean Geometry  *)
(*                       Nat Miller                      *)
(*                  started January 1999                 *)
(*               Version 2.0b2 , August 2011              *)
(*            Copyright 2011 Nathaniel Miller.           *)
(*            Contact: nat@alumni.princeton.edu          *)

(*
    This file is part of CDEG.

    CDEG is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    CDEG is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with CDEG.  If not, see <http://www.gnu.org/licenses/>.
*)

(*********************)
(* General apparatus *)
(*********************)

(* list operations *)

exception Dummy;;
exception EmptyList;;
exception BadInputList;;
exception BadInput;;

let pi1((first,second)) = first;;
let pi2((first,second)) = second;;


let append(list1,list2) = list1@list2;;

let double(list) = list@list;;

let triple(list) = list@list@list;;

let firstelt(list) =
  match list with
      first::rest -> first 
    |_ -> raise EmptyList;;
	
let secondelt(list) =
  match list with
      first::second::rest -> second 
    |_ -> raise BadInputList;;

let cdr(list) =
  match list with
      first::rest -> rest
    | _ -> raise EmptyList;;

let rec lastelt(list) =
  match list with
      elt::[] -> elt
    | first :: rest -> lastelt(rest)
    | _ -> raise EmptyList;;

let rec remove_last_elt(list) = 
  match list with
      elt:: [] -> []
    | first :: rest -> first::remove_last_elt(rest)
    | _ -> raise EmptyList;;

let rec replace_nth_elt(list,n,replist) = 
  match list with
      first::rest ->   
	if n = 1 
	then append(replist,rest)
	else first::replace_nth_elt(rest,n-1,replist)
    | _ -> raise BadInputList;;

let striplist(list) = cdr(remove_last_elt(list));;


let rec lasttwoelts(list) =
  match list with
      one::two::[] -> (one,two)
    | first::rest -> lasttwoelts(rest)
    | _ -> raise BadInputList;; (* this should never happen  *)

let rec getelt(i,list) =
  match list with
      first::rest -> 
	if i=1 then first else getelt(i-1,rest)
    | _ -> raise BadInputList;;


let rec inlist(elt, list) = 
  match list with
      first:: rest -> if first = elt then true else inlist(elt,rest)
    | [] -> false;;

let rec sub_in_list(oldelt,newelt,list) = 
  match list with
      first::rest -> 
	if first = oldelt 
	then newelt::sub_in_list(oldelt,newelt,rest)
	else first ::sub_in_list(oldelt,newelt,rest)
    | _ -> [];; 

let rec doublesub(oldelt1,oldelt2,newelt1,newelt2,list) = 
  match list with
      first::rest when first = oldelt1 -> 
	newelt1::doublesub(oldelt1,oldelt2,newelt1,newelt2,rest)
    | first::rest when first = oldelt2 ->	
	newelt2::doublesub(oldelt1,oldelt2,newelt1,newelt2,rest)
    | first::rest ->
	first ::doublesub(oldelt1,oldelt2,newelt1,newelt2,rest)
    | _ -> [];; 

let rec replaceinlist(list, elt, insertlist) = 
  match list with
      first::rest when (first = elt) -> 
	append(insertlist,replaceinlist(rest,elt,insertlist))
	  (*changed to replace all occurances to fix add dot to seg *)
    | first::rest -> first::replaceinlist(rest,elt,insertlist)
    | _ -> [];; 
	
let rec doublereplaceinlist(list, elt1, insertlist1,elt2,insertlist2) = 
  match list with
      first::rest when (first = elt1) -> 
		append(insertlist1,doublereplaceinlist(rest,elt1,insertlist1,elt2,insertlist2))
	|  first::rest when (first = elt2) -> 
		append(insertlist2,doublereplaceinlist(rest,elt1,insertlist1,elt2,insertlist2))
    | first::rest -> first::doublereplaceinlist(rest,elt1,insertlist1,elt2,insertlist2)
    | _ -> [];; 

(* replace3inlist replaces the given 3 elements when they occur in the given order or
    in the reversed order in the list.  *)
let rec replace3inlist(list, elt1, elt2, elt3, newelt) =
	match list with
		first::second::third::rest when first = elt1 & second = elt2 & third = elt3 ->
			newelt::replace3inlist(rest, elt1, elt2, elt3, newelt)
		| first::second::third::rest when first = elt3 & second = elt2 & third = elt1 ->
			newelt::replace3inlist(rest, elt1, elt2, elt3, newelt)
		| first:: rest ->
			first :: replace3inlist(rest, elt1, elt2, elt3, newelt)
		| [] -> [];;

let removefromlist(list,elt) = 
  replaceinlist(list,elt,[]);;

let rec precedesinlist(elt, list) = 
  match list with
      first:: second :: rest when second = elt -> first 
    | first :: rest -> precedesinlist(elt,rest)
    | _ -> raise BadInputList;;

let circular_precedesinlist(elt, list) = 
  let last = lastelt(list) in
  let newlist = last::list in
    precedesinlist(elt,newlist);;

(* circular_precedesinlist and follows in list are written to find the *)
(* instance of elt in the list. *)

let rec followsinlist(elt, list) = 
  match list with
      first:: second :: rest when first = elt -> second 
    | first :: rest -> followsinlist(elt,rest)
    | _ -> raise BadInputList;;

let circular_followsinlist(elt, list) = 
  let first = firstelt(list) in
  let newlist = append(list,[first]) in
    followsinlist(elt,newlist);;


let rec circ_occurs(first,second,third,list) =
  match list with
      firstl::secondl::thirdl::rest ->
	rec_circ_occurs(first,second,third,firstl,secondl,list)
    | _ -> false
and rec_circ_occurs(first,second,third,origfirst,origsecond,list)=
  match list with
      firstl::secondl::thirdl::rest ->
	if (firstl = first) & (secondl = second) & (thirdl=third)
	then true
	else rec_circ_occurs(first,second,third,origfirst,origsecond,
			    secondl::thirdl::rest)
    |firstl::secondl::[] ->
	if (((firstl = first) & (secondl = second) & (origfirst=third)) or
	    ((secondl=first) & (origfirst = second) & (origsecond=third)))
	then true
	else false
    | _ -> false;; (*shouldn't happen *)
	
	
	
(* between_in_list finds all elts from elt1 to elt2, including
    elt1 but not elt2 in the list.  If elt2 occurs before elt1 in list,
	we reverse the list order. *)
let rec between_in_list(list, elt1, elt2) =
	match list with
	first::rest when first = elt1 ->
		rec2_between_in_list([first],rest,elt2)
	| first::rest when first = elt2 ->
		between_in_list(List.rev list,elt1,elt2)
	| first::rest -> 
		between_in_list(rest, elt1,elt2)
	| _ -> raise BadInputList
and rec2_between_in_list(output_list, input_list, elt2) =
	match input_list with
	first::rest when first = elt2 -> output_list
	| first::rest -> rec2_between_in_list(append(output_list,[first]),rest, elt2)
	| _ -> raise BadInputList;;

let cons1(elt,pair) =
  match pair with
      (list1,list2) -> (elt::list1,list2);;

let firstcomp(pair) =
  match pair with
      (elt1,elt2) -> elt1;;

let secondcomp(pair) =
  match pair with
      (elt1,elt2) -> elt2;;
	  
let listofone(list) =
	match list with
		  first::[] -> true
		  |_ -> false;;


(* set operations *)
type 'a set = 'a list;;
let emptyset: 'a set = [];;
let setadjoin(elt,set) : 'a set = elt :: set;;

let rec setremove(elt,set) = 
  match set with
      first:: rest when first = elt -> setremove(elt,rest)
    | first:: rest -> first :: setremove(elt,rest)
    | _ -> [];;
let setunion(set1,set2) = append(set1,set2);;

let rec inset(elt, set) = 
  match set with
      first:: rest -> if first = elt then true else inset(elt,rest)
    | [] -> false;;

let fancysetadjoin(elt,set) = 
  if inset(elt,set) then set else setadjoin(elt,set);;

let rec fancysetunion(set1,set2) = 
  match set1 with 
      [] -> set2
    | first::rest -> fancysetunion(rest,fancysetadjoin(first,set2));;
	
let rec setdifference(smallset, bigset) =
	match bigset with
		  first::rest when inset(first,smallset) ->
			setdifference(smallset,rest)
		| first::rest -> first::setdifference(smallset, rest)
		| [] -> [];;

let rec disjoint(set1, set2) = 
  match set2 with
      first:: rest -> if inset(first, set1) then false else disjoint(set1, rest)
    | [] -> true;;

let rec subset(set1, set2) = 
  match set1 with
      first::rest -> if inset(first, set2) then subset(rest, set2) else false
    | [] -> true;;

let propersubset(set1, set2) = 
  (subset(set1, set2) & (not (subset(set2,set1))));;

let rec replaceinlistset(elt,list,set) =
  match set with
      first::rest -> 
	replaceinlist(first, elt,list)::replaceinlistset(elt,list,rest)
    | _ -> [];;
	
let equal_sets(set1, set2) =
	subset(set1,set2) && subset(set2,set1);;

let rec setofsets_inset(elt, set) = 
  match set with
      first:: rest -> if equal_sets(first, elt) then true else setofsets_inset(elt,rest)
    | [] -> false;;
	
let rec setofsets_disjoint(set1,set2) =
  match set2 with
      first:: rest -> 
		if setofsets_inset(first, set1) then false else setofsets_disjoint(set1, rest)
    | [] -> true;;
	
	
(* uniquesetintersection finds the first element of set1 that is also
in set2.  This is the intersection of the 2 sets if they only have one
element in common.*)
let rec uniquesetintersection(set1,set2) =
	match set1 with
		  first::rest when inset(first,set2) ->
			first
		| first::rest -> uniquesetintersection(rest,set2)
		| [] -> raise BadInput;;

(* splitin3 splits a list into three pieces around elt1 and elt2,
which go in the middle list.*)
let rec splitin3(list,elt1,elt2) =
	split3_1(list,elt1,elt2,[])
and split3_1(list,elt1,elt2,output1) =
	match list with
		  first::rest when first =elt1 ->
			split3_2(rest,elt2,output1,[first])
		| first::rest when first = elt2 ->
			split3_2(rest,elt1,output1,[first])
		| first::rest ->
			split3_1(rest,elt1,elt2,append(output1, [first]))
		| [] -> raise BadInput
and split3_2(list,elt,output1,output2)=
	match list with
		  first::rest when first = elt ->
			(output1,append(output2, [first]),rest)
		| first::rest ->
			split3_2(rest,elt,output1,append(output2, [first]))
		| _ -> raise BadInput;;


(* functions and counters *)
let extendfunction(f, elt, value) =
  function x -> if x = elt then value else f(x);;
	
exception TooManyObjects;;
let max_elts_in_universe = 300000;;
let initial_hashsize = 10000;;
let small_hashsize = 100;;

let countervalue = ref 1;;
let counter() = 
  countervalue := !countervalue + 1;
  !countervalue;;
(* counter() returns a new value each time it is called *)	

let displayname_countervalue = ref 0;;
let dn_counter() = 
  displayname_countervalue := !displayname_countervalue + 1;
  !displayname_countervalue;;

(* logic *)
let not(tv) =
	if tv then false else true;;

(* colors *)
type color = int;;

let black = 0x000000;;
let white = 0xFFFFFF;;
let green = 0x00EE00;;
let purple = 0xA020F0;;
let red = 0xFF0000;;
let blue = 0x0000CD;;
let orange = 0xFF8C00;;
let light_blue = 0xFFFF;;
let brown = 0xA0522D;;
let pink = 0xFF00FF;;
let teal = 0x0CB3A0;;
let sky_blue = 0x6495ED;;
let charcoal = 0x737373;;
let dark_gray = 0xB3B3B3;;
let yellow = 0xFFFF00;;

let randomcolor() =
  let r = Random.int(256) in
  let g = Random.int(256) in
  let b = Random.int(256) in
    b + 256*g + 256*256*r;;

let lookup_color(i) =
  match i with  
      j when j = 1 -> green
    | j when j = 2 -> purple
    | j when j = 3 -> red
    | j when j = 4 -> teal
    | j when j = 5 -> pink
    | j when j = 6 -> light_blue
    | j when j = 7 -> sky_blue
    | j when j = 8 -> orange
    | j when j = 9 -> brown
    | j when j = 10 -> blue
    | j when j = 11 -> charcoal
    | j when j = 12 -> dark_gray
    | _ -> randomcolor();;

let color_countervalue = ref 0;;
let color_counter() = 
  color_countervalue := !color_countervalue + 1;
  lookup_color(!color_countervalue);;
let reset_color_counter() =
  (color_countervalue := 0;
   () );;
	
let output_color(out,color) =
  Printf.fprintf out "#%X" color;;

let output_color_line(out,color) =
  output_string out "      fill \"";
  output_color(out,color);
  output_string out "\"  \n";;

let color_array = Hashtbl.create small_hashsize;;
Hashtbl.add color_array 0 black;;

let array_lookup_color index=
	if Hashtbl.mem color_array index 
	then Hashtbl.find color_array index
	else 
		(let newcolor = color_counter() in
		Hashtbl.add color_array index newcolor;
		newcolor);;

(*******************************)	
(* Basic diagram element types *)
(*******************************)	

exception BadInput;;
exception BadIncList;;

type dotpos = Interior | OnFrame;;
type dot = {dname:string; dnum:int ; dpos:dotpos};;

let isframedot(dot) =
  match dot.dpos with
      Interior -> false
    | OnFrame -> true;;

type style = Solid | Dotted | Frame;;
type segment = {sname:string; snum:int; ssty:style};;

type region = {rname:string; rnum:int};;

type dline = {lname:string; lnum:int};;
type dseg = segment set;;
type dcirc = {cname:string; cnum:int};;

type pangle = (dot * segment);;
(* pangles (primitive angles) are independent 
   of an angle's orientation,  
   and are named by giving the dot 
   that is the vertex of the angle and the solid segment that lies on the
   counter clockwise side of the angle  *)
   
type di_angle = pangle set;;

type regset = region set;;

type trianglesides = (dot * dseg  * dot *  dseg * dot  * dseg);;
   
type marker = {mname:string; mnum:int};;


(****************************)
(* new element constructors *)
(****************************)


(* an array is used to look up elements by number *)
type arrayelt = ArrayDot of dot | ArraySeg of segment | ArrayReg of region
		| ArrayLine of dline | ArrayCirc of dcirc 
		| ArrayMarker of marker | NullArrayElt;;

type usedstate = Clean | Dirty;;
(* usedstate is for checking if an element is currently used or can be deleted from the array so that 
its memory can be reclaimed*)

let namearray = Hashtbl.create initial_hashsize;;
exception Undefined;;

  
let getdot(i) = match (Hashtbl.find namearray i) with
    ArrayDot(dot) -> dot
  | _ -> raise Undefined;;
let getseg(i) = match (Hashtbl.find namearray i) with
    ArraySeg(seg) -> seg
  | _  -> raise Undefined;;
let getreg(i) = match (Hashtbl.find namearray i) with
    ArrayReg(reg) -> reg
  | _ -> raise Undefined;;
let getline(i) = match (Hashtbl.find namearray i) with
    ArrayLine(line) -> line
  | _  -> raise Undefined;;
let getcirc(i) = match (Hashtbl.find namearray i) with
    ArrayCirc(circ) -> circ
  | _ -> raise Undefined;;
let getmarker(i) = match (Hashtbl.find namearray i) with
    ArrayMarker(marker) -> marker
  | _ -> raise Undefined;;


let getdotnum(dot) = dot.dnum;;
let getsegnum(seg) = seg.snum;;
let getregnum(reg) = reg.rnum;;
let getmarkernum(marker) = marker.mnum;;
let getlinenum(line) = line.lnum;;
let getcircnum(circ) = circ.cnum;;

let newdot() : dot = 
  let c = counter() in
  let ndot = {dname = "dot"^string_of_int(c); dnum = c; dpos = Interior} in
    ndot;;
		
let newfdot() : dot = 
  let c = counter() in
  let ndot = {dname = "fdot"^string_of_int(c); dnum = c; dpos = OnFrame} in
    ndot;;

let newsseg() = 
  let c = counter() in
  let nseg = {sname = "solid"^string_of_int(c); snum = c; ssty=Solid} in
    nseg;;
		
let newdottedseg() = 
  let c = counter() in
  let nseg = {sname = "dottedseg"^string_of_int(c); snum = c; ssty=Dotted} in
    nseg;;
		
let newfseg() = 
  let c = counter() in
  let nseg = {sname = "frame"^string_of_int(c); snum = c; ssty=Frame} in
    nseg;;

let newregion() : region = 
  let c = counter() in
  let nreg = {rname= "region"^string_of_int(c); rnum = c} in
    nreg;;

let outerregion = 
  let c = counter() in
    {rname = "outerregion";rnum = c};;
(* a placeholder for the region outside the diagrams *)

let newline() : dline = 
  let c = counter() in
  let nline = {lname= "dline"^string_of_int(c); lnum = c} in
    nline;;
		
let newcirc(): dcirc  = 
  let c = counter() in
  let ncirc = {cname= "circle"^string_of_int(c); cnum = c} in
    ncirc;;

let newmarker()  = 
  let c = counter() in
  let nmarker = {mname= "marker"^string_of_int(c); mnum = c} in
    nmarker;;



(* Hashtable copying--used in loading diagrams from saved file. *)
 
let list_of_elts = ref [];;

(* makes a list of all elements *)
let list_hash number value = 
  list_of_elts := number::!list_of_elts;;

let rec add_list_to_hash(list,oldtbl,newtbl) = 
  match list with 
      first::rest -> 
	Hashtbl.add newtbl first (Hashtbl.find oldtbl first);
	add_list_to_hash(rest,oldtbl,newtbl)
    | _ -> ();;


let copy_hashtbl(oldtbl, newtbl) =
  Hashtbl.clear newtbl;
  list_of_elts := [];
  Hashtbl.iter list_hash oldtbl;
  add_list_to_hash(!list_of_elts,oldtbl,newtbl);
  list_of_elts := [];;
  
  
(* displayname tables *)

(* elements are assigned display numbers 
so that numbers on displayed diagrams are smaller*)
let displaynamearray = Hashtbl.create initial_hashsize;;
let reversedisplaynamearray = Hashtbl.create initial_hashsize;;


let assign_dn(inum) =
	if Hashtbl.mem displaynamearray inum
	then ()
	else
		let dnum = dn_counter() in 
		(*let dnum = inum in          for debugging *)
		Hashtbl.add displaynamearray inum dnum;
		Hashtbl.add reversedisplaynamearray dnum inum;;
			
let lookup_dn(inum) =
	Hashtbl.find displaynamearray inum;;
	
let rlookup_dn(dnum) =
	Hashtbl.find reversedisplaynamearray dnum;;

(****************************************************)	
(* Maps to keep track of relations between elements *)
(****************************************************)	

(* There are a lot of new types here for keeping track of 
pieces of diagrams in different situations.  *)

(* segend (segment end) and sse (single segment end)
are used to keep track of ends of segments.  Sse's help deal
with segments where both ends go to the same dot. *)
type segend = DotPair of (dot * dot) | NullEnd| Loop of (region*region);;
(* for a loop, we list the inner region first and the outer region 2nd *)

type sing_seg_end = Plain of segment | Returning of segment;;
(* the returning end of a seg that returns to the same dot is the cw side *)
type sse = sing_seg_end;;
let sse2seg(sse) = match sse with Plain(seg) -> seg | Returning(seg) -> seg;;

type edgemap = (segment -> segend);;
(* gives the dots on the boundry of a segment *)


(* Next, we have types for the surroundings of a dot. *)
type dotsurround = DSSeg of sse | Reg of region;;
let extractDSregion(ds) = match ds with Reg(reg) -> reg | _-> raise BadInput;;

(*rextensionidentifiers extend regions to regions plus the segments that are 
  their boundries, as seen from a dot. *)
type rextensionidentifier =   
    RI of (sse* region * sse)
  | SI of segment
  | SR of region;;
  
(*dextensionidentifiers extend dots to dots plus the segments next to them, 
  as seen from an adjoining region. *)  
type dextensionidentifier =   
				   DI of (sse * dot * sse) 
			     | SSI of segment
			     | STI of (dot * segment * dot)
			     | SD of dot;;

(* Similarly, extended dots, regions, and segments include the objects next to them*)
type ext_seg = ST of (dot * segment * dot) | SingSeg of segment;;
type ext_reg = RT of (sse * region * sse) | SingReg of region;;
type ext_dot = DT of (sse * dot * sse) | SingDot of dot;;

type diagelt = Dot of dot | Seg of segment;;
type regionedgemap = (region -> diagelt list);;
(* lists the segments/dots on the boundry of each region in clockwise order *)

type geom_obj = Line of dline | Circ of dcirc | NullGO;;
type membershipmap = segment -> geom_obj;;
(* tells which line or circle a given segment is part of *)
type intersectsmap = dot -> geom_obj set;;
(* tells which lines and circles intersect at the given dot *)
type intersect_number_map = (geom_obj -> (geom_obj -> int))
(* tells how many time the geometric objects intersect *)

type lmakeupmap = dline -> diagelt list;;
type center = CDot of dot | NullCenter;; 
type cmakeupmap = dcirc -> (diagelt list * center);;

type markables = Dseg of dseg | Angle of di_angle | RegionSet of regset;;
type markedbymap = markables -> marker set;;
type marksmap = marker -> markables set;;

type dotincidencemap = (dot -> dotsurround list);;
type simpledotincidencemap = (dot -> segment list)
(* lists the segments coming out of each dot in clockwise order *)


type region_info_struct =
    {int_bd_list:  (diagelt list) set;}
(*int_bd_list contains the boundries of inner components, in CCW order*)
type regioncontentsmap = region -> region_info_struct;;

let emptyedgemap:edgemap = function seg -> NullEnd;; 
let emptydotincmap:dotincidencemap = function d -> [];; 
let emptyregionedgemap:regionedgemap = function reg -> [];; 
let emptymembershipmap: membershipmap = function s -> NullGO;;
let emptyintersectsmap: intersectsmap = function d -> [];;
let emptylmakeupmap: lmakeupmap = function l -> [];;
let emptycmakeupmap: cmakeupmap = function c -> ([] , NullCenter);;
let emptymarkedbymap: markedbymap = function m -> emptyset;;
let emptymarksmap: marksmap = function m -> emptyset;;
let emptyinumbmap: intersect_number_map = (function g -> (function g2 -> 0));;
let empty_region_info_struct = {int_bd_list = []};;
let emptyrcmap = function r -> empty_region_info_struct;;

(*****************************************)
(* Primitive Diagrams and Diagram arrays *)
(*****************************************)

type container = Region of region | Outermost;;

type graphstruct = 
    {dots: dot set;
     segs: segment set;
     inc: dotincidencemap; 
     emap: edgemap;
     regs: region set} ;;

type pd = 
    {rmap: regionedgemap;
     rcmap: regioncontentsmap;
     graph: graphstruct;
     lmakeup: lmakeupmap;
     cmakeup: cmakeupmap;
     member: membershipmap; 
     intersect: intersectsmap;
     markers: marker set;
     markedby: markedbymap;
     marks: marksmap;
     lines: dline set;
     circs: dcirc set};;

type diagramarray = pd set;;
	 
let emptypd =
  let frameseg = newfseg() in
  let r = newregion() in
  let newemap = extendfunction(emptyedgemap,frameseg,Loop(r,outerregion)) in
  let initialgraph = {dots = emptyset; 
		      segs= [frameseg];
		      inc = emptydotincmap;
		      emap = newemap;
		      regs = r :: []} in
    {rmap = extendfunction(emptyregionedgemap, r, [Seg(frameseg)]);
     rcmap = emptyrcmap;
     graph = initialgraph;
     lmakeup = emptylmakeupmap;
     cmakeup = emptycmakeupmap;
     member = emptymembershipmap;
     intersect = emptyintersectsmap;
     markers = emptyset;
     markedby = emptymarkedbymap;
     marks = emptymarksmap;
     lines= [];
     circs = []};;

(*************************)
(* registration of names *)
(*************************)
 
(* register names adds all new objects to the namearray Hashtable so that 
they can be looked up by index. *)

let register_elt(index, obj) =
	if Hashtbl.mem namearray index
	then ()
	else Hashtbl.add namearray index obj;;

let register_dot(dot) =
	register_elt(dot.dnum, ArrayDot(dot));;
	
let register_seg(seg) =
	register_elt(seg.snum, ArraySeg(seg));;

let register_reg(reg) =
	register_elt(reg.rnum, ArrayReg(reg));;
	
let register_marker(marker) =
	register_elt(marker.mnum, ArrayMarker(marker));;
	
let register_line(line) =
	register_elt(line.lnum, ArrayLine(line));;
	
let register_circ(circ) =
	register_elt(circ.cnum, ArrayCirc(circ));;
  
let pd_register_names(pd) =
  ignore (List.map register_dot pd.graph.dots);
  ignore (List.map register_seg pd.graph.segs);
  ignore (List.map register_reg pd.graph.regs);
  ignore (List.map register_marker pd.markers);
  ignore (List.map register_line pd.lines);
  ignore (List.map register_circ pd.circs);;  
  
  
let rec register_names(diag_array) =
  match diag_array with
      first::rest ->
	pd_register_names(first);
	register_names(rest);
    | _ -> ();;

  
(* assigns displaynames to all parts of a pd that don't
	already have them *)
let pd_assign_dns(pd) =
	ignore (List.map assign_dn (List.map getdotnum pd.graph.dots));
	ignore (List.map assign_dn (List.map getsegnum pd.graph.segs));
	ignore (List.map assign_dn (List.map getregnum pd.graph.regs));
	ignore (List.map assign_dn (List.map getmarkernum pd.markers));
	ignore (List.map assign_dn (List.map getlinenum pd.lines));
	ignore (List.map assign_dn (List.map getcircnum pd.circs));;
	
let rec da_assign_dns(da)=
	match da with 
		  firstpd::rest ->
			pd_assign_dns(firstpd);
			da_assign_dns(rest)
		 | [] -> ();;
			
pd_register_names(emptypd);;
pd_assign_dns(emptypd);;


(*****************)	
(* Printing Pds  *)
(*****************)	

(* Produces a text-only representation of a diagram array *)

let printdot(dot) = 
	print_string("dot");
	print_string(string_of_int(lookup_dn(dot.dnum)));;

let longprintdot(dot) = 
  printdot(dot);
  print_string(" of type ");
  (match dot.dpos with
      Interior -> print_string("Interior Dot")
    | OnFrame -> print_string("Frame Dot"));
  print_newline();;

let printseg(seg) =
	begin
	match seg.ssty with
		Solid ->
			print_string("solidseg")
		| Dotted ->
			print_string("dottedseg")
		| Frame ->
			print_string("frameseg")
		end;
	print_string(string_of_int(lookup_dn(seg.snum)));;

let printsse(sse) = 
  match sse with
      Plain(seg) -> printseg(seg)
    | Returning(seg) -> 
	print_string("R(");
	printseg(seg);
	print_string(")");;

let printreg(reg) = 
	if reg.rname = "outerregion"
	then print_string("outerregion")
	else
 	(print_string("region");
	print_string(string_of_int(lookup_dn(reg.rnum))));;

let printmarker(marker) =
	print_string("marker");
	print_string(string_of_int(lookup_dn(marker.mnum)));;

let print_line(dline) = 
	print_string("dline");
	print_string(string_of_int(lookup_dn(dline.lnum)));;

let print_circ(dcirc) =
	print_string("dcirc");
	print_string(string_of_int(lookup_dn(dcirc.cnum)));;

let printpangle(pangle) =
  let (dot,seg) = pangle in
    print_string("PAngle(");
    printdot(dot);
    print_string(",");
    printseg(seg);
    print_string(")");;

let rec rec_print_di_angle(angle)=
  match angle with
      first::[] ->
	printpangle(first);
	print_string(")")
    | first::rest ->
	printpangle(first);
	print_string(",");
	rec_print_di_angle(rest);
    | _ -> print_string(")");;

let print_di_angle(angle) =
  print_string("Di_angle(");
  rec_print_di_angle(angle);;

let rec rec_print_dseg(dseg)=
  match dseg with
      first::[] ->
	printseg(first);
	print_string(")")
    | first::rest ->
	printseg(first);
	print_string(",");
	rec_print_dseg(rest)
    | _ -> print_string(")");;

let print_dseg(dseg) =
  print_string("DSeg(");
  rec_print_dseg(dseg);;
  
let rec rec_print_regset(regset)=
  match regset with
      first::[] ->
	printreg(first);
	print_string(")")
    | first::rest ->
	printreg(first);
	print_string(",");
	rec_print_regset(rest)
    | _ -> print_string(")");;

let print_regset(regset) =
  print_string("RegionSet(");
  rec_print_regset(regset);;

let rec printdelist(delist) =
  match delist with
      Dot(dot)::rest -> (printdot(dot);
			 print_string(" ");
			 printdelist(rest))
    | Seg(seg)::rest -> (printseg(seg);
			 print_string(" ");
			 printdelist(rest))
    | _ -> ();;

let rec printdslist(delist) =
  match delist with
      Reg(reg)::rest -> (printreg(reg);
			 print_string(" ");
			 printdslist(rest))
    | DSSeg(seg)::rest -> (printsse(seg);
			   print_string(" ");
			   printdslist(rest))
    | _ -> ();;

let rec printmarkablelist(mlist) =
  match mlist with
      Angle(a)::rest -> (print_di_angle(a);
			 print_string(" ");
			 printmarkablelist(rest))
    | Dseg(seg)::rest -> (print_dseg(seg);
			  print_string(" ");
			  printmarkablelist(rest))
	| RegionSet(regset)::rest ->
		(print_regset(regset);
		 print_string(" ");
		 printmarkablelist(rest))
    | _ -> ();;


let rec printcontentslist(bdlistlist, i) =
  match bdlistlist with
      first::rest -> (print_string("Component #");
		      print_int(i);
		      print_string(": ");
		      printdelist(first);
		      print_newline();
		      printcontentslist(rest,i + 1))
    | _ -> ();;


let printend(segend) =
  match segend with
      DotPair(dot1,dot2) -> (print_string("dots ");
			     printdot(dot1);
			     print_string(" and ");
			     printdot(dot2);)
    | NullEnd -> print_string("NullEnd")
    | Loop(reg1,reg2) -> (print_string("loop in regions ");
			     printreg(reg1);
			     print_string(" and ");
			     printreg(reg2););;
      

let rec rec_printsegends(segs,emap) =
  match segs with
      first::rest -> (printseg(first);
		      print_string(" ends at ");
		      printend(emap(first));
		      print_newline();
		      rec_printsegends(rest,emap))
    | _ -> ();;

let printsegends(graph) =
  rec_printsegends(graph.segs,graph.emap);;

let rec printmarkerl(markerl) =
  match markerl with
      first::rest -> (printmarker(first);
		      print_string(" ");
		      printmarkerl(rest))
    | _ -> ();;
	
let rec rec_printmarkings(markers,mmap) =
  match markers with
      first::rest -> (printmarker(first);
		      print_string(" marks ");
		      printmarkablelist(mmap(first));
		      print_newline();
		      rec_printmarkings(rest,mmap))
    | _ -> ();;

let printmarkings(pd) =
  rec_printmarkings(pd.markers,pd.marks);;

let rec rec_printlines(lines,lmakeup) = 
  match lines with
      first :: rest -> (print_line(first);
			print_string(" is made up of ");
			printdelist(lmakeup(first));
			print_newline();
			rec_printlines(rest,lmakeup);)
    | _ -> ();;

let printlines(pd) = rec_printlines(pd.lines,pd.lmakeup);;

let rec rec_printcircs(circs,cmakeup) = 
  match circs with
      first :: rest -> 
	(match cmakeup(first) with
	     (list,CDot(dot)) ->
	       (print_circ(first);
		print_string(" has center ");
		printdot(dot);
		print_string(" and boundry ");
		printdelist(list);
		print_newline();
		rec_printcircs(rest,cmakeup);)
	   | _ -> raise BadInput)
    | _ -> ();;

let printcircs(pd) = rec_printcircs(pd.circs,pd.cmakeup);;

let rec print_intersectslist(ilist) =
	match ilist with
		  Circ(c)::rest ->
			(print_circ(c);
			 print_intersectslist(rest))
		| Line(l)::rest -> 
			(print_line(l);
			 print_intersectslist(rest))
		| NullGO::rest -> 
			(print_string("NullGO ");
			 print_intersectslist(rest))
		| [] -> ();;

let rec rec_printdotsur(dots,inc) =
  match dots with
      first::rest -> (printdot(first);
		      print_string(" is surrounded by: ");
		      printdslist(inc(first));
		      print_newline();
		      rec_printdotsur(rest,inc))
    | _ -> ();;

let printdotsur(graph) = 
  rec_printdotsur(graph.dots,graph.inc);;
  
let rec rec_printdotint(dots,pd) =
  match dots with
      first::rest -> (printdot(first);
		      print_string(" intersects: ");
		      print_intersectslist((pd.intersect)(first));
		      print_newline();
		      rec_printdotint(rest,pd))
    | _ -> ();;
	
let printdotint(pd) =
	rec_printdotint((pd.graph).dots,pd);;

let rec rec_printreginfo(regs,rmap,rcmap) =
  match regs with
      first::rest -> (printreg(first);
		      print_string(" has boundry: ");
		      printdelist(rmap(first));
		      print_newline();
		      print_string("        and contents: ");
		      print_newline();
		      printcontentslist((rcmap(first)).int_bd_list, 1);
		      print_newline();
		      rec_printreginfo(rest,rmap,rcmap))
    | _ -> print_newline();;

let printreginfo(pd) =
  rec_printreginfo(pd.graph.regs,pd.rmap,pd.rcmap);;

let printpd(pd) = 
  printdotsur(pd.graph);
 (* printdotint(pd); *)
  printsegends(pd.graph);
  printmarkings(pd);
  printlines(pd);
  printcircs(pd);
  print_newline();
  printreginfo(pd);;

let rec rec_printpdlist(pdlist,i) =
  match pdlist with
      first::rest -> (print_string("Diagram #");
		      print_int(i);
		      print_string(": ");
		      print_newline();
		      printpd(first);
		      rec_printpdlist(rest,i+1))
    | _ -> print_newline();;

let printpdlist(pdlist) = 
match pdlist with 
    [] -> 
      print_string("Empty PD list");
      print_newline();
  | _ ->
      rec_printpdlist(pdlist,1);; 
	  

(****************************)
(* Conversion Between Types *)
(****************************)

(* conversion from dextensionidentifiers to ext_dots*)
let dei2edot(dei) =
  match dei with
      DI(sse1,dot,sse2) -> DT(sse1,dot,sse2)
    | SD(dot) -> SingDot(dot) 
    | _ -> raise BadInput;;

let reiflip(rei) =
  match rei with
      RI(sse1,reg,sse2) -> RI(sse2,reg,sse1)
    | _ -> rei;;

let exreg2exdot(ereg,dot) = 
  match ereg with
      RT(seg1,reg,seg2) -> DT(seg1,dot,seg2)
    | SingReg(region) -> SingDot(dot);;

let exdot2exreg(edot,reg) = 
  match edot with
      DT(seg1,dot,seg2) -> RT(seg1,reg,seg2)
    | SingDot(dot) -> SingReg(reg);;
	
let exdot2ndseg(edot) =
	match edot with
		  DT(seg1,dot,seg2) -> seg2
		  | _ -> raise BadInput;;


(* replaces a seg in an ext_reg*)
let replaceinRT(ereg,seg,newseg) =
  match ereg with
      RT(seg1,reg,seg2) when (seg1 = seg & seg2 = seg) ->
	RT(newseg,reg,newseg)
    | RT(seg1,reg,seg2) when (seg1 = seg) ->
	RT(newseg,reg,seg2)
    | RT(seg1,reg,seg2) when (seg2 = seg) ->
	RT(seg1,reg,newseg)
    | _ -> ereg;;


let swapexregdot(ereg,edot,ind_dot) = (* fixed 5/3 DEBUG*)
  match ereg with
      RT(rseg1,reg,rseg2) ->
	(match edot with
	     DT(dseg1,dot,dseg2) -> 
	       (RT(dseg2,reg,dseg1),DT(rseg2,ind_dot,rseg1),dot)
	   | SingDot(dot) -> (SingReg(reg),DT(rseg2,ind_dot,rseg1),dot))
    | SingReg(reg) ->
	(match edot with
	     DT(dseg1,dot,dseg2) -> (RT(dseg2,reg,dseg1),SingDot(ind_dot),dot)
	   | SingDot(dot) -> (SingReg(reg),SingDot(ind_dot),dot))

let extractsegment(eseg) = 
  match eseg with
      ST(dot1,seg,dot2) -> seg 
    | SingSeg(seg) -> seg;;

let extractregion(ereg) = 
  match ereg with
      RT(seg1,reg,seg2) -> reg 
    | SingReg(reg) -> reg;;

let extractdot(edot) =
  match edot with
      DT(seg1,dot,seg2) -> dot
    | SingDot(dot) -> dot;;

let eflip(ereg) =
  match ereg with
      RT(seg1,reg,seg2) -> RT(seg2,reg,seg1) 
    | SingReg(reg) -> SingReg(reg);;



let rec recsegextract(dotinc, output) =
  match dotinc with
      DSSeg(seg) :: rest -> recsegextract(rest, seg :: output)
    | Reg(reg) :: rest -> recsegextract(rest,output)
    | _ -> List.rev(output);;

(*segextract converts a dotsurround list to the corresponding segend list*)
let segextract(dotinc) = recsegextract(dotinc, []);;

let rec recssegextract(dotinc, output) =
  match dotinc with
      DSSeg(Plain(seg)) :: rest when seg.ssty = Solid -> recssegextract(rest, seg :: output)
	| DSSeg(segend) :: rest -> recssegextract(rest, output)
    | Reg(reg) :: rest -> recssegextract(rest,output)
    | _ -> List.rev(output);;

(*ssegextract converts a dotsurround list to the corresponding seg list, only including
   solid segments*)
let ssegextract(dotinc) = recssegextract(dotinc, []);;


exception NotASeg
exception NotADot

let ds2v_seg(dselt) = 
  match dselt with
      DSSeg(seg) -> Seg(sse2seg(seg))
    | _ -> raise NotASeg;; 
	
let diagelt2sse(de) = 
  match de with
      Seg(seg) -> Plain(seg)
    | _ -> raise NotASeg;;
	
let de2dot(de) = 
  match de with
      Dot(d) -> d
    | _ -> raise NotADot;;




(********************)
(*  EIification     *)
(********************)

(* Conversion from dotsurrounds to 
extension identifiers.  Extension identifiers have
3 surrounding pieces at once. *)

type delistorig = Out | In;;  
(* specifies whether this is a boundry (Out) list or a comp (In) list *)

(*rEIify converts a list of dotsurrounds to a list of rextensionidentifiers *)
let rec rEIify(delist) = 
  match delist with
      DSSeg(seg)::[] -> [SI(sse2seg(seg))]
    | Reg(reg)::[] -> [SR(reg)]
    | Reg(reg)::rest -> rec_rEIify(lastelt(delist)::delist)
    | DSSeg(seg)::rest -> rec_rEIify(append(delist,[DSSeg(seg)]))
    | _-> []
and rec_rEIify(delist) =
  match delist with
      DSSeg(seg)::Reg(reg)::DSSeg(seg2)::rest ->
	RI(seg,reg,seg2)::SI(sse2seg(seg2))::rec_rEIify(DSSeg(seg2)::rest)
    | DSSeg(seg) :: [] -> []
    | _ -> raise BadInputList;;


let dEIified_dot_2_ereg(eoutdot,reg) =
  match eoutdot with
      DI(sse1,dot,sse2) -> 
	(dot,RT(sse1,reg,sse2))
    | _ -> raise BadInput;;

let rec make_correct_EI(seg,dot,seg2,orig,pd)= 
  let edgem = pd.graph.emap in
    match (edgem(seg),edgem(seg2)) with
	(DotPair(ed1,ed2),DotPair(ed3,ed4)) 
	when not(((ed1 = dot) & (ed2 = dot)) or 
		 ((ed3 = dot) & (ed4 = dot))) ->
	  DI(Plain(seg),dot,Plain(seg2))
      | (DotPair(ed1,ed2),DotPair(ed3,ed4)) ->
	  let dslist = (pd.graph.inc)(dot) in
	  let db_dslist = double(dslist) in
	    rec_make_correct_EI(db_dslist,seg,dot,seg2)
      | _ -> raise BadInput
and rec_make_correct_EI(db_dslist,seg,dot,seg2) =
  match db_dslist with
      DSSeg(sse2)::Reg(reg)::DSSeg(sse)::rest 
	when (sse2seg(sse2) = seg2 & sse2seg(sse) = seg) ->
	  DI(sse,dot,sse2) 
    | first::rest -> rec_make_correct_EI(rest,seg,dot,seg2)
    | _ -> raise BadInput;;
      
(*rEIify converts a list of diagelts to a list of dextensionidentifiers *)
let rec dEIify(delist,orig,pd) = 
  match delist with
      Seg(seg)::[] -> [SSI(seg)]
    | Dot(dot)::[] -> [SD(dot)]
    | Seg(seg)::Dot(dot)::[] ->
	(match orig with
	    In -> [DI(Plain(seg),dot,Returning(seg));
		   STI(dot,seg,dot)]
	  | Out -> [DI(Returning(seg),dot,Plain(seg));
		   STI(dot,seg,dot)])
    | Dot(dot)::Seg(seg)::[] ->
	(match orig with
	    In -> [DI(Plain(seg),dot,Returning(seg));
		   STI(dot,seg,dot)]
	  | Out -> [DI(Returning(seg),dot,Plain(seg));
		   STI(dot,seg,dot)])
    | first::rest -> 
	let (e1,e2) = lasttwoelts(delist) in
	  rec_EIify(e1::e2::delist,orig,pd)
    | _-> []
and rec_EIify(delist,orig,pd) =
  match delist with
      Seg(seg)::Dot(dot)::Seg(seg2)::rest ->
	make_correct_EI(seg,dot,seg2,orig,pd)
	::rec_EIify(Dot(dot)::Seg(seg2)::rest,orig,pd)
    | Dot(dot)::Seg(seg)::Dot(dot2)::rest ->
	STI(dot,seg,dot2)::rec_EIify(Seg(seg)::Dot(dot2)::rest,orig,pd)
    | _ -> [];;
	  
	  
	  
(********************************)
(* Useful Functions on Diagrams *)
(********************************)

(* Sorting of geometric objects *)
let seg_compare seg1 seg2  =
	let index1 = seg1.snum in
	let index2 = seg2.snum in
	(index1 - index2);;

let sort_dseg(dseg) = List.fast_sort seg_compare dseg;;

let reg_compare reg1 reg2  =
	let index1 = reg1.rnum in
	let index2 = reg2.rnum in
	(index1 - index2);;

let sort_regset(regset) = List.fast_sort reg_compare regset;;

(* defines lexicographic ordering on di_angles *)
let di_angle_compare pang1 pang2 =
	let (dot1,seg1) = pang1 in
	let (dot2,seg2) = pang2 in
	let dot1i = dot1.dnum in
	let dot2i = dot2.dnum in
	let seg1i = seg1.snum in
	let seg2i = seg2.snum in
	if dot1i = dot2i then seg1i - seg2i else dot1i - dot2i;;

let sort_diang(diang) = List.fast_sort di_angle_compare diang;;

let rec mapmarkedinward(seg,dot1,newseg1,dot2,newseg2,mlist) = 
  match mlist with
      Dseg(set)::rest when inset(seg,set) ->
		let newset1 =
			replaceinlist(set,seg,newseg1::newseg2::[]) 
		in
		let newset2 = 
			List.fast_sort seg_compare newset1 in
		Dseg(newset2)::mapmarkedinward(seg,dot1,newseg1,dot2,newseg2,rest)
	| Dseg(set)::rest ->
		Dseg(set)::mapmarkedinward(seg,dot1,newseg1,dot2,newseg2,rest)
    | Angle(a)::rest -> 
		let a2 = doublereplaceinlist(a,(dot1,seg),[(dot1,newseg1)],
									   (dot2,seg),[(dot2,newseg2)]) in
		let a3 = sort_diang(a2) in
		Angle(a3)::mapmarkedinward(seg,dot1,newseg1,dot2,newseg2,rest)
	| RegionSet(rs)::rest -> RegionSet(rs)::mapmarkedinward(seg,dot1,newseg1,dot2,newseg2,rest)
    | [] -> [];;



let marked_equal(markable1, markable2,pd) = 
  not (disjoint(pd.markedby(markable1),pd.markedby(markable2)));;
  
(* converts a diagelt list into a dseg  *)  
let rec diageltl2dseg(delist) =
	let newlist = rec_diageltl2dseg(delist) in
	sort_dseg(newlist)
and rec_diageltl2dseg(delist) =
	match delist with
		    Seg(s)::rest -> s::rec_diageltl2dseg(rest)
		  | Dot(d)::rest -> rec_diageltl2dseg(rest)
		  | [] -> [];;  
  
  
  (* filterlines takes a list of geometric objects and returns 
     the lines from that list*)
let rec filterlines(golist) =
	match golist with
		  Line(l)::rest -> l::filterlines(rest)
		| other::rest -> filterlines(rest)
		| [] -> [];;
		
  (* filterpoints takes a list of diagelts and returns 
     the dots from that list*)
let rec filterdots(delist) =
	match delist with
		  Dot(d)::rest -> d::filterdots(rest)
		| other::rest -> filterdots(rest)
		| [] -> [];;
		
  
  
let dseg_from_endpoints(dot1,dot2,pd) =
	let lines1 = filterlines((pd.intersect)(dot1)) in
	let lines2 = filterlines((pd.intersect)(dot2)) in
	let line = uniquesetintersection(lines1,lines2) in
	let (bg, middle, ed) = splitin3((pd.lmakeup)(line),Dot(dot1),Dot(dot2)) in
	diageltl2dseg(middle);;
	
	
	
let find_radii(circle,pd) =
	let (clist, cdcent) = (pd.cmakeup)(circle) in
	let ccent = match cdcent with
		CDot(cd) -> cd
		|_ -> raise BadInput in
	let cpoints = filterdots(clist) in
	let f = function d ->
		(try
			[Dseg(dseg_from_endpoints(d, ccent, pd))]
		with
			_ -> [])
	in List.flatten (List.map f cpoints);;
			
	
(*
exception Bad_dseg_exception;;
exception Bad_args;;

let rec recboundry(segendl) = 
  match segendl with
      DotPair(d1,d2)::DotPair(d3,d4)::rest -> 
	if d1 = d3 then recboundry(DotPair(d2,d4)::rest)
	else if d1 = d4 then recboundry(DotPair(d2,d3)::rest)
	else if d2 = d3 then recboundry(DotPair(d1,d4)::rest)
	else if d2 = d4 then recboundry(DotPair(d1,d3)::rest)
	else raise Bad_dseg_exception
    | DotPair(d1,d2)::[] -> (d1,d2)
    | _ -> raise Bad_dseg_exception;;

let boundry(dseg, pd) = 
  recboundry(List.map pd.graph.emap dseg);; 

let is_radius((d1,d2),(eltlist,cent)) =
  match cent with
      CDot(center) ->
	if center = d1 then inset(Dot(d2),eltlist)
	else if center = d2 then inset(Dot(d1),eltlist)
	else false
    |_-> raise Bad_args;; *)

let edge_elt(dot,pd,region) = inlist(Dot(dot),pd.rmap(region));;





(* dotcomp returns the boundry of the interior component that 
    dot is part of in a given region. *)
let rec rec_dotcomp(dot,complist) = 
  match complist with
      first::rest when inlist(Dot(dot),first)-> first
    | first::rest -> rec_dotcomp(dot,rest)
    | _ -> raise BadInputList;;

let dotcomp(dot,pd,region) =
  let complist = (pd.rcmap(region)).int_bd_list in
    rec_dotcomp(dot,complist);;

(**************************)
(* Marker Inference Rules *)
(**************************)

let fixmarkby(marker1, eltset, oldmarkedby) =
  function elt -> 
    if inset(elt, eltset) then fancysetadjoin(marker1, oldmarkedby(elt))
    else oldmarkedby(elt);;
		
exception Inapplicable;;
		

(* marker_combine combines two overlapping markers.  This rule takes the place of 
   transitivity.  It is unsafe to use if one marker marks more than one type of object
   (segments, angles, or regions), but this should never happen.  *)

let marker_combine(pd, marker1, marker2, markable) =
  if 
    (inset(markable, pd.marks(marker1)) & inset(markable, pd.marks(marker2)))
  then 
    let newmarkedby = fixmarkby(marker1,pd.marks(marker2),pd.markedby) in
    let newmarkers = setremove(marker2,pd.markers) in
      {rmap = pd.rmap;
       rcmap = pd.rcmap;
       graph = pd.graph;
       lmakeup = pd.lmakeup;
       cmakeup = pd.cmakeup;
       lines = pd.lines;
       circs = pd.circs;
       member = pd.member;
       intersect = pd.intersect;
       markers = newmarkers;
       markedby = newmarkedby;
       marks = extendfunction(pd.marks,
			      marker1, 
			      fancysetunion(pd.marks(marker1),
					    pd.marks(marker2)))}
  else raise Inapplicable;;

let fast_marker_combine(pd, marker1, marker2) =
    let newmarkedby = fixmarkby(marker1,pd.marks(marker2),pd.markedby) in
    let newmarkers = setremove(marker2,pd.markers) in
      {rmap = pd.rmap;
       rcmap = pd.rcmap;
       graph = pd.graph;
       lmakeup = pd.lmakeup;
       cmakeup = pd.cmakeup;
       lines = pd.lines;
       circs = pd.circs;
       member = pd.member;
       intersect = pd.intersect;
       markers = newmarkers;
       markedby = newmarkedby;
       marks = extendfunction(pd.marks,
			      marker1, 
			      fancysetunion(pd.marks(marker1),
					    pd.marks(marker2)))};;

let rec marker_fix(pd,markable) =
  let mlist = pd.markedby(markable) in
    match mlist with 
	first::rest -> rec_marker_fix(pd,first,rest)
      | _ -> pd
and rec_marker_fix(pd,marker1,list) =
  match list with
      first::rest -> 
	rec_marker_fix(fast_marker_combine(pd,marker1,first),marker1,rest)
    | _ -> pd;;


(* marker_union marks equal the unions of two sets of segs already marked
   equal; it takes the place of segment addition.  *)

let marker_union_seg(pd, dseg1, dseg2, dsegA, dsegB) =
  if (marked_equal(Dseg(dseg1), Dseg(dsegA), pd) & 
      marked_equal(Dseg(dseg2), Dseg(dsegB), pd)) &
	  (disjoint(dseg1,dseg2) & disjoint(dsegA , dsegB))
  then
    let  (dseg3, dsegC) = (sort_dseg(setunion(dseg1,dseg2)), 
						   sort_dseg(setunion(dsegA,dsegB))) in
    let marker3 = newmarker() in 
	   assign_dn(marker3.mnum);
      {rmap = pd.rmap;
       rcmap = pd.rcmap;
       graph = pd.graph;
       lmakeup = pd.lmakeup;
       cmakeup = pd.cmakeup;
       lines = pd.lines;
       circs = pd.circs;
       member = pd.member;
       intersect = pd.intersect;
       markers = setadjoin(marker3,pd.markers);
       markedby = extendfunction(
	 extendfunction(pd.markedby, Dseg(dseg3), setadjoin(marker3, pd.markedby(Dseg(dseg3)))),
	 Dseg(dsegC),
	 setadjoin(marker3, pd.markedby(Dseg(dsegC))));
       marks = extendfunction(pd.marks,
			      marker3, 
			      setadjoin(Dseg(dseg3), setadjoin(Dseg(dsegC), emptyset)))}
  else raise Inapplicable;;

let marker_union_ang(pd, ang1, ang2, angA, angB) =
  if (marked_equal(Angle(ang1), Angle(angA), pd) & 
      marked_equal(Angle(ang2), Angle(angB), pd)) &
	  (disjoint(ang1,ang2) & disjoint(angA , angB))
  then
    let  (ang3, angC) = (sort_diang(setunion(ang1,ang2)), 
						 sort_diang(setunion(angA,angB))) in
    let marker3 = newmarker() in 
	  assign_dn(marker3.mnum);
      {rmap = pd.rmap;
       rcmap = pd.rcmap;
       graph = pd.graph;
       lmakeup = pd.lmakeup;
       cmakeup = pd.cmakeup;
       lines = pd.lines;
       circs = pd.circs;
       member = pd.member;
       intersect = pd.intersect;
       markers = setadjoin(marker3,pd.markers);
       markedby = extendfunction(
	 extendfunction(pd.markedby, Angle(ang3), setadjoin(marker3, pd.markedby(Angle(ang3)))),
	 Angle(angC),
	 setadjoin(marker3, pd.markedby(Angle(angC))));
       marks = extendfunction(pd.marks,
			      marker3, 
			      setadjoin(Angle(ang3), setadjoin(Angle(angC), emptyset)))}
  else raise Inapplicable;;
  
let marker_union_reg(pd, regs1, regs2, regsA, regsB) =
  if (marked_equal(RegionSet(regs1), RegionSet(regsA), pd) & 
      marked_equal(RegionSet(regs2), RegionSet(regsB), pd)) &
	  (disjoint(regs1,regs2) & disjoint(regsA , regsB))
  then
    let  (regs3, regsC) = (sort_regset(setunion(regs1,regs2)), 
						   sort_regset(setunion(regsA,regsB))) in
    let marker3 = newmarker() in 
	   assign_dn(marker3.mnum);
      {rmap = pd.rmap;
       rcmap = pd.rcmap;
       graph = pd.graph;
       lmakeup = pd.lmakeup;
       cmakeup = pd.cmakeup;
       lines = pd.lines;
       circs = pd.circs;
       member = pd.member;
       intersect = pd.intersect;
       markers = setadjoin(marker3,pd.markers);
       markedby = extendfunction(
	 extendfunction(pd.markedby, RegionSet(regs3), setadjoin(marker3, pd.markedby(RegionSet(regs3)))),
	 RegionSet(regsC),
	 setadjoin(marker3, pd.markedby(RegionSet(regsC))));
       marks = extendfunction(pd.marks,
			      marker3, 
			      setadjoin(RegionSet(regs3), setadjoin(RegionSet(regsC), emptyset)))}
   else raise Inapplicable;;
 
let marker_subtract_seg(pd, dseg1, dseg2, dsegA, dsegB) =
  if (marked_equal(Dseg(dseg1), Dseg(dsegA), pd) & 
      marked_equal(Dseg(dseg2), Dseg(dsegB), pd)) &
	  (subset(dseg1,dseg2) & subset(dsegA , dsegB))
  then
    let  (dseg3, dsegC) = (sort_dseg(setdifference(dseg1,dseg2)), 
						   sort_dseg(setdifference(dsegA,dsegB))) in
    let marker3 = newmarker() in 
	   assign_dn(marker3.mnum);
      {rmap = pd.rmap;
       rcmap = pd.rcmap;
       graph = pd.graph;
       lmakeup = pd.lmakeup;
       cmakeup = pd.cmakeup;
       lines = pd.lines;
       circs = pd.circs;
       member = pd.member;
       intersect = pd.intersect;
       markers = setadjoin(marker3,pd.markers);
       markedby = extendfunction(
	 extendfunction(pd.markedby, Dseg(dseg3), setadjoin(marker3, pd.markedby(Dseg(dseg3)))),
	 Dseg(dsegC),
	 setadjoin(marker3, pd.markedby(Dseg(dsegC))));
       marks = extendfunction(pd.marks,
			      marker3, 
			      setadjoin(Dseg(dseg3), setadjoin(Dseg(dsegC), emptyset)))}
  else raise Inapplicable;;
  
let marker_subtract_reg(pd, regs1, regs2, regsA, regsB) =
  if (marked_equal(RegionSet(regs1), RegionSet(regsA), pd) & 
      marked_equal(RegionSet(regs2), RegionSet(regsB), pd)) &
	  (subset(regs1,regs2) & subset(regsA , regsB))
  then
    let  (regs3, regsC) = (sort_regset(setdifference(regs1,regs2)), 
						   sort_regset(setdifference(regsA,regsB))) in
    let marker3 = newmarker() in 
	   assign_dn(marker3.mnum);
      {rmap = pd.rmap;
       rcmap = pd.rcmap;
       graph = pd.graph;
       lmakeup = pd.lmakeup;
       cmakeup = pd.cmakeup;
       lines = pd.lines;
       circs = pd.circs;
       member = pd.member;
       intersect = pd.intersect;
       markers = setadjoin(marker3,pd.markers);
       markedby = extendfunction(
	 extendfunction(pd.markedby, RegionSet(regs3), setadjoin(marker3, pd.markedby(RegionSet(regs3)))),
	 RegionSet(regsC),
	 setadjoin(marker3, pd.markedby(RegionSet(regsC))));
       marks = extendfunction(pd.marks,
			      marker3, 
			      setadjoin(RegionSet(regs3), setadjoin(RegionSet(regsC), emptyset)))}
   else raise Inapplicable;;

let marker_subtract_ang(pd, ang1, ang2, angA, angB) =
  if (marked_equal(Angle(ang1), Angle(angA), pd) & 
      marked_equal(Angle(ang2), Angle(angB), pd)) &
	  (subset(ang1,ang2) & subset(angA , angB))
  then
    let  (ang3, angC) = (sort_diang(setdifference(ang1,ang2)), 
						 sort_diang(setdifference(angA,angB))) in
    let marker3 = newmarker() in 
	  assign_dn(marker3.mnum);
      {rmap = pd.rmap;
       rcmap = pd.rcmap;
       graph = pd.graph;
       lmakeup = pd.lmakeup;
       cmakeup = pd.cmakeup;
       lines = pd.lines;
       circs = pd.circs;
       member = pd.member;
       intersect = pd.intersect;
       markers = setadjoin(marker3,pd.markers);
       markedby = extendfunction(
	 extendfunction(pd.markedby, Angle(ang3), setadjoin(marker3, pd.markedby(Angle(ang3)))),
	 Angle(angC),
	 setadjoin(marker3, pd.markedby(Angle(angC))));
       marks = extendfunction(pd.marks,
			      marker3, 
			      setadjoin(Angle(ang3), setadjoin(Angle(angC), emptyset)))}
  else raise Inapplicable;;



let add_single_marker(pd, markedobj) =
    let marker3 = newmarker() in
	  assign_dn(marker3.mnum);
      {rmap = pd.rmap;
       graph = pd.graph;
       rcmap = pd.rcmap;
       lmakeup = pd.lmakeup;
       cmakeup = pd.cmakeup;
       lines = pd.lines;
       circs = pd.circs;
       member = pd.member;
       intersect = pd.intersect;
       markers = setadjoin(marker3,pd.markers);
       markedby = extendfunction(pd.markedby, markedobj, 
								 setadjoin(marker3, pd.markedby(markedobj)));
       marks = extendfunction(pd.marks,
			      marker3, 
			      setadjoin(markedobj,emptyset))};;
				  
(*let mark_radii_old(pd, circle, dseg1, dseg2) = 
  if (is_radius(boundry(dseg1,pd), pd.cmakeup(circle)) &
      is_radius(boundry(dseg2,pd),pd.cmakeup(circle))) 
  then 
    let marker3 = newmarker() in
	  assign_dn(marker3.mnum);
      {rmap = pd.rmap;
       graph = pd.graph;
       rcmap = pd.rcmap;
       lmakeup = pd.lmakeup;
       cmakeup = pd.cmakeup;
       lines = pd.lines;
       circs = pd.circs;
       member = pd.member;
       intersect = pd.intersect;
       markers = setadjoin(marker3,pd.markers);
       markedby = extendfunction(
	 extendfunction(pd.markedby, Dseg(dseg1), setadjoin(marker3, pd.markedby(Dseg(dseg1)))),
	 Dseg(dseg2),
	 setadjoin(marker3, pd.markedby(Dseg(dseg2))));
       marks = extendfunction(pd.marks,
			      marker3, 
			      setadjoin(Dseg(dseg1), setadjoin(Dseg(dseg2), 
							       emptyset)))}
  else raise Inapplicable;;*)
  
let mark_radii(pd, circle) = 
	let radii = find_radii(circle,pd) in
    let marker3 = newmarker() in
	  assign_dn(marker3.mnum);
      {rmap = pd.rmap;
       graph = pd.graph;
       rcmap = pd.rcmap;
       lmakeup = pd.lmakeup;
       cmakeup = pd.cmakeup;
       lines = pd.lines;
       circs = pd.circs;
       member = pd.member;
       intersect = pd.intersect;
       markers = setadjoin(marker3,pd.markers);
       markedby = (function d ->
			if inset(d,radii)
			then setadjoin(marker3,(pd.markedby)(d))
			else (pd.markedby)(d));
       marks = extendfunction(pd.marks,marker3, radii)};;

let mark_segs(pd, dseg1,dseg2) =
    let marker3 = newmarker() in
	  assign_dn(marker3.mnum);
      {rmap = pd.rmap;
       graph = pd.graph;
       rcmap = pd.rcmap;
       lmakeup = pd.lmakeup;
       cmakeup = pd.cmakeup;
       lines = pd.lines;
       circs = pd.circs;
       member = pd.member;
       intersect = pd.intersect;
       markers = setadjoin(marker3,pd.markers);
        markedby = extendfunction(
	 extendfunction(pd.markedby, Dseg(dseg1), setadjoin(marker3, pd.markedby(Dseg(dseg1)))),
	 Dseg(dseg2),
	 setadjoin(marker3, pd.markedby(Dseg(dseg2))));
       marks = extendfunction(pd.marks,
			      marker3, 
			      setadjoin(Dseg(dseg1), setadjoin(Dseg(dseg2), 
							       emptyset)))}
								   
let mark_angs(pd, dang1,dang2) =
    let marker3 = newmarker() in
	  assign_dn(marker3.mnum);
      {rmap = pd.rmap;
       graph = pd.graph;
       rcmap = pd.rcmap;
       lmakeup = pd.lmakeup;
       cmakeup = pd.cmakeup;
       lines = pd.lines;
       circs = pd.circs;
       member = pd.member;
       intersect = pd.intersect;
       markers = setadjoin(marker3,pd.markers);
	   markedby = extendfunction(
			extendfunction(pd.markedby, Angle(dang1), setadjoin(marker3, pd.markedby(Angle(dang1)))),
									Angle(dang2),
									setadjoin(marker3, pd.markedby(Angle(dang2))));
       marks = extendfunction(pd.marks,
			      marker3, 
			      setadjoin(Angle(dang1), setadjoin(Angle(dang2), 
							       emptyset)))}
								   
let mark_regs(pd, regs1,regs2) =
    let marker3 = newmarker() in
	  assign_dn(marker3.mnum);
      {rmap = pd.rmap;
       graph = pd.graph;
       rcmap = pd.rcmap;
       lmakeup = pd.lmakeup;
       cmakeup = pd.cmakeup;
       lines = pd.lines;
       circs = pd.circs;
       member = pd.member;
       intersect = pd.intersect;
       markers = setadjoin(marker3,pd.markers);
        markedby = extendfunction(
	 extendfunction(pd.markedby, RegionSet(regs1), setadjoin(marker3, pd.markedby(RegionSet(regs1)))),
	 RegionSet(regs2),
	 setadjoin(marker3, pd.markedby(RegionSet(regs2))));
       marks = extendfunction(pd.marks,
			      marker3, 
			      setadjoin(RegionSet(regs1), setadjoin(RegionSet(regs2), 
							       emptyset)))}

let cs_applies(pd, dseg1,dseg2) =
 (* if marked_equal(Dseg(dseg1), Dseg(dseg2), pd) then print_string("me");
  if propersubset(dseg1,dseg2)  then print_string("ps12");
  if propersubset(dseg2,dseg1)  then print_string("ps21"); *) 		
  if (marked_equal(Dseg(dseg1), Dseg(dseg2), pd) &
      (propersubset(dseg1,dseg2) or propersubset(dseg2,dseg1)))
  then true 
  else false;;  

let ca_applies(pd, ang1, ang2) =
if marked_equal(Angle(ang1), Angle(ang2), pd) then print_string("me");
(*  if propersubset(ang1,ang2)  then print_string("ps12");
  if propersubset(ang2,ang1)  then print_string("ps21");
  print_di_angle(ang1);
  print_di_angle(ang2);*)
  if (marked_equal(Angle(ang1), Angle(ang2), pd) &
      (propersubset(ang1,ang2) or propersubset(ang2,ang1)))
  then true 
  else false;;

let cr_applies(pd,regs1,regs2) =
 (* if marked_equal(Dseg(dseg1), Dseg(dseg2), pd) then print_string("me");
  if propersubset(dseg1,dseg2)  then print_string("ps12");
  if propersubset(dseg2,dseg1)  then print_string("ps21"); *) 		
  if (marked_equal(RegionSet(regs1), RegionSet(regs2), pd) &
      (propersubset(regs1,regs2) or propersubset(regs2,regs1)))
  then true 
  else false;; 

let erase_marker(marker,pd) = 
	let newmarkedby = function x ->
		setremove(marker,(pd.markedby)(x)) in
	let newmarks = function x ->
		if x = marker then [] else (pd.marks)(x) in
	  {rmap = pd.rmap;
       graph = pd.graph;
       rcmap = pd.rcmap;
       lmakeup = pd.lmakeup;
       cmakeup = pd.cmakeup;
       lines = pd.lines;
       circs = pd.circs;
       member = pd.member;
       intersect = pd.intersect;
       markers = setremove(marker,pd.markers);
       markedby = newmarkedby;
	   marks = newmarks};;
	
let marker_used(marker,pd) =
	if (pd.marks)(marker) = [] then false else true;;
		     
let erase_unused_markers(pd) =
	let mks = pd.markers in
	let f = function m -> marker_used(m,pd) in
	let used_mks = List.filter f mks in
	  {rmap = pd.rmap;
       graph = pd.graph;
       rcmap = pd.rcmap;
       lmakeup = pd.lmakeup;
       cmakeup = pd.cmakeup;
       lines = pd.lines;
       circs = pd.circs;
       member = pd.member;
       intersect = pd.intersect;
       markers = used_mks;
       markedby = pd.markedby;
	   marks = pd.marks};;

	




(**********************)
(* Construction Tools *)
(**********************)

(* Used to extend lines and circles *)

type goal = DotGoal of dot | FrameGoal | StartDot of dot | SingleExtend | Done;;

let satisfiesgoal(dot, goal) =
  match goal with
      DotGoal(dotgoal) -> if dotgoal = dot then true else false
    | FrameGoal -> if dot.dpos = OnFrame then true else false
    | StartDot(sdot) -> false
    | SingleExtend -> false
    | Done -> true;;

let willsatisfygoal(dot, goal) =
  match goal with
      DotGoal(dotgoal) -> if dotgoal = dot then true else false
    | FrameGoal -> if dot.dpos = OnFrame then true else false
    | StartDot(sdot) -> if sdot = dot then true else false
    | SingleExtend -> false
    | Done -> true;;

let updategoal(goal) = 
  match goal with
      StartDot(sdot) -> DotGoal(sdot)
    | SingleExtend -> Done
    | _ -> goal;;

(* updatearray adds the number of times that the lines/circles *)
(* occur in the array, and returns false if a line count goes over 1, or *)
(* a circle count goes over 2.  Used to check that a given line doesn't *)
(* intersect other lines/circles too many times.  *)
(* the array is now a hashtable instead, since only a few entries are actually used.*)

let intersects_array = Hashtbl.create small_hashsize;;

let poke_array(elt, array) =
	if (Hashtbl.mem array elt)
	then ()
	else
		(Hashtbl.add array elt 0);
		();;
		
let get_from_array(elt,array) =
	poke_array(elt, array);
	(Hashtbl.find array elt);;
	
let array_increment_elt(elt, array) =	
	let oldvalue = Hashtbl.find array elt in
	Hashtbl.replace array elt (oldvalue + 1);;
	
let array_get_and_increment(elt,array) =
	poke_array(elt, array);
	let oldvalue = Hashtbl.find array elt in
	Hashtbl.replace array elt (oldvalue + 1);
	oldvalue;;
	

type except_line =  No_exceptions 
		    | ExceptLine of int 
		    | ExceptPair of (int * int);;

let excepted_index(index,except) =
  match except with
      No_exceptions -> false
    | ExceptLine(int1) -> if index = int1 then true else false
    | ExceptPair(int1,int2) ->
	if (index = int1 or index = int2)
	then true else false;;
	
let find_center(pd,circ) =
	let center= secondcomp(pd.cmakeup(circ)) in
		match center with
			|CDot(c) -> c
			|_-> raise BadInput;;

let rec updatearray(array,obj_list, except,max_line_intersections) =
  match obj_list with
      Line(line)::rest ->
	let index = line.lnum in
	  if excepted_index(index,except) 
	  then updatearray(array,rest,except,max_line_intersections)
	  else 
	    let value = array_get_and_increment(index, array) in
	      if value < max_line_intersections
	      then 
		begin 
		  updatearray(array,rest,except,max_line_intersections) 
		end
		else false
    | Circ(circ)::rest -> 
	let index = circ.cnum in
	  if excepted_index(index,except) 
	  then updatearray(array,rest,except,max_line_intersections)
	  else
	    let value = array_get_and_increment(index, array) in
	      if value < 2
	      then 
		begin 
		  updatearray(array,rest,except,max_line_intersections)
		end
		else false
    | _ -> true;;

(*when first initializing array from a circle, we check 
that we aren't hitting any other circles
with the same center. return false if we are.*)
let rec updatearrayfromcirc(array,obj_list, except,max_line_intersections,pd, newcirc) =
  match obj_list with
      Line(line)::rest ->
	let index = line.lnum in
	  if excepted_index(index,except) 
	  then updatearray(array,rest,except,max_line_intersections)
	  else 
	    let value = array_get_and_increment(index, array) in
	      if value < max_line_intersections
	      then 
		begin 
		  updatearrayfromcirc(array,rest,except,max_line_intersections,pd,newcirc)
		end
		else false
    | Circ(circ)::rest -> 
	let index = circ.cnum in
	  if excepted_index(index,except) 
	  then updatearray(array,rest,except,max_line_intersections)
	  else
	  if find_center(pd, newcirc) = find_center(pd, circ) then false
	  else
	    let value = array_get_and_increment(index, array) in
	      if value < 2
	      then 
		begin 
		  updatearrayfromcirc(array,rest,except,max_line_intersections,pd,newcirc)
		end
		else false
    | _ -> true;;

let rec intersectokline(linelist, intersectsmap,array,except,container) =
  let max_lint = 
    match container with
	Line(dline) -> 1
      | Circ(circ) -> 2
      | _ -> 0 in
    match linelist with
	Dot(dot)::rest ->
	  if updatearray(array,intersectsmap(dot),except,max_lint)
	    (*haven't exceeded bounds yet*)
	  then intersectokline(rest,intersectsmap,array,except,container)
	  else false
      | Seg(seg)::rest ->
	  intersectokline(rest,intersectsmap,array,except,container)
      | [] -> true;;


let unsafetohitdotnormally(pd,container,newdot) =
  if isframedot(newdot)
  then true
  else
  (Hashtbl.clear intersects_array;
  let max_lint = 
    match container with
	Line(dline) -> 1
      | Circ(circ) -> 2
      | _ -> raise BadInput in  
  let ilist = pd.intersect(newdot) in
    begin
      (ignore (updatearray(intersects_array,ilist,No_exceptions,max_lint)));
      let line_index = 
	match container with 
	    Line(dline) -> dline.lnum
	  | Circ(circ) -> circ.cnum
	  | _ -> raise BadInput in
      let makeup = 
	match container with
	    Line(dline) -> pd.lmakeup(dline)
	  | Circ(circ) -> firstcomp(pd.cmakeup(circ))
	  | _ -> raise BadInput in
	if get_from_array(line_index, intersects_array) > 0 (*if the line already hit the dot *)
	then true
	else 
	  not(intersectokline(makeup,
			      pd.intersect,intersects_array,
			      ExceptLine(line_index),
			      container));
    end);;


let unsafetohitdotnormallywcirc(pd,container, circ,center,newdot) =
  if isframedot(newdot)
  then true
  else
  (Hashtbl.clear intersects_array;
  let max_lint = 2 in
  let ilist = pd.intersect(newdot) in
    begin
      if updatearrayfromcirc(intersects_array,ilist,No_exceptions,max_lint,pd,circ) 
	  then
      let line_index = circ.cnum in
	  let makeup = firstcomp(pd.cmakeup(circ)) in
		begin
		if get_from_array(line_index, intersects_array) > 0 (*if the line already hit the dot *)
		then true
		else 
			not(intersectokline(makeup,
					pd.intersect,intersects_array,
					ExceptLine(line_index),
					container))
		end;
	  else true
    end);;



let unsafetohitdot(pd,container,newdot,goal) =
  match container with
      Line(dline) -> unsafetohitdotnormally(pd,container,newdot)
    | Circ(circ) -> 
	if willsatisfygoal(newdot,goal)
	then false
	else
	  let center= secondcomp(pd.cmakeup(circ)) in
	    (match center with
		CDot(cdot) ->
		  if newdot = cdot 
		  then true
		  else
		    unsafetohitdotnormallywcirc(pd,container, circ,center,newdot)
		| _ -> raise BadInput)
    | _ -> raise BadInput;;
    
let unsafetohitsegwithline(pd,dline,seg,goal) =
  Hashtbl.clear intersects_array;
  let line_index = dline.lnum in
  let container = pd.member(seg) in
    match container with
	Line(line) ->
	  let index = line.lnum in
	    begin
	      if index = line_index then true 
	      else
		(Hashtbl.add intersects_array index 1;
		 not(intersectokline(pd.lmakeup(dline),
				     pd.intersect,intersects_array,
				     ExceptLine(line_index),
				     Line(dline))))
	    end
      | Circ(circ) ->
	  let index = circ.cnum in
	    begin
		(Hashtbl.add intersects_array index 1;
		 not (intersectokline(pd.lmakeup(dline),
				      pd.intersect,intersects_array,
				      ExceptLine(line_index),
				      Line(dline))))
	    end
      | _ ->  (* when hitting frame *)
	  (match goal with
	       FrameGoal -> false
	     | _ -> true);;

let unsafetohitsegwithcirc(pd,circ,seg) =
   Hashtbl.clear intersects_array;
  let circ_index = circ.cnum in
  let container = pd.member(seg) in
    match container with
	Line(line) ->
	  let index = line.lnum in
	    begin
		(Hashtbl.add intersects_array index 1;
		 not(intersectokline(firstcomp(pd.cmakeup(circ)),
				     pd.intersect,intersects_array,
				     ExceptLine(circ_index),
				     Circ(circ))))
	    end
      | Circ(hitcirc) ->
	  let hitcenter = find_center(pd,hitcirc) in
	  let ocenter = find_center(pd, circ) in
	  if ocenter =hitcenter then true else
	  let index = hitcirc.cnum in
	    begin
	      if index = circ_index then true 
	      else
		(Hashtbl.add intersects_array index 1;
		 not (intersectokline(firstcomp(pd.cmakeup(circ)),
				      pd.intersect,intersects_array,
				      ExceptLine(circ_index),
				      Circ(circ))))
	    end
      | _ -> true;; (*since circles can't hit frame *)



let unsafetohitseg(pd,oldcontainer,seg,goal)=
  match oldcontainer with
      Line(dline) -> unsafetohitsegwithline(pd,dline,seg,goal)
    | Circ(circ) -> unsafetohitsegwithcirc(pd,circ,seg)
    | _ -> raise BadInput;;

type calledfrom = OI | IO;;

(* split returns a pair of lists; the first contains elements from elt1 to *)
(* elt2 in list, and the second contains elements from elt2 to elt1 in list *)
(* when list is viewed circularly. elt1 and elt2 are left out of both lists. *)

let rec split(list,elt1,elt2)=
	split1(double(list),elt1,elt2)
and  split1(list,elt1,elt2)=
  match list with
      first::rest when (first = elt1) ->
		split2(rest,elt1,elt2)
    | first::rest -> split1(rest,elt1,elt2)
    | _ -> raise BadInput
and split2(list,elt1,elt2) =
  match list with
      first::rest when (first = elt2) ->
	([],split3(rest,elt1))
    | first::rest -> cons1(first,split2(rest,elt1,elt2))
    | _ -> raise BadInput
and split3(list,elt) =
  match list with
      first::rest when (first = elt) -> []
    | first::rest -> first::split3(rest,elt)
    | _ -> raise BadInput;;


(*tsplit splits the given list into two lists, separated by elt2 and *)
(* elt4, in the spots in the given list where there are surrounded by the *)
(* other given elements. *)

let rec tsplit(list,edot1,edot2)=
  match (edot1,edot2) with
      (DT(elt1e,elt2,elt3e),DT(elt4e,elt5,elt6e)) ->
	let (elt1,elt3,elt4,elt6) = 
	  (sse2seg(elt1e),sse2seg(elt3e),sse2seg(elt4e),sse2seg(elt6e)) in
	(match list with
	     Seg(eltA)::Dot(eltB)::Seg(eltC)::rest when 
	       (eltA = elt1) & (eltB = elt2) & (eltC = elt3) ->
		 cons1(Dot(elt2),
		       tsplit2(Seg(elt3)::rest,
			       (Seg(elt1),Dot(elt2),Seg(elt3)),
			       (Seg(elt4),Dot(elt5),Seg(elt6))))
	   | first::rest -> tsplit(rest,edot1,edot2)
	   | _ -> raise BadInput)
    | (SingDot(dot1),SingDot(dot2)) -> ([Dot(dot1)],[Dot(dot2)])
    | _ -> raise BadInput  (* shouldn't happen since this is called when *)
	  (*joining dots both on boundry or in a single component*)
and tsplit2(list,(elt1,elt2,elt3),(elt4,elt5,elt6))=
  match list with
      eltA::eltB::eltC::rest when 
	(eltA = elt4) & (eltB = elt5) & (eltC = elt6) ->
	([eltA;eltB],tsplit3(eltB::eltC::rest,(elt1,elt2,elt3)))
    | first::rest -> cons1(first,tsplit2(rest,
					 (elt1,elt2,elt3),
					 (elt4,elt5,elt6)))
    | _ -> raise BadInput
and tsplit3(list,(elt1,elt2,elt3))=
  match list with
      eltA::eltB::eltC::rest when 
	(eltA = elt1) & (eltB = elt2) & (eltC = elt3) ->
	  [elt1;elt2]
    | first::rest -> first::tsplit3(rest,(elt1,elt2,elt3))
    | _ -> raise BadInput;;

let rec rotateto(list,edot)=
  match edot with
      DT(elt1e,elt2,elt3e) ->
	let (elt1,elt3) = (sse2seg(elt1e),sse2seg(elt3e)) in
	(match list with
	    Seg(eltA)::Dot(eltB)::Seg(eltC)::rest when 
	      (eltA = elt1) & (eltB = elt2) & (eltC = elt3) ->
		Dot(elt2)::rotateto2(Seg(elt3)::rest,
				     (Seg(elt1),Dot(elt2),Seg(elt3)))
	  | first::rest -> rotateto(rest,edot)
	  | _ -> raise BadInput)
    | SingDot(dot) -> 
	[Dot(dot)]
and rotateto2(list,(elt1,elt2,elt3))=
  match list with
      eltA::eltB::eltC::rest when 
	(eltA = elt1) & (eltB = elt2) & (eltC = elt3) -> [eltA;eltB]
    | first::rest -> first::rotateto2(rest, (elt1,elt2,elt3))
    | _ -> raise BadInput;;


let rec simple_rotate_to(list,elt) =
	match list with
		first::rest ->
			if first = elt then list
			else 
				simple_rotate_to(rest@[first],elt)
		|_ -> raise BadInput;;


let rec rep_reg(ereg,newregl, inclist) = 
  match ereg with
      RT(seg1,reg,seg2) -> sing_rep_reg((DSSeg(seg1),Reg(reg),DSSeg(seg2)),
					newregl,inclist)
    | SingReg(reg) ->   
	(match (inclist,newregl) with
	    (Reg(oldregion)::[],[Reg(newreg1);DSSeg(newseg);Reg(newreg2)])
	    when oldregion = reg & newreg1 = newreg2 ->
	      [Reg(newreg1);DSSeg(newseg)]
		(*|(Reg(oldregion)::[],[Reg(newreg1);DSSeg(newseg);Reg(newreg2)]) -> 
			(* newreg1 != newreg2 if we are returning to the original dot; in this case,
			this gets ignored. *)
			[Reg(reg);DSSeg(newseg)]
		|   (Reg(oldregion)::[],[Reg(newreg1);DSSeg(newseg);Reg(newreg2);DSSeg(newseg2);Reg(newreg3)])
	    when oldregion = reg & newreg1 = newreg3 ->
	      [Reg(newreg1);DSSeg(newseg);Reg(newreg2);DSSeg(newseg2)]
		  (* for when a single dot returns to itself; this is still broken *) *)
		| _ -> raise BadInput)	
and sing_rep_reg((seg1,reg,seg2),newregl,inclist) = 
  match inclist with
      first::second::rest when (first=reg & second = seg2) ->
	if lastelt(inclist) = seg1 
	then rec_rep_reg((seg1,reg,seg2),newregl,append(newregl,second::rest))
	else rec_rep_reg((seg1,reg,seg2),newregl,inclist)
    | first::rest when first = seg2 ->
	firstmatch_rec_rep_reg((seg1,reg,seg2),newregl,inclist)
    |_ -> rec_rep_reg((seg1,reg,seg2),newregl,inclist)
and rec_rep_reg((seg1,reg,seg2),newregl,inclist) = 
  match inclist with
      first::second::third::rest-> 
	if (first = seg1 & second = reg & third = seg2)
	then first:: append(newregl,rec_rep_reg((seg1,reg,seg2),newregl,
						third::rest))
	else first::rec_rep_reg((seg1,reg,seg2),newregl,second::third::rest)
    | _ -> inclist
and  firstmatch_rec_rep_reg((seg1,reg,seg2),newregl,inclist) = 
  match inclist with
      first::second::third::rest-> 
	if (first = seg1 & second = reg & third = seg2)
	then first:: append(newregl,firstmatch_rec_rep_reg((seg1,reg,seg2),
							   newregl,third::rest))
	else first::firstmatch_rec_rep_reg((seg1,reg,seg2),
					   newregl,second::third::rest)
    | first::second::[] -> 
	if (first = seg1 & second = reg)
	then first::newregl
	else first::[second]
    | _ -> raise BadInput;;


type orientation = Forward | Reverse;;


(* fix_regions fixes the regions around dot in inclist when region is split into 2 pieces:
newregion1 and newregion2, replacing region by newregion1 if dot occurns in firsthalf, 
region2 otherwise.  Orientation is always Reverse to begin with.  *)
let rec fix_regions(region,newregion1,newregion2,
		    firsthalf,inclist,dot,orient) =
  match inclist with
      first::second::[]  ->
	if second = Reg(region)
	then
	  match first with
	      DSSeg(fseg) ->
		if circ_occurs(Seg(sse2seg(fseg)),Dot(dot),Seg(sse2seg(fseg)),
			       firsthalf) 
		then first::Reg(newregion1)::[]
		else first::Reg(newregion2)::[]
	    | _ -> raise BadInputList
	else if first=Reg(region)
	then
	  match second with
	      DSSeg(sseg) ->
		if circ_occurs(Seg(sse2seg(sseg)),Dot(dot),Seg(sse2seg(sseg)),
			       firsthalf) 
		then Reg(newregion1)::second::[]
		else Reg(newregion2)::second::[]
	    | _ -> raise BadInputList
	else inclist
	| Reg(reg)::[] -> 
		if reg = region
		then Reg(newregion2)::[]
		else inclist  (*changed 5/12/2010 to match that all occurences of
		region get changed, even inside a component; distribute innards now
		expects this.*)
    | first::[] -> inclist
    | first::second::rest when (first=Reg(region)) ->
	let last = lastelt(rest) in
	if 
	  match orient with 
	      Reverse -> circ_occurs(ds2v_seg(second),Dot(dot),ds2v_seg(last),
				     firsthalf) 
	    | Forward -> circ_occurs(ds2v_seg(last),Dot(dot),ds2v_seg(second),
				     firsthalf) 
	then rec_fix_regions(region,newregion1,newregion2,firsthalf,
			     Reg(newregion1)::second::rest,dot,first,orient)
	else rec_fix_regions(region,newregion1,newregion2,firsthalf,
			     Reg(newregion2)::second::rest,dot,first,orient)
    | first::rest  ->
	rec_fix_regions(region,newregion1,newregion2,firsthalf,
			inclist,dot,first,orient)
    | _ -> raise BadInputList
and rec_fix_regions(region,newregion1,newregion2,firsthalf,
		    inclist,dot,origfirst,orient) =
  match inclist with
      first::Reg(reg)::third::rest -> 
	if (reg=region)
	then 
	  if 
	    match orient with 
		Reverse -> circ_occurs(ds2v_seg(third),Dot(dot),ds2v_seg(first),
				       firsthalf) 
	      | Forward -> circ_occurs(ds2v_seg(first),Dot(dot),ds2v_seg(third),
				       firsthalf) 
	  then first::Reg(newregion1)::rec_fix_regions(region,
						       newregion1,
						       newregion2,
						       firsthalf,
						       third::rest,
						       dot,
						       origfirst,
						       orient)
	  else first::Reg(newregion2)::rec_fix_regions(region,
						       newregion1,
						       newregion2,
						       firsthalf,
						       third::rest,
						       dot,
						       origfirst,
						       orient)
	else first::Reg(reg)::rec_fix_regions(region,
					       newregion1,
					       newregion2,
					       firsthalf,
					       third::rest,
					       dot,
					       origfirst,
					       orient)

    | first::second::[] -> 
	if second=Reg(region)
	then 
	  if
	    match orient with 
		Reverse -> circ_occurs(ds2v_seg(origfirst),Dot(dot),
				       ds2v_seg(first),
				       firsthalf) 
	      | Forward -> circ_occurs(ds2v_seg(first),Dot(dot),
				       ds2v_seg(origfirst),
				       firsthalf) 
	  then first::Reg(newregion1)::[]
	  else first::Reg(newregion2)::[]
	else inclist
    | first::rest -> 
	first::rec_fix_regions(region,newregion1,newregion2,firsthalf,
				rest,dot,origfirst,orient)
    | _ -> inclist;;

(* fix_segs replaces oldseg by newseg1,newdot,newseg2, placing newseg1 on *)
(* the side of newdot that olddot1 is on.  If olddot1=olddot2, then *)
(* they occur in the order newseg1, newdot,newseg2.  So it is important *)
(* that seg1/seg2 be given in the right order if called on a loop *)
let rec fix_segs(oldseg,newseg1,newseg2,olddot1,olddot2,newdot,list) =
  match list with
      first::second::[]  ->
	if second = Seg(oldseg)
	then
	  [Dot(olddot1);Seg(newseg1);Dot(newdot);Seg(newseg2)]
	else if first=Seg(oldseg)
	then
	  [Seg(newseg1);Dot(newdot);Seg(newseg2);Dot(olddot1)]
	else list
    | first::[] -> list
    | first::second::rest when (first=Seg(oldseg)) ->
	if second = Dot(olddot2)
	then Seg(newseg1)::Dot(newdot)::Seg(newseg2)::
	  rec_fix_segs(oldseg,newseg1,newseg2,olddot1,olddot2,newdot,
		       second::rest)
	else Seg(newseg2)::Dot(newdot)::Seg(newseg1)::
	  rec_fix_segs(oldseg,newseg1,newseg2,olddot1,olddot2,newdot,
		       second::rest)
    | first::rest  ->
	  rec_fix_segs(oldseg,newseg1,newseg2,olddot1,olddot2,newdot,
		       list)
    | _ -> list (*fixed 5/5/2010 *)
and rec_fix_segs(oldseg,newseg1,newseg2,olddot1,olddot2,newdot,list)=
  match list with
      first::Seg(seg)::third::rest -> 
	if (seg=oldseg)
	then 
	  if first= Dot(olddot1)
	  then Dot(olddot1)::Seg(newseg1)::Dot(newdot)::Seg(newseg2)::
	  rec_fix_segs(oldseg,newseg1,newseg2,olddot1,olddot2,newdot,
		       third::rest)
	  else Dot(olddot2)::Seg(newseg2)::Dot(newdot)::Seg(newseg1)::
	  rec_fix_segs(oldseg,newseg1,newseg2,olddot1,olddot2,newdot,
		       third::rest)
	else first::Seg(seg)::
	  rec_fix_segs(oldseg,newseg1,newseg2,olddot1,olddot2,newdot,
		       third::rest)

    | first::second::[] -> 
	if second=Seg(oldseg)
	then 
	  if first = Dot(olddot1)
	  then first::Seg(newseg1)::Dot(newdot)::Seg(newseg2)::[]
	  else first::Seg(newseg2)::Dot(newdot)::Seg(newseg1)::[]
	else list
    | first::rest -> 
	first::rec_fix_segs(oldseg,newseg1,newseg2,olddot1,olddot2,newdot,rest)
    | _-> list;;


let rec fix_segs_listset(oldseg,newseg1,newseg2,olddot1,olddot2,newdot,set) =
  match set with 
      first::rest -> 
	fix_segs(oldseg,newseg1,newseg2,olddot1,olddot2,newdot,first)::
	fix_segs_listset(oldseg,newseg1,newseg2,olddot1,olddot2,newdot,rest)
    | _ -> [];;

let sameline((edge1,edgeA),(edge2,edgeB)) = 
  if (edge1 = edge2) or (edge1 = edgeB)
  then true
  else false;;


(* checks for tangency of the line going through (edge1 and edgeA) with *)
(* the line going through (edge2 and edgeB); if they are the same line, *)
(* returns false *)
let rec tangent((edge1,edgeA), (edge2,edgeB), sinclist) =
  rec_tangent(edge1,edgeA, edge2,edgeB, append(sinclist,sinclist))
and rec_tangent(edge1,edgeA, edge2,edgeB, db_list) =
  if sameline((edge1,edgeA),(edge2,edgeB)) then false (* only one line *)
  else 
    match db_list with
	first::rest -> 
	  if first = edge1
	  then rec_tangent2(edgeA, edge2, edgeB, rest, 0)
	  else rec_tangent(edge1, edgeA, edge2, edgeB, rest)
      | _ -> raise BadIncList
and rec_tangent2(edgeA, edge2, edgeB, db_list, counter) =
  match db_list with
      first::rest -> 
	if first = edgeA
	then if ((counter = 0) or (counter = 2)) then true else false
	else 
	  if ((first = edge2) or (first = edgeB)) 
	  then rec_tangent2(edgeA, edge2, edgeB, rest, (counter + 1))
	  else  rec_tangent2(edgeA, edge2, edgeB, rest, counter)
    | _ -> raise BadIncList;;
	




let lineedge(sse) =
  if (sse2seg(sse)).ssty = Solid then true else false;;

let circedge(sse) =
  if (sse2seg(sse)).ssty = Dotted then true else false;;


(* cw_edge finds the segment cw from the given segment in the given list; *)
(* if there isn't one, it returns the given segment. *)

let rec cw_edge(seg,sinclist) =
  match sinclist with
      first::rest -> rec_cw_edge(seg,sinclist,first)
    | _ -> raise BadIncList
and rec_cw_edge(seg,sinclist,orig_first) =
  match sinclist with
      first :: second :: rest -> 
	if first=seg then second else rec_cw_edge(seg,second::rest,orig_first)
    | first :: [] -> if first =seg then orig_first else raise BadIncList
    | _ -> raise BadIncList;;

(* opp_seg returns the opposite segment (i.e., the extension of the line) if 
there is one; otherwise, it returns the given segment *)
let rec opp_seg(seg, sinclist, makeupmap) =
  let line = makeupmap(sse2seg(seg)) in
    match sinclist with
	first :: rest -> 
	  if first = seg 
	  then opp_seg(seg, rest, makeupmap) 
	  else 
	    if makeupmap(sse2seg(first)) = line 
	    then first
	    else opp_seg(seg, rest, makeupmap)
      | _ -> seg;;

let has_opp(sse,sinclist,makeupmap) =
  let opp = opp_seg(sse,sinclist,makeupmap) in
    if opp = sse then false else true;;

type lineflag = NoLineYet | PossibleLine | TangentToLine
type ls = LineSeen | NoLineSeen;;


(* inner_tang finds the last edge on the ccw side of edge that is definitely *)
(* tangent to it. *)
let rec inner_tang(edge,opp_edge,sinclist,makeupmap) =
  rec_inner_tang(edge,opp_edge,edge,List.rev(sinclist),makeupmap,
		 if lineedge(edge) then TangentToLine else NoLineYet)
and rec_inner_tang(edge,opp_edge,current_seg,sinclist,makeupmap,lf) =
  let next = cw_edge(current_seg,sinclist) in
  let opposite = opp_seg(next,sinclist,makeupmap) in
    if (opposite = next) (* i.e., next has no opposite *)
    then 
      let newlf = 
	if lineedge(next) then
	  match lf with NoLineYet -> PossibleLine | _ -> lf 
	else lf in
      rec_inner_tang(edge,opp_edge,next,sinclist,makeupmap,newlf)
    else 
      if tangent((edge,opp_edge),(next,opposite),sinclist)
      then 
      let newlf = 
	if lineedge(next) then TangentToLine
	else match lf with PossibleLine -> TangentToLine | _ -> lf in
	rec_inner_tang(next,opposite,next,sinclist,makeupmap,newlf)
      else 
	let ls =
	  match lf with
	      NoLineYet -> NoLineSeen
	    | PossibleLine -> NoLineSeen
	    | TangentToLine -> LineSeen in
	  (edge,ls);;
(* This is guaranteed to terminate (on correct inputs)  since edge *)
(* and opp_edge should be opposite and not tangent.  *)
      





(* (c)cw_extension_edge returns the extension of the next line of the *)
(* (c)cw side of the given segment that has such an extension, *)
(* and then the last edge on that side that is tangent to it. *)
let rec cw_extension_edge(sinclist, makeupmap, segment, initial_seg) =
  let next = cw_edge(segment,sinclist) in
  let opposite = opp_seg(next, sinclist, makeupmap) in
    if (opposite = next) (* i.e., if next has no opposite edge *)
    then 
      if (next = initial_seg) (* i.e., we've gone all the way around *)
      then (initial_seg, initial_seg, (initial_seg,NoLineSeen)) 
      else cw_extension_edge(sinclist, makeupmap, next, initial_seg)
    else (opposite, next, inner_tang(opposite,next,sinclist,makeupmap));;

let ccw_extension_edge(sinclist, makeupmap, segment, initial_seg) =
  cw_extension_edge(List.rev(sinclist), makeupmap, segment, initial_seg);;

let extension_edges(sinclist, makeupmap, segment) =
   (cw_extension_edge(sinclist, makeupmap, segment, segment),
   ccw_extension_edge(sinclist, makeupmap, segment, segment));;

let rec cwtangextensions(db_inclist,edge,ls,sinclist,makeupmap,seg) = 
  match db_inclist with
      DSSeg(sse)::rest when sse = edge ->
	cwtangext2(db_inclist,ls,sinclist,makeupmap,seg)
    | first::rest -> cwtangextensions(rest,edge,ls,sinclist,makeupmap,seg)
    | _ -> raise BadInput
and cwtangext2(db_inclist,ls,sinclist,makeup,seg) =
  match db_inclist with
      DSSeg(sse)::Reg(reg)::DSSeg(sse2)::rest ->
	(match ls with
	    LineSeen ->
	      [RI(sse,reg,sse2)]
	  | NoLineSeen ->
	      if ((has_opp(sse2,sinclist,makeup)) or sse2 = seg)
	      then [RI(sse,reg,sse2)]
	      else RI(sse,reg,sse2)::SI(sse2seg(sse2))::
		cwtangext2(DSSeg(sse2)::rest,ls,sinclist,makeup,seg))
    | _ -> raise BadInput;;

let rec ccwtangextensions(list,edge,ls,sinclist,makeup,seg) =
  List.map reiflip 
    (cwtangextensions(List.rev(list),edge,ls,sinclist,makeup,seg));;



(* gets the first sse occuring between the given edges in the sinclist, *)
(* if there is one. *)
let rec get_between_segs(edge1,edge2,sinclist) =
  match sinclist with
      first::rest when first = edge1 ->
	(match rest with
	     r1::rrest ->
	       if r1 = edge2 then [] else [SI(sse2seg(r1))]
	   | _ -> raise BadInput)
    | first::rest ->
	get_between_segs(edge1,edge2,rest)
    | _ -> raise BadInput;;



(* The viable extensions functions find those elements in the inc. list that
occur between edge1 and edge2 on the side that doesn't include the given
segment.  The first function locates the segment in the given list, the second
locates the one of edge1 or edge2 that comes next in cw order, and then the
third function outputs the segments and regions that occur after this edge
but before the other in cw order. *)

let rec viable_extensions(inclist,makeupmap,segment) =
  List.flatten(viable_extensions1(inclist,makeupmap,segment))
and viable_extensions1(inclist, makeupmap, segment) =
  let sinclist = segextract(inclist) in
  let ((edge1,edgeA,(inneredge1,ls1)),(edge2, edgeB,(inneredge2,ls2))) = 
    extension_edges(sinclist, makeupmap, segment)
  in
    if edge1 = segment 
    then  
      [rec_viable_extensions2(double(inclist), edge1, edge2,
			      sinclist,makeupmap)]
    else if  sameline((edge1,edgeA),(edge2,edgeB))
    then
      if lineedge(segment)
      then 
	match ls1 with
	    LineSeen -> (* Line hitting line *)
	      [rec_viable_extensions2(double(inclist),inneredge2,inneredge1,
				      sinclist,makeupmap)]
	  | NoLineSeen ->  (* Line hitting circles *)
	      [rec_viable_extensions2(double(inclist),inneredge2,inneredge1,
				      sinclist,makeupmap);
	       ccwtangextensions(double(inclist),edge2,LineSeen,
				sinclist,makeupmap,segment);
	       cwtangextensions(double(inclist),edge1,LineSeen,
				 sinclist,makeupmap,segment)]
	else 
	  match ls1 with
	      LineSeen ->  (* Circle hitting lines *)
		[rec_viable_extensions2(double(inclist),inneredge2,inneredge1,
					sinclist,makeupmap);
		 ccwtangextensions(double(inclist),edge2,LineSeen,
				  sinclist,makeupmap,segment);
		 cwtangextensions(double(inclist),edge1,LineSeen,
				   sinclist,makeupmap,segment)]
	    | NoLineSeen -> (*Circle hitting circles *)
		[rec_viable_extensions2(double(inclist),inneredge2,inneredge1,
					sinclist,makeupmap);
		 ccwtangextensions(double(inclist),edge2,NoLineSeen,
				  sinclist,makeupmap,segment);
		 cwtangextensions(double(inclist),edge1,NoLineSeen,
				   sinclist,makeupmap,segment)]
    else if  tangent((edge1,edgeA), (edge2,edgeB), sinclist)
    then
      if lineedge(segment) 
      then 
	if (ls1 = LineSeen or ls2=LineSeen) 
	then [] (* so lines won't be tangent *)
	else
	  let between_segs = get_between_segs(edge1,edge2,double(sinclist)) in
	    match between_segs with 
		[] -> [rec_viable_extensions2(double(inclist),edge1,edge2,
					      sinclist,makeupmap)]
	      | _ -> [between_segs]
      else (* a circle coming in *)  
	[rec_viable_extensions2(double(inclist),edge1,edge2,
				    sinclist,makeupmap)]
    else (* if they aren't tangent *)
      if (circedge(segment))
      then 
	 [rec_viable_extensions2(double(inclist),inneredge2,inneredge1,
				       sinclist,makeupmap);
		cwtangextensions(double(inclist),edge1,ls1,
				 sinclist,makeupmap,segment);
		ccwtangextensions(double(inclist),edge2,ls2,
				  sinclist,makeupmap,segment)]
      else (* segment is a line *)
	match (ls1,ls2) with
	    (NoLineSeen,NoLineSeen) ->
	      [rec_viable_extensions2(double(inclist),inneredge2,inneredge1,
				      sinclist,makeupmap);
	       cwtangextensions(double(inclist),edge1,LineSeen,
				sinclist,makeupmap,segment);
	       ccwtangextensions(double(inclist),edge2,LineSeen,
				 sinclist,makeupmap,segment)]
	  | (NoLineSeen,LineSeen) ->
	      [rec_viable_extensions2(double(inclist),inneredge2,inneredge1,
				      sinclist,makeupmap);
	       cwtangextensions(double(inclist),edge1,LineSeen,
				sinclist,makeupmap,segment)]
	  | (LineSeen,NoLineSeen) ->
	      [rec_viable_extensions2(double(inclist),inneredge2,inneredge1,
				      sinclist,makeupmap);
	       ccwtangextensions(double(inclist),edge2,LineSeen,
				 sinclist,makeupmap,segment)]
	  | (LineSeen,LineSeen) ->
	    [rec_viable_extensions2(double(inclist),inneredge2,inneredge1,
				    sinclist,makeupmap)]
and rec_viable_extensions2(db_inclist, edge1, edge2,sinc,makeup) =
  match db_inclist with
      DSSeg(firstseg)::rest ->
	if (firstseg = edge1) 
	then rec_viable_extensions3(db_inclist, edge2,sinc,makeup)
	else rec_viable_extensions2(rest, edge1, edge2,sinc,makeup)
    | first :: rest ->  rec_viable_extensions2(rest, edge1, edge2,sinc,makeup)
    | _ -> raise BadIncList
and rec_viable_extensions3(db_inclist, finish,sinclist,makeup) =
  match db_inclist with
      DSSeg(seg)::Reg(reg)::DSSeg(seg2)::rest ->
	if seg2 = finish 
	then [RI(seg,reg,seg2)]
	else 
	  if not(has_opp(seg2,sinclist,makeup))
	  then
	    RI(seg,reg,seg2)::SI(sse2seg(seg2))::
	    rec_viable_extensions3(DSSeg(seg2)::rest,finish,sinclist,makeup)
	  else
	    RI(seg,reg,seg2)::
	    rec_viable_extensions3(DSSeg(seg2)::rest,finish,sinclist,makeup)
    | _ -> raise BadIncList;;      


let rec between_in_dslist(db_inclist, edge1, edge2) =
  match db_inclist with
      DSSeg(firstseg)::rest ->
	if (firstseg = edge1) 
	then bid2(rest, edge2)
	else between_in_dslist(rest,edge1,edge2)
    | first :: rest ->  between_in_dslist(rest, edge1, edge2)
    | _ -> raise BadInput
and bid2(db_inclist, finish) =
  match db_inclist with
      first::rest ->
	if first = DSSeg(finish) 
	then []
	else first::bid2(rest,finish)
    | _ -> raise BadInput;;      



(**********************)
(* Search Algorithm   *)
(**********************)

(* We search through the whole diagram to determine
cw / ccw orientation of circles and triangles. *)

let rec initializearray(list,array) =
  match list with
      Seg(seg)::rest ->
		Hashtbl.add array (seg.snum) true;
		initializearray(rest,array)
    | Dot(dot)::rest -> 
		Hashtbl.add array (dot.dnum) true;
		initializearray(rest,array)
    | [] -> ();;


open Queue;;

exception HitOutside;;

type search_obj = SDot of dot | SSeg of segment | SReg of region;;

let search_array = Hashtbl.create small_hashsize

let add_reg(reg,queue,array) =
  add (SReg(reg)) queue;
  Hashtbl.add array (reg.rnum) true;;
  
let regionseen(reg,array) = 
	Hashtbl.mem array reg.rnum

let check_and_add_reg(pd,reg,dot,queue,array) =
  let rnum = reg.rnum in
    if 
	(Hashtbl.mem array rnum) then () 
    else 
      if edge_elt(dot,pd,reg)
      then 
	(add (SReg(reg)) queue;
	 Hashtbl.add array rnum true;)
      else raise HitOutside;;

let add_seg(seg,queue,array) =
  let snum = seg.snum in
    if (Hashtbl.mem array snum) then ()
    else
      (add (SSeg(seg)) queue;
       Hashtbl.add array snum true;);;

let add_dot(dot,queue,array) =
  let dnum = dot.dnum in
    if (Hashtbl.mem array dnum) then ()
    else
      (add (SDot(dot)) queue;
       Hashtbl.add array dnum true;);;

let rec add_dslist(list,queue,array) =
  match list with
      DSSeg(sse) :: rest -> 
	(add_seg(sse2seg(sse),queue,array);
	 add_dslist(rest,queue,array))
    | Reg(reg):: rest ->
	(add_reg(reg,queue,array);
	 add_dslist(rest,queue,array))
    | [] -> ();;

let rec add_delist(list,queue,array) =
  match list with
      Seg(seg) :: rest -> 
	(add_seg(seg,queue,array);
	 add_delist(rest,queue,array))
    | Dot(dot):: rest ->
	(add_dot(dot,queue,array);
	 add_delist(rest,queue,array))
    | [] -> ();;



let rec add_delists(lists,queue,array) =
  match lists with
      first::rest ->
	add_delist(first,queue,array);
	add_delists(rest,queue,array)
    | _ -> ();;

let rec safe_add_dslist(pd,list,dot,queue,array) =
  match list with
      DSSeg(sse) :: rest -> 
	(add_seg(sse2seg(sse),queue,array);
	 safe_add_dslist(pd,rest,dot,queue,array))
    | Reg(reg):: rest ->
	(check_and_add_reg(pd,reg,dot,queue,array);
	 safe_add_dslist(pd,rest,dot,queue,array))
    | [] -> ();;


let rec add_eilist(pd,eilist,q,array) =
  match eilist with
      DI(sse1,dot,sse2)::rest ->
	let dslist =
	  between_in_dslist(double((pd.graph.inc)(dot)),
			    sse2, sse1) in
	  safe_add_dslist(pd,dslist,dot,q,array);
	  add_eilist(pd,rest,q,array)
    | first::rest-> add_eilist(pd,rest,q,array)
    | _ -> ()

let initializequeue(pd,list,queue,array) =
  match list with
      Seg(seg)::[] ->
	(match ((pd.graph).emap)(seg) with
	     Loop(innerreg,outerreg) ->
	       add_reg(innerreg,queue,array)
	   | _ -> raise BadInput)
    |Seg(seg)::Dot(dot)::[] ->
	let newlist = 
	  between_in_dslist(double((pd.graph.inc)(dot)),
				 Plain(seg),
				 Returning(seg)) in
	  safe_add_dslist(pd, newlist,dot, queue,array)
    | Dot(dot)::Seg(seg)::[] -> 
	let newlist = 
	  between_in_dslist(double((pd.graph.inc)(dot)),
				 Plain(seg),
				 Returning(seg)) in
	  safe_add_dslist(pd, newlist, dot, queue,array)
    | first::second::third::rest ->
	let eilist = dEIify(list,Out,pd) in 
	  add_eilist(pd,eilist,queue,array)
    | _  -> raise BadInput;;

let rec bf_search(pd,queue,array) = 
  try
    match take queue with
	SSeg(seg) ->
	  (match pd.graph.emap(seg) with 
	       DotPair(dot1,dot2) ->
		 add_dot(dot1,queue,array);
		 add_dot(dot2,queue,array);
		 bf_search(pd,queue,array)
	     | Loop(innerreg,outerreg) ->
		 add_reg(innerreg,queue,array);
		 bf_search(pd,queue,array)
	     | _ -> raise BadInput)
      | SDot(dot) ->
	  safe_add_dslist(pd,(pd.graph.inc)(dot),dot,queue,array);
	  bf_search(pd,queue,array)
      | SReg(reg) -> 
	  add_delists((pd.rcmap(reg)).int_bd_list,queue,array);
	  bf_search(pd,queue,array)
  with Empty -> ();;

(* this checks the circle made up of pieces in list *)
(* to make sure that 1) the list goes in cw order *)
(* (to eliminate duplicating all circles), and that *)
(* the center dot is inside it. *)
let centerinsideofcwlist(pd,dot,list) = 
   (* pd_assign_dns(pd);
	printpd(pd);   for debugging ............. *)
	Hashtbl.clear search_array;
	let queue = create() in
    try
      initializearray(list,search_array);
      initializequeue(pd,list,queue,search_array);
      bf_search(pd,queue,search_array);
      Hashtbl.mem search_array dot.dnum;
    with HitOutside -> false;;

(* test_cw tests if the path given in whole_boundry_list is in cw order*)
let test_cw(whole_boundry_list, pd)=
	Hashtbl.clear search_array;
	let queue = create() in
    try
      initializearray(whole_boundry_list,search_array);
      initializequeue(pd,whole_boundry_list,queue,search_array);
      bf_search(pd,queue,search_array);
      true;
    with HitOutside -> false;;
	
(* cw_return_int_regs returns a list of the interior regions enclosed by the given list; we assume this 
list is given in cw order and raise an error if not.*)
let cw_return_int_regs(whole_boundry_list, pd)=
	Hashtbl.clear search_array;
	let queue = create() in
    try
      initializearray(whole_boundry_list,search_array);
      initializequeue(pd,whole_boundry_list,queue,search_array);
      bf_search(pd,queue,search_array);
	  let reglist = (pd.graph).regs in
	  let f = function r -> regionseen(r,search_array) in
	  let insidereg  = List.filter f reglist in
      sort_regset(insidereg);
    with HitOutside -> 
		raise BadInput;;
	
	
(* test_cw_return_int_regs tests if the path given in whole_boundry_list is in cw order
   and returns a list of all regions inside the given boundry.*)
let  test_cw_return_int_regs(whole_boundry_list, pd)=
	Hashtbl.clear search_array;
	let queue = create() in
    try
      initializearray(whole_boundry_list,search_array);
      initializequeue(pd,whole_boundry_list,queue,search_array);
      bf_search(pd,queue,search_array);
	  let reglist = (pd.graph).regs in
	  let f = function r -> regionseen(r,search_array) in
	  let insidereg  = List.filter f reglist in
      (true, sort_regset(insidereg));
    with HitOutside -> 
		let insidereg =cw_return_int_regs(List.rev whole_boundry_list, pd) in
		(false, insidereg);;

(************)
(* Tangency *)
(************)

(* We check that lines and circles cross in the right way. *)

type intersection_type = TangentOnInside | TangentOnOutside 
			 | Crossing;;

let rec find_go_segs(pd,go,dot,inc_list) =
  match inc_list with
      seg::rest -> 
	let container = pd.member(sse2seg(seg)) in
	  if container = go then seg ::find_go_segs(pd,go,dot,rest)
	  else find_go_segs(pd,go,dot,rest)
    | _ -> [];;

(* ordered_csegs lists the segs in the order they occur in the list *)
(* of segs that make up the circ (which should be cw if the circle *)
(* isn't going to get pruned), so that segs occuring between the two *)
(* output segs lie outside the circle *)
let rec ordered_csegs(cseg1,cseg2,pd,circ,dot) =
  let (dlist,center) = (pd.cmakeup)(circ) in
    match (cseg1,cseg2) with
	(Plain(seg1),Plain(seg2)) ->
	  rec_ordered_csegs(double(dlist),cseg1,cseg2,dot)
      | (Returning(seg1),Plain(seg2)) ->
	  (cseg1,cseg2) (*fixed 5/12/2010*)
      | (Plain(seg1),Returning(seg2)) -> (cseg2,cseg1)
      | _ -> raise BadInput
and rec_ordered_csegs(dlist,cseg1,cseg2,dot) =
  match dlist with
      Seg(seg)::Dot(odot)::Seg(seg2)::rest 
	when Plain(seg) = cseg1 & Plain(seg2) = cseg2 & odot = dot -> 
	  (cseg1,cseg2)
    | Seg(seg)::Dot(odot)::Seg(seg2)::rest 
	when Plain(seg) = cseg2 & Plain(seg2) = cseg1 & odot = dot -> 
	(cseg2,cseg1)
    | first::rest -> rec_ordered_csegs(rest,cseg1,cseg2,dot)
    | _ -> raise BadInput;;

(*returns the lsegs in the order they occur in in the 
  (directed) line*)
let rec ordered_lsegs(lseg1,lseg2,pd,line) =
  let dlist = (pd.lmakeup)(line) in
    match (lseg1,lseg2) with
	(Plain(seg1),Plain(seg2)) ->
	  rec_ordered_lsegs(dlist,lseg1,lseg2)
      | _ -> raise BadInput
and rec_ordered_lsegs(dlist,lseg1,lseg2) =
  match dlist with
      Seg(seg)::rest when Plain(seg) = lseg1 -> (lseg1,lseg2)
    | Seg(seg)::rest when Plain(seg) = lseg2 -> (lseg2,lseg1)
    | first::rest -> rec_ordered_lsegs(rest,lseg1,lseg2)
    | _ -> raise BadInput;;



let rec lc_tangency_type((edge1,edgeA), (edge2,edgeB), sinclist) =
  rec_lctangent(edge1,edgeA, edge2,edgeB, append(sinclist,sinclist))
and rec_lctangent(edge1,edgeA, edge2,edgeB, db_list) =
  match db_list with
      first::rest -> 
	if first = edge1
	then rec_lctangent2(edgeA, edge2, edgeB, rest, 0)
	else rec_lctangent(edge1, edgeA, edge2, edgeB, rest)
    | _ -> raise BadIncList
and rec_lctangent2(edgeA, edge2, edgeB, db_list, counter) =
  match db_list with
      first::rest -> 
	(if (first = edgeA)
	 then 
	   (if (counter = 0) 
	    then TangentOnInside
	    else 
	      (if (counter = 2)
	       then TangentOnOutside
	       else Crossing ))
	 else
	   (if ((first = edge2) or (first = edgeB)) 
	    then rec_lctangent2(edgeA, edge2, edgeB, rest, (counter + 1))
	    else  rec_lctangent2(edgeA, edge2, edgeB, rest, counter)))
    | _ -> raise BadIncList;;

let find_lc_intersection_type(pd,line,circ,dot) =
  let sinclist = segextract((pd.graph.inc)(dot)) in 
  let lseglist = find_go_segs(pd,Line(line),dot,sinclist) in
  let cseglist = find_go_segs(pd,Circ(circ),dot,sinclist) in
    match (lseglist,cseglist) with
	([lseg1;lseg2],[unord_cseg1;unord_cseg2]) ->
	  let (cseg1,cseg2) = 
	    ordered_csegs(unord_cseg1,unord_cseg2,pd,circ,dot)
	  in
	    lc_tangency_type((cseg1,cseg2),(lseg1,lseg2),sinclist)
	| _ -> Crossing;;
	
(*finds out if two circs cross or are tangent at the given dot*)	
let find_cc_intersection_type(pd,circ1,circ2,dot) =
  let sinclist = segextract((pd.graph.inc)(dot)) in 
  let c1seglist = find_go_segs(pd,Circ(circ1),dot,sinclist) in
  let c2seglist = find_go_segs(pd,Circ(circ2),dot,sinclist) in
    match (c1seglist,c2seglist) with
	([cseg1a;cseg1b],[cseg2a;cseg2b]) ->
	  if tangent((cseg1a,cseg1b),(cseg2a,cseg2b),sinclist)
	  then TangentOnOutside
	  else Crossing
	| _ -> raise BadInput;;

let rec rec_check_exit(cseg1,cseg2,lseg1,lseg2,db_list) =
  match db_list with
      first::rest -> 
	if first = cseg1
	then rec_check_exit2(cseg2,lseg1,lseg2,rest)
	else rec_check_exit(cseg1,cseg2,lseg1,lseg2,rest)
    | _ -> raise BadIncList
and rec_check_exit2(cseg2,lseg1,lseg2,list) =
  match list with
      first::rest when first = lseg2 -> true
    | first::rest when first = lseg1 or first = cseg2 -> false
    | first::rest -> rec_check_exit2(cseg2,lseg1,lseg2,rest)
    | _ -> raise BadInput;;


(* line_exits_circle_here is true if the given (directed) line exits the given circle at 
   the given dot.*)
let line_exits_circle_here(pd,line,circ,dot) =  (* screwey!  May need to be fixed *)
  let inc_list = segextract((pd.graph.inc)(dot)) in
  let dinc_list = double(inc_list) in
  let lseglist =  find_go_segs(pd,Line(line),dot,inc_list) in
  let cseglist =  find_go_segs(pd,Circ(circ),dot,inc_list) in
        match (lseglist,cseglist) with
			([ulseg1;ulseg2],[unord_cseg1;unord_cseg2]) ->
				let (cseg1,cseg2) = 
					ordered_csegs(unord_cseg1,unord_cseg2,pd,circ,dot)
				in
				let (lseg1,lseg2) =
					ordered_lsegs(ulseg1,ulseg2,pd,line) 
				in
				rec_check_exit(cseg1,cseg2,lseg1,lseg2,dinc_list)
			| ([lseg],[unord_cseg1;unord_cseg2]) ->
				let (cseg1,cseg2) =
					ordered_csegs(unord_cseg1,unord_cseg2,pd,circ,dot)
				in
					(match (pd.lmakeup)(line) with
						Dot(d1)::rest when d1 = dot -> 
						(*lseg begins line and should therefore be on outside *)
							rec_check_exit(cseg1,cseg2,cseg2,lseg,dinc_list)
							(* the second cseg2 is a dummy *)
						| _ ->  (* lseg ends line and should be inside *)
							not(rec_check_exit(cseg1,cseg2,cseg2,lseg,dinc_list)))
			| _ -> 
				(* printpd(pd);*) (* for debugging *)
				raise BadInput;;
	  



let rec find_second_dot(dot,cdot,llist) =
  match llist with
      Dot(ldot)::rest when ldot = dot -> cdot
    | Dot(ldot)::rest when ldot = cdot -> dot
    | first::rest -> find_second_dot(dot,cdot,rest)
    | _ -> raise BadInputList;;


type seen_intersections = NoIntersections | OneTangent | OneCrossing of dot;;

let itype_array = Hashtbl.create small_hashsize;;

let safe_lookup(elt, itypetable) =
	if Hashtbl.mem itypetable elt
	then Hashtbl.find itypetable elt
	else NoIntersections;;

(*line_circle_intersections_ok checks that the new line "line" doesn't violate
any tangency rules with existing circles.*)
let rec line_circle_intersections_ok(pd,line) = 
  Hashtbl.clear itype_array;
  let line_makeup = (pd.lmakeup)(line) in
    rec_lc_int_ok(pd,line,itype_array,line_makeup)
and rec_lc_int_ok(pd,line,array,line_makeup) = 
  match line_makeup with
      Seg(seg)::rest -> rec_lc_int_ok(pd,line,array,rest)
    | Dot(dot)::rest -> 
	let ilist = pd.intersect(dot) in
	  if rec2_lc_int_ok(pd,line,array,dot,ilist)
	  then rec_lc_int_ok(pd,line,array,rest)
	  else false
    | _ -> true
and rec2_lc_int_ok(pd,line,array,dot,ilist) =
  match ilist with
      Line(dline)::rest -> 	  
	rec2_lc_int_ok(pd,line,array,dot,rest)
    | Circ(circ)::rest -> 
	let index = circ.cnum in
	let value = safe_lookup(index,array) in
	let int_type = find_lc_intersection_type(pd,line,circ,dot) in
	  (match (value,int_type) with
	       (_,TangentOnInside) -> false
	     | (OneTangent,_) -> false
	     | (NoIntersections,Crossing) ->
		 ((Hashtbl.add array index (OneCrossing(dot)));
		  rec2_lc_int_ok(pd,line,array,dot,rest))
	     | (OneCrossing(cdot),Crossing) ->
		 if line_exits_circle_here(pd,line,circ,dot)
		 then rec2_lc_int_ok(pd,line,array,dot,rest)
		 else false
	     | (NoIntersections,TangentOnOutside) ->
		 (Hashtbl.replace array index OneTangent;
		  rec2_lc_int_ok(pd,line,array,dot,rest))
	     | (_,TangentOnOutside) -> false)
    | first::rest -> rec2_lc_int_ok(pd,line,array,dot,rest)
    | _ -> true;;

(* circle line intersections ok checks that the new circle circ doesn't
violate any intersection/tangency rules with existing lines and circles.*)
let rec circle_line_intersections_ok(pd,circ,clist) = 
	Hashtbl.clear itype_array;
    rec_cl_int_ok(pd,circ,itype_array,clist)
and rec_cl_int_ok(pd,circ,array,circ_makeup) = 
  match circ_makeup with
      Seg(seg)::rest -> rec_cl_int_ok(pd,circ,array,rest)
    | Dot(dot)::rest -> 
	let ilist = pd.intersect(dot) in
	  if rec2_cl_int_ok(pd,circ,array,dot,ilist)
	  then rec_cl_int_ok(pd,circ,array,rest)
	  else false
    | _ -> true
and rec2_cl_int_ok(pd,circ,array,dot,ilist) =
  match ilist with
      Circ(circ2)::rest -> 	
		let index = circ2.cnum in
		let value = safe_lookup(index,array) in
		let int_type = find_cc_intersection_type(pd,circ,circ2,dot) in
		 (match (value,int_type) with
	     | (OneTangent,_) -> false
	     | (NoIntersections,Crossing) ->
		 (Hashtbl.replace array index (OneCrossing(dot));
		  rec2_cl_int_ok(pd,circ,array,dot,rest))
	     | (OneCrossing(cdot),Crossing) ->
		  rec2_cl_int_ok(pd,circ,array,dot,rest)
	     | (NoIntersections,TangentOnOutside) ->
		 (Hashtbl.replace array index OneTangent;
		  rec2_cl_int_ok(pd,circ,array,dot,rest))
	     | (_,TangentOnOutside) -> false
		 | _ -> raise BadInput)
    | Line(line)::rest -> 
	let index = line.lnum in
	let value = safe_lookup(index,array) in
	let int_type = find_lc_intersection_type(pd,line,circ,dot) in
	  (match (value,int_type) with
	       (_,TangentOnInside) -> false
	     | (OneTangent,_) -> false
	     | (NoIntersections,Crossing) ->
		 (Hashtbl.replace array index (OneCrossing(dot));
		  rec2_cl_int_ok(pd,circ,array,dot,rest))
	     | (OneCrossing(cdot),Crossing) ->
		 let second_dot = 
		   find_second_dot(dot,cdot,(pd.lmakeup)(line)) 
		 in
		   if line_exits_circle_here(pd,line,circ,second_dot)
		   then rec2_cl_int_ok(pd,circ,array,dot,rest)
		   else false
	     | (NoIntersections,TangentOnOutside) ->
		 (Hashtbl.replace array index OneTangent;
		  rec2_cl_int_ok(pd,circ,array,dot,rest))
	     | (_,TangentOnOutside) -> false)
    | first::rest -> rec2_cl_int_ok(pd,circ,array,dot,rest)
    | _ -> true;;
	
let rec rec_circle_already_drawn(pd, rdot, center, ilist)=
	match ilist with
		Line(line)::rest -> rec_circle_already_drawn(pd,rdot,center, rest)
		| Circ(circ)::rest ->
			let (dlist, center2) = pd.cmakeup(circ) in
				if center2 = center then true 
				else rec_circle_already_drawn(pd,rdot,center, rest)
		|_-> false ;;
	
let circle_already_drawn(pd, rdot, center) =
	let ilist = pd.intersect(rdot) in
	rec_circle_already_drawn(pd, rdot, center, ilist);;
	



(*************)
(* Triangles *)
(*************)
	
let common_point(d1s1,d2s1,d1s2,d2s2)=
	if d1s1 = d1s2 or d1s1 = d2s2
	then d1s1
	else if d2s1 = d1s2 or d2s1 = d2s2
	then d2s1
	else raise BadInput;;
	
(* circular_ss_between_in_list finds all solid segments from elt1 to elt2, including
    elt1 but not elt2 in the list.  If elt2 occurs before elt1 in list,
	we still start at elt1 and cycle back to the beginning of the list. *)
let rec circular_ss_between_in_list(list, elt1, elt2) =
	let dbllist = append(list,list) in
	rec1_circular_ss_between_in_list(dbllist, elt1,elt2)
and rec1_circular_ss_between_in_list(dbllist, elt1,elt2) =
	match dbllist with
	first::rest when first = elt1 ->
		rec2_circular_ss_between_in_list([sse2seg(first)],rest,elt2)
	| first::rest -> 
		rec1_circular_ss_between_in_list(rest, elt1,elt2)
	| _ -> raise BadInputList
and rec2_circular_ss_between_in_list(output_list, input_list, elt2) =
	match input_list with
	first::rest when first = elt2 -> output_list
	| Plain(first)::rest when first.ssty = Solid -> 
		rec2_circular_ss_between_in_list(append(output_list,[first]),rest, elt2)
	| first::rest -> rec2_circular_ss_between_in_list(output_list,rest,elt2)
	| _ -> raise BadInputList;;


let get_angle(pd, point, seg1, seg2) =
	let dotsur = segextract(pd.graph.inc(point)) in 
	let anglesegs = circular_ss_between_in_list(dotsur, seg1, seg2) in
	let pangles = List.map (function seg -> (point, seg)) anglesegs in
	sort_diang(pangles);;
	
let reorder_dseg(dseg1,pd, pointA, pointB) =
	let ln =
		match pd.member(firstelt(dseg1)) with
			Line(ln2)  -> ln2
			| _ -> raise BadInput
		in
	let linelist = pd.lmakeup(ln) in
	between_in_list(linelist, Dot(pointA), Dot(pointB));;
	
	
(*
The following function finds the 3 interior angles of a given triangle.
The triangle will look like this:

A  dseg1   B
           
  d		   d
   e	   s
    s	   e
	 e	   g
	  g	   2
	   3	
		   
		   
		   C
		   
		   a1seg will be the segment starting at pointA along dseg1;
		   b1seg will be the segment starting at pointB along dseg2;
		   c1seg will be the segment starting at pointC along dseg3;
		   
		   a2seg will be the segment ending at pointA along dseg3;
		   b2seg will be the segment ending at pointB along dseg1;
		   c2seg will be the segment ending at pointC along dseg2;
		   
		   If the triangle has a cw orientation (as in the picture), the interior angles
		   go from a1seg to a2seg, etc.
		   If the triangle has a ccw orientation, the interior angles 
		   go from a2seg to a1seg, etc.
	
*)	
let find_triangle_angles_and_int(pointA,dseg1,pointB,dseg2,pointC,dseg3,pd) =
	let odseg1 = reorder_dseg(dseg1,pd, pointA, pointB) in
	let odseg2 = reorder_dseg(dseg2,pd, pointB, pointC) in
	let odseg3 = reorder_dseg(dseg3,pd, pointC, pointA) in
	let a1seg = diagelt2sse(secondelt(odseg1)) in
	let a2seg = diagelt2sse(lastelt(odseg3)) in
	let b1seg = diagelt2sse(secondelt(odseg2)) in
	let b2seg = diagelt2sse(lastelt(odseg1)) in
	let c1seg = diagelt2sse(secondelt(odseg3)) in
	let c2seg = diagelt2sse(lastelt(odseg2)) in
	let whole_triangle_list = append(odseg1, append(odseg2,odseg3)) in 
	let (cwflag, irlist) = test_cw_return_int_regs(whole_triangle_list,pd) in
	if cwflag
	then 
		let angA = get_angle(pd, pointA, a1seg, a2seg) in
		let angB = get_angle(pd, pointB, b1seg, b2seg) in
		let angC = get_angle(pd, pointC, c1seg, c2seg) in
		(angB, angC, angA, irlist)
	else
		let angA = get_angle(pd, pointA, a2seg, a1seg) in
		let angB = get_angle(pd, pointB, b2seg, b1seg) in
		let angC = get_angle(pd, pointC, c2seg, c1seg) in
		(angB, angC, angA, irlist);;
		

let sas_applies(pd, triangle1, triangle2) = 
	let (t1s1,t1a1,t1s2,t1a2,t1s3,t1a3) = triangle1 in
	let (t2s1,t2a1,t2s2,t2a2,t2s3,t2a3) = triangle2 in	
	if 
		marked_equal(Dseg(t1s1),Dseg(t2s1), pd) 
		&& marked_equal(Angle(t1a1), Angle(t2a1), pd)
		&& marked_equal(Dseg(t1s2),Dseg(t2s2), pd)
	then
		true
	else false;;

let sas_triangleupdate(pd,trianglesides1,trianglesides2) =
	let (t1d1,t1s1,t1d2,t1s2,t1d3,t1s3) = trianglesides1 in
	let (t2d1,t2s1,t2d2,t2s2,t2d3,t2s3) = trianglesides2 in
	let (t1a1,t1a2,t1a3,t1rs) = 
		find_triangle_angles_and_int(t1d1,t1s1,t1d2,t1s2,t1d3,t1s3,pd) in
	let (t2a1,t2a2,t2a3, t2rs) = 
		find_triangle_angles_and_int(t2d1,t2s1,t2d2,t2s2,t2d3,t2s3,pd) in
	let triangle1 = (t1s1,t1a1,t1s2,t1a2,t1s3,t1a3) in
	let triangle2 = (t2s1,t2a1,t2s2,t2a2,t2s3,t2a3) in	
	if sas_applies(pd, triangle1, triangle2)
	then
	 let marker1 = newmarker() in
	 let marker2 = newmarker() in
	 let marker3 = newmarker() in
	 let marker4 = newmarker() in
	 let markedby1 = extendfunction(extendfunction(pd.markedby, Dseg(t1s3), 
									               setadjoin(marker1,pd.markedby(Dseg(t1s3)))),
								    Dseg(t2s3),  setadjoin(marker1,pd.markedby(Dseg(t2s3)))) in
	 let markedby2 = extendfunction(extendfunction(markedby1, Angle(t1a2), 
									               setadjoin(marker2,pd.markedby(Angle(t1a2)))),
								    Angle(t2a2),  setadjoin(marker2,pd.markedby(Angle(t2a2)))) in
	 let markedby3 = extendfunction(extendfunction(markedby2, Angle(t1a3), 
									               setadjoin(marker3,markedby2(Angle(t1a3)))),
								    Angle(t2a3),  setadjoin(marker3,markedby2(Angle(t2a3)))) in
	 let markedby4 = extendfunction(extendfunction(markedby3, RegionSet(t1rs), 
									               setadjoin(marker4,pd.markedby(RegionSet(t1rs)))),
								    RegionSet(t2rs),  setadjoin(marker4,pd.markedby(RegionSet(t2rs)))) in
	 let marks1 = extendfunction(pd.marks,
			      marker1, 
			      fancysetadjoin(Dseg(t2s3), setadjoin(Dseg(t1s3), 
							       emptyset))) in
	 let marks2 = extendfunction(marks1,
			      marker2, 
			      fancysetadjoin(Angle(t2a2), setadjoin(Angle(t1a2), 
							       emptyset))) in
	 let marks3 = extendfunction(marks2,
			      marker3, 
			      fancysetadjoin(Angle(t2a3), setadjoin(Angle(t1a3), 
							       emptyset))) in
	 let marks4 = extendfunction(marks3,
			      marker4, 
			      fancysetadjoin(RegionSet(t2rs), setadjoin(RegionSet(t1rs), 
							       emptyset))) in
	  assign_dn(marker1.mnum);
	  assign_dn(marker2.mnum);
	  assign_dn(marker3.mnum);
	  assign_dn(marker4.mnum);
      {rmap = pd.rmap;
       graph = pd.graph;
       rcmap = pd.rcmap;
       lmakeup = pd.lmakeup;
       cmakeup = pd.cmakeup;
       lines = pd.lines;
       circs = pd.circs;
       member = pd.member;
       intersect = pd.intersect;
       markers = setadjoin( marker4,setadjoin(marker1, setadjoin(marker2,setadjoin(marker3,pd.markers))));
       markedby = markedby4;
       marks = marks4}
  else raise Inapplicable;;

let sss_applies(pd, triangle1, triangle2) = 
	let (t1s1,t1a1,t1s2,t1a2,t1s3,t1a3) = triangle1 in
	let (t2s1,t2a1,t2s2,t2a2,t2s3,t2a3) = triangle2 in	
	if 
		marked_equal(Dseg(t1s1),Dseg(t2s1), pd) 
		&& marked_equal(Dseg(t1s2),Dseg(t2s2), pd)
		&& marked_equal(Dseg(t1s3),Dseg(t2s3), pd)
	then
		true
	else false;;

let sss_triangleupdate(pd,trianglesides1,trianglesides2) =
	let (t1d1,t1s1,t1d2,t1s2,t1d3,t1s3) = trianglesides1 in
	let (t2d1,t2s1,t2d2,t2s2,t2d3,t2s3) = trianglesides2 in
	let (t1a1,t1a2,t1a3,t1rs) = 
		find_triangle_angles_and_int(t1d1,t1s1,t1d2,t1s2,t1d3,t1s3,pd) in
	let (t2a1,t2a2,t2a3, t2rs) = 
		find_triangle_angles_and_int(t2d1,t2s1,t2d2,t2s2,t2d3,t2s3,pd) in
	let triangle1 = (t1s1,t1a1,t1s2,t1a2,t1s3,t1a3) in
	let triangle2 = (t2s1,t2a1,t2s2,t2a2,t2s3,t2a3) in	
	if sss_applies(pd, triangle1, triangle2)
	then
	 let marker1 = newmarker() in
	 let marker2 = newmarker() in
	 let marker3 = newmarker() in
	 let marker4 = newmarker() in
	 let markedby1 = extendfunction(extendfunction(pd.markedby, Angle(t1a1), 
									               setadjoin(marker1,pd.markedby(Angle(t1a1)))),
								    Angle(t2a1),  setadjoin(marker1,pd.markedby(Angle(t2a1)))) in
	 let markedby2 = extendfunction(extendfunction(markedby1, Angle(t1a2), 
									               setadjoin(marker2,markedby1(Angle(t1a2)))),
								    Angle(t2a2),  setadjoin(marker2,markedby1(Angle(t2a2)))) in
	 let markedby3 = extendfunction(extendfunction(markedby2, Angle(t1a3), 
									               setadjoin(marker3,markedby2(Angle(t1a3)))),
								    Angle(t2a3),  setadjoin(marker3,markedby2(Angle(t2a3)))) in
	 let markedby4 = extendfunction(extendfunction(markedby3, RegionSet(t1rs), 
									               setadjoin(marker4,pd.markedby(RegionSet(t1rs)))),
								    RegionSet(t2rs),  setadjoin(marker4,pd.markedby(RegionSet(t2rs)))) in
	 let marks1 = extendfunction(pd.marks,
			      marker1, 
			      fancysetadjoin(Angle(t2a1), setadjoin(Angle(t1a1), 
							       emptyset))) in
	 let marks2 = extendfunction(marks1,
			      marker2, 
			      fancysetadjoin(Angle(t2a2), setadjoin(Angle(t1a2), 
							       emptyset))) in
	 let marks3 = extendfunction(marks2,
			      marker3, 
			      fancysetadjoin(Angle(t2a3), setadjoin(Angle(t1a3), 
							       emptyset))) in
	 let marks4 = extendfunction(marks3,
			      marker4, 
			      fancysetadjoin(RegionSet(t2rs), setadjoin(RegionSet(t1rs), 
							       emptyset))) in
	  assign_dn(marker1.mnum);
	  assign_dn(marker2.mnum);
	  assign_dn(marker3.mnum);
      {rmap = pd.rmap;
       graph = pd.graph;
       rcmap = pd.rcmap;
       lmakeup = pd.lmakeup;
       cmakeup = pd.cmakeup;
       lines = pd.lines;
       circs = pd.circs;
       member = pd.member;
       intersect = pd.intersect;
       markers = setadjoin( marker4, setadjoin(marker1, setadjoin(marker2,setadjoin(marker3,pd.markers))));
       markedby = markedby4;
       marks = marks4}
  else raise Inapplicable;;
  
(***************************)  
(* Euclid's Fifth Postulate*)
(***************************)  

(* get_straight_angle returns the di-angle with the given dot as vertex and
   with the given segment as the ccw side and the continuation of that line as the cw side.
   It gives an error if the given segment doesn't continue on the other side.*)
let get_straight_angle(dot, segment, pd) =
	let makeupmap = pd.member in
	let sinclist = segextract(((pd.graph).inc)(dot)) in
	let opseg = sse2seg(opp_seg(Plain(segment), sinclist,makeupmap)) in
	if opseg = segment
	then raise BadInput
	else get_angle(pd,dot,Plain(segment),Plain(opseg));; 
	
(* segs_around_dots gives the segments before and after the two given dots in the given 
   list translist, along with a boolean value which is true if dot1 precedes dot2 in the list,
   and false otherwise.*)	 
let rec segs_around_dots(dot1,dot2,translist) =
	match translist with 
		  Seg(s1)::Dot(d)::Seg(s2)::rest when d = dot1 ->
			sad2(s1,s2,dot2,Seg(s2)::rest,true)
		| Seg(s1)::Dot(d)::Seg(s2)::rest when d = dot2 ->
			sad2(s1,s2,dot1,Seg(s2)::rest,false)
		| Seg(s1)::Dot(d)::Seg(s2)::rest ->
			segs_around_dots(dot1,dot2,Seg(s2)::rest)
		| Dot(d)::rest ->
			segs_around_dots(dot1,dot2,rest)
		| _ -> raise BadInput
and sad2(segA1,segA2,dot,translist,flag) =
	match translist with
		  Seg(s1)::Dot(d)::Seg(s2)::rest when d = dot & flag = true  ->
			(segA1,segA2, s1, s2, flag)
		| Seg(s1)::Dot(d)::Seg(s2)::rest when d = dot & flag = false ->
			(s1, s2,segA1,segA2, flag)
		| Seg(s1)::Dot(d)::Seg(s2)::rest ->
			sad2(segA1,segA2,dot,Seg(s2)::rest, flag)
		| _ -> raise BadInput;;

(* halfline returns the half of the given line on the side of dot on which 
   seg occurs.  It assumes the segment is adjacent to the dot. *)
let rec halfline(pd, line, dot, seg) =
	rec_halfline((pd.lmakeup)(line), [], dot, seg)
and rec_halfline(linelist, seenlist, dot, seg) =
	match linelist with 
		  Dot(d)::Seg(s)::rest when d = dot & s = seg -> linelist
		| Dot(d)::rest when d = dot -> (raise BadInput)
		| Dot(d)::rest -> rec_halfline(rest,Dot(d)::seenlist,dot,seg)
		| Seg(s)::Dot(d)::rest when s = seg & dot = d -> Dot(d)::Seg(s)::seenlist
		| Seg(s)::rest when s = seg -> raise BadInput
		| Seg(s)::rest -> rec_halfline(rest,Seg(s)::seenlist,dot,seg)
		| _ -> raise BadInput;;
		
		

(* efp_applies checks if the hypotheses of Euclid's Fifth Postulate apply in the 
given diagram, but the conclusion does not.  That is, that the two lines containing
seg1 and seg2 cross the transversal trans at seg1 and seg2, and the interior angles on the side
of seg1 and seg2 are a subset of the diangle containing_diang, which is marked congruent to the 
straight angle whose ccw side is stangseg at stangdot, but those lines don't cross on that 
side of the transversal.   *)
let efp_applies(pd,trans,seg1,seg2,containing_diang,stangdot,stangseg) =
	let line1 = 
		match (pd.member)(seg1) with
			Line(l) -> l
			|_ -> raise BadInput in
	let line2 = 
		match (pd.member)(seg2) with
			Line(l) -> l
			|_ -> raise BadInput in
	let translist = (pd.lmakeup)(trans) in
	let (dot1a,dot1b) = 
		match ((pd.graph).emap)(seg1) with
			DotPair(da,db) -> (da,db)
			| _ -> raise BadInput
	in
	let (dot2a,dot2b) = 
		match ((pd.graph).emap)(seg2) with
			DotPair(da,db) -> (da,db)
			| _ -> raise BadInput
	in
	let dot1 =
		 if inset(Line(trans),(pd.intersect)(dot1a)) then dot1a
		 else if inset(Line(trans),(pd.intersect)(dot1b)) then dot1b
		 else raise BadInput
	in
	let dot2 =
		 if inset(Line(trans),(pd.intersect)(dot2a)) then dot2a
		 else if inset(Line(trans),(pd.intersect)(dot2b)) then dot2b
		 else raise BadInput
	in	
	let (ts1a,ts1b,ts2a,ts2b, onefirstflag) = segs_around_dots(dot1,dot2,translist) in
	let sang1 = get_angle(pd,dot1,Plain(ts1a),Plain(ts1b)) in
	let sang2 = get_angle(pd,dot2,Plain(ts2a),Plain(ts2b)) in
	let leftside1 = inset((dot1,seg1),sang1) in
	let leftside2 = inset((dot2,seg2),sang2) in
	let leftflag = 
		match (leftside1,leftside2) with
			  (true,true) -> true
			| (false,false) -> false
			| _ -> raise BadInput in
	let halfline1 = halfline(pd,line1,dot1,seg1) in
	let halfline2 = halfline(pd,line2,dot2,seg2) in
	let linesdontintersect = disjoint(halfline1,halfline2) in
	let frameends = isframedot(de2dot(lastelt(halfline1))) & 
					isframedot(de2dot(lastelt(halfline2))) in
	let (int_ang1,int_ang2) = 
		match (onefirstflag,leftflag) with
			  (true,true) -> (get_angle(pd,dot1,Plain(seg1),Plain(ts1b)),
							  get_angle(pd,dot2,Plain(ts2a),Plain(seg2)))
			| (true,false) -> (get_angle(pd,dot1,Plain(ts1b),Plain(seg1)),
							   get_angle(pd,dot2,Plain(seg2),Plain(ts2a))) 
			| (false,true) -> (get_angle(pd,dot1,Plain(ts1a),Plain(seg1)),
							   get_angle(pd,dot2,Plain(seg2),Plain(ts2b))) 
			| (false,false) -> (get_angle(pd,dot1,Plain(seg1),Plain(ts1a)),
							    get_angle(pd,dot2,Plain(ts2b),Plain(seg2)))
	in
	let subset1 = subset(int_ang1,containing_diang) in
	let subset2 = subset(int_ang2,containing_diang) in
	let stang = get_straight_angle(stangdot,stangseg,pd) in
	linesdontintersect & subset1 & subset2 & frameends & 
		marked_equal(Angle(containing_diang),Angle(stang),pd);;
			



(******************************)
(* Erasing Pieces of Diagrams *)
(******************************)

exception NotErasable;;


	
let rec dotinangle(dot, palist) = 
	match palist with
		  (d,s)::rest when d=dot -> true
		| first::rest -> dotinangle(dot,rest)
		| [] -> false;;
		
		(* previoussegs finds the ccw segments from the given segment that ends at dot1 and dot2
		 on either side.*)
let previoussegs(seg,dot1,dot2, pd) = 
			let ds1 = ssegextract(((pd.graph).inc)(dot1)) in
			let ds2 = ssegextract(((pd.graph).inc)(dot2)) in
			let pseg1 = circular_precedesinlist(seg,ds1) in
			let pseg2 = circular_precedesinlist(seg,ds2) in
			(pseg1,pseg2);;
			

		

let rec segdividesangle(seg,palist,pd,dot1,pseg1,dot2,pseg2) =
			match ( inlist((dot1,pseg1),palist), inlist((dot1,seg),palist)) with
				  (true,false) -> true
				| (false,true) -> true
				| _ ->
					(match  (inlist((dot2,pseg2),palist), inlist((dot2,seg),palist)) with
						  (true,false) -> true
						| (false,true) -> true
						| _ -> false);;  
			
			


let erase_disconnected_point(dot, pd) =
	let graph = pd.graph in
	let inc = graph.inc in
	let ds = inc(dot) in
	let reg =
		match ds with
			Reg(reg1)::[] -> reg1
			| _ -> raise NotErasable
		in
	let oldrcmap = pd.rcmap in
	let ibdl = (oldrcmap(reg)).int_bd_list in 
	let newibdl = setremove([Dot(dot)],ibdl) in 
	let newrcmap = 
		function x ->
			if x = reg
			then {int_bd_list = newibdl}
			else oldrcmap(x)  
		in
	let newdots = setremove(dot,graph.dots) in
	let newinc = 
		function x ->
			if x = dot
			then []
			else inc(x)
		in
	let newgraph =
		{dots = newdots;
		 segs = graph.segs;
		 inc = newinc;
		 emap = graph.emap;
		 regs = graph.regs} in
	{rmap = pd.rmap;
	 rcmap = newrcmap;
	 graph = newgraph;
	 lmakeup = pd.lmakeup;
	 cmakeup = pd.cmakeup;
	 member = pd.member;
	 intersect = pd.intersect;
	 markers = pd.markers;
	 markedby = pd.markedby;
	 marks = pd.marks;
	 lines = pd.lines;
	 circs = pd.circs};;
	 
let erase_edge_point(dot, pd) =
	let graph = pd.graph in
	let inc = graph.inc in
	let ds = inc(dot) in
	let (sse1,regl,sse2,regr) =
		match ds with
			Reg(reg22)::DSSeg(sse11)::Reg(reg11)::DSSeg(sse22)::[] -> (sse11,reg11,sse22,reg22)
			| DSSeg(sse11)::Reg(reg11)::DSSeg(sse22)::Reg(reg22)::[] -> (sse11,reg11,sse22,reg22)
			| _ -> raise NotErasable
		in
	let seg1 = sse2seg(sse1) in
	let seg2 = sse2seg(sse2) in
	let send1 = ((pd.graph).emap)(seg1) in	
	let send2 = ((pd.graph).emap)(seg2) in	
	let dot1 =
		match send1 with
			  DotPair(d1,d2) when d1 = dot -> d2
			| DotPair(d1,d2) -> d1
			| _ -> raise BadInput in
	let dot2 =
		match send2 with
			  DotPair(d1,d2) when d1 = dot -> d2
			| DotPair(d1,d2) -> d1
			| _ -> raise BadInput in		
	let loopflag = (dot1 = dot) in (* we're removing dot from a loop *)
	let returnflag = (dot1 = dot2) in (*we're creating a segment that returns to a dot *)
	let reglbd = (pd.rmap)(regl) in
	let regrbd = (pd.rmap)(regr) in
	let connectedleft = inlist(Dot(dot),reglbd) in
	let connectedright = inlist(Dot(dot),regrbd) in
	let newdots = setremove(dot,graph.dots) in
	let newseg = if loopflag then seg1 
		else match seg1.ssty with
			  Solid -> newsseg()
			| Dotted -> newdottedseg()
			| Frame -> newfseg() in
	let newsegs =
		if loopflag then graph.segs 
		else setadjoin(newseg,setremove(seg1,setremove(seg2, graph.segs)))
	in
	let newinc = 
		function x ->
			match (x,returnflag) with
				  (d,rf) when d = dot -> []
				| (d,true) when d = dot1 -> 
					let ds = inc(d) in 
					if inlist(Dot(dot1), reglbd) (* loop is on left of dot *)
					then 
						let ds1 = sub_in_list(DSSeg(Plain(seg1)), DSSeg(Returning(newseg)), ds) in
						sub_in_list(DSSeg(Plain(seg2)), DSSeg(Plain(newseg)), ds1) 
					else
					let ds1 = sub_in_list(DSSeg(Plain(seg1)), DSSeg(Plain(newseg)), ds) in
						sub_in_list(DSSeg(Plain(seg2)),DSSeg(Returning(newseg)), ds1) 
				| (d,false) when d = dot1 -> 
					let ds = inc(d) in 
					sub_in_list(DSSeg(Plain(seg1)), DSSeg(Plain(newseg)), ds)
				| (d,false) when d = dot2 -> 
					let ds = inc(d) in 
					sub_in_list(DSSeg(Plain(seg2)), DSSeg(Plain(newseg)), ds)
				| (d,rf) -> inc(x)
	in
	let newedgemap = function e ->
		if ((e = seg1) or (e=seg2)) 
		then 
			(if e = seg1 & e = seg2 
			then 
				(if inlist(Dot(dot1), reglbd) (* loop is on left of dot *)
				then Loop(regl,regr)
				else Loop(regr,regl))
			else NullEnd)
		else if e = newseg then DotPair(dot1,dot2)
		else ((pd.graph).emap)(e)
	in
	let newgraph =
		{dots = newdots;
		 segs = newsegs;
		 inc = newinc;
		 emap = newedgemap;
		 regs = graph.regs} in
	let listfix = function x -> replace3inlist(simple_rotate_to(x,Dot(dot1)),
								Seg(seg1),Dot(dot),Seg(seg2),Seg(newseg)) in
	let listfixline = function x -> replace3inlist(x,
								Seg(seg1),Dot(dot),Seg(seg2),Seg(newseg)) in
	let newrmap =
		function r ->
			if r = regl & connectedleft & not(loopflag) 
			then listfix(reglbd)
			else if r = regr & connectedright & not(loopflag) 
			then listfix(regrbd)
			else if r = regl & connectedleft & loopflag 
			then [Seg(newseg)]
			else if r = regr & connectedright & loopflag 
			then [Seg(newseg)]
			else (pd.rmap)(r)
	in
	let listfixint = 
		function x -> 
			if inlist(Dot(dot),x) 
			then (if List.length(x) > 2
				  then listfix(x) 
				  else [Seg(newseg)])
			else x
	in
	let newrcmap =
		function r ->
			if (r = regl & not(connectedleft))  
			then {int_bd_list =(List.map listfixint (((pd.rcmap)(r)).int_bd_list))}
			else if r = regr & not(connectedright)
			then {int_bd_list =(List.map listfixint (((pd.rcmap)(r)).int_bd_list))}
			else (pd.rcmap)(r)
	in
	let dotGO = 
		match pd.intersect(dot) with
			first::[] ->first
			| _ -> NullGO
	in
	let newlmakeup = function l ->
		if dotGO = Line(l)
		then listfixline((pd.lmakeup)(l))
		else (pd.lmakeup)(l) in
	let newcmakeup = function l ->
		if dotGO = Circ(l)
		then
			let cm = (pd.cmakeup)(l) in
			let cml = pi1(cm) in
			let ccent = pi2(cm) in
				(listfix(cml),ccent)
		else (pd.cmakeup)(l) in
	let newmember = function s->
		if s = newseg
		then dotGO
		else if s = seg1 or s = seg2 
		then NullGO
		else (pd.member)(s) in
	
	
	let newmarkedby = function m ->
		match m with 
			Dseg(l) ->
				if inset(newseg,l) 
				then 
					let newdsl = setadjoin(seg2,
										   setadjoin(seg1,setremove(newseg,l))) in
					let newdsl2 = List.fast_sort seg_compare newdsl in
					(pd.markedby)(Dseg(newdsl2))
				else (pd.markedby)(Dseg(l))
			|Angle(l) ->
				if dotinangle(dot,l) then [] 
				else
				let l2 = doublereplaceinlist(l, (dot1,newseg),[(dot1,seg1)],
												(dot2,newseg),[(dot2,seg2)]) in
				(pd.markedby)(Angle(sort_diang(l2)))
			| RegionSet(l) -> (pd.markedby(RegionSet(l)))
	in
	let newmarks =
		let markerupdate = 
			function  m ->
				match m with 
					Dseg(l) ->
						if inset(seg1,l) & inset(seg2,l)
						then 
							let newdsl = setadjoin(newseg,setremove(seg1,setremove(seg2,l))) in
							let newdsl2 = List.fast_sort seg_compare newdsl in
							(Dseg(newdsl2))
						else if inset(seg1,l) or inset(seg2,l) 
						then
							Angle([])  (* This deletes this GO. *)
						else (Dseg(l))
					|Angle(l) ->
						if dotinangle(dot,l) then Angle([]) 
						else 
						let l2 = doublereplaceinlist(l, (dot1,seg1),[(dot1,newseg)],
												(dot2,seg2),[(dot2,newseg)]) in
						Angle(sort_diang(l2))
					| RegionSet(l) -> RegionSet(l)
		in
		function m ->
			let oldmarks = (pd.marks)(m) in
			let newmarks1 = List.map markerupdate oldmarks in
			setremove(Angle([]),newmarks1) 
	in
	{rmap = newrmap;
	 rcmap = newrcmap;
	 graph = newgraph;
	 lmakeup = newlmakeup;
	 cmakeup = newcmakeup;
	 member = newmember;
	 intersect = pd.intersect;
	 markers = pd.markers;
	 markedby = newmarkedby;
	 marks = newmarks;
	 lines = pd.lines;
	 circs = pd.circs};;


let erase_point(dot,pd)=
	let ds = ((pd.graph).inc)(dot) in
	match ds with
		  Reg(r)::[] -> erase_disconnected_point(dot,pd)
		| Reg(r1):: DSSeg(dss1)::Reg(r2)::DSSeg(dss2)::[] ->
			let go1 = (pd.member)(sse2seg(dss1)) in
			let go2 = (pd.member)(sse2seg(dss2)) in
			if go1 = go2
			then 
				let newpd = erase_edge_point(dot,pd) 
				in
					pd_register_names(newpd);
					pd_assign_dns(newpd);
					newpd;
			else raise BadInput
		| DSSeg(dss1)::Reg(r2)::DSSeg(dss2)::Reg(r1)::[] ->
			let go1 = (pd.member)(sse2seg(dss1)) in
			let go2 = (pd.member)(sse2seg(dss2)) in
			if go1 = go2
			then 
				let newpd = erase_edge_point(dot,pd)
				in
					pd_register_names(newpd);
					pd_assign_dns(newpd);
					newpd;
			else raise BadInput	
		| _ -> raise BadInput;;



(* goinDSlist checks if any of the segments in the given dotsurround list
   are part of geometric object go *)	 
let rec goinDSlist(go,dslist,pd) =
	match dslist with
		    DSSeg(Plain(seg))::rest when pd.member(seg) = go  -> true
		  | DSSeg(Returning(seg))::rest when pd.member(seg) = go  -> true
		  | first::rest -> goinDSlist(go,rest,pd)
		  | [] -> false;;

(* cdr_unless_sole removes the first elt unless there is only one element in the list. *)		  
let cdr_unless_sole(list) =
	match list with
		  first :: second :: rest -> second::rest
		| _ -> list;;
			
	
	(* erase_seg_and_disconnect is called to remove a segment when the same region is 
	   found on either side of the segment, which means that the two sides will become
	   disconnected from one another when the segment is removed. *)
let erase_seg_and_disconnect(seg,pd, dot1,dot2,ds12,reg) =
	let circleflag = 
				(match (pd.member)(seg) with
					Line(dline) -> false
					| Circ(circ) ->  true 
					| _ -> raise BadInput ) in
	let ds13 = striplist(ds12) in
	let newds1 = 
		if ds13 = []
		then [Reg(reg)] 
		else ds13 in
	let ds21 = ((pd.graph).inc)(dot2) in
	let ds22 = simple_rotate_to(ds21,DSSeg(Plain(seg))) in
	let ds23 = striplist(ds22) in
	let newds2 = 
		if ds23 = []
		then [Reg(reg)] 
		else ds23 in			
	let newsegs = setremove(seg,(pd.graph).segs) in 
	let newinc = 
	function d ->
		if (d = dot1) then newds1 
		else if (d = dot2) then newds2
		else ((pd.graph).inc)(d) 
	in
	let newedgemap = pd.graph.emap in 
	let newregs =  (pd.graph).regs in
	let newgraph = 
		{dots = pd.graph.dots;
		segs = newsegs;
		inc = newinc;
		emap = newedgemap;
		regs = newregs} in
	let regbd = (pd.rmap)(reg) in
	let connectedflag = inlist(Seg(seg),regbd) in
				(* connectedflag = true iff seg is connected to the outside of reg *)
	let (bdlist1,bdlist2) =  (* This finds the two pieces we get when removing seg*)
		if connectedflag then split(regbd,Seg(seg),Seg(seg))
		else 
			let innerbd = dotcomp(dot1,pd,reg)in
			split(innerbd,Seg(seg),Seg(seg))
	in
	let (bdlist3,bdlist4) = (cdr_unless_sole(bdlist1),cdr_unless_sole(bdlist2)) in 
	let outsidefirst =  (* Marks which bdlist is the outside of the region if seg is on the outside*)
		if connectedflag
		then
			(if listofone(bdlist3)
			 then false
			 else if listofone(bdlist4)
			 then true
			 else test_cw(bdlist3,pd))
		else false 
	in 
	let newrmap = function inputregion ->
		match (inputregion, connectedflag) with
			  (r, true) when r = reg & outsidefirst = true  -> bdlist3
			| (r, true) when r = reg & outsidefirst = false -> bdlist4
			| (r, tv) -> (pd.rmap)(r)
	in
	let newrcmap = function r ->
		if r = reg 
		then
			(let ibl = ((pd.rcmap)(reg)).int_bd_list in
			if connectedflag && outsidefirst
			then
				{int_bd_list = setunion(ibl, [bdlist4])}
			else if connectedflag
			then
				{int_bd_list = setunion(ibl, [bdlist3])}
			else 
				(let f = function list -> 
					if inlist(Seg(seg),list) then bdlist3 else list in
				 let newibl = (List.map f ibl) in
					{int_bd_list = setunion(newibl, [bdlist4])}))
		else (pd.rcmap)(r)
	in
	let newmember = function x ->
		if x = seg then NullGO else (pd.member)(x) in
	let memberof = pd.member(seg) in
	let newintersect = function d ->
		if d = dot1 or d=dot2
			then 
				(let dslist = newinc(d) in
				 if goinDSlist(memberof,dslist,pd)
				 then (pd.intersect)(d)
				 else setremove(memberof,(pd.intersect)(d)))
			else (pd.intersect)(d) in
	let (newmarkedby,newmarks) = 
	if circleflag then (pd.markedby,pd.marks)
	else (
	let (pseg1,pseg2) = previoussegs(seg,dot1,dot2, pd) in
	let newmarkedbyr = function m ->
		match m with 
			Dseg(l) ->
				if inset(seg,l) 
				then 
					[]
				else (pd.markedby)(Dseg(l))
			|Angle(l) ->
				let l2 = 
					doublereplaceinlist(l,(dot1,pseg1),(dot1,pseg1)::(dot1,seg)::[],
										  (dot2,pseg2),(dot2,pseg2)::(dot2,seg)::[]) in
				(pd.markedby)(Angle(sort_diang(l2)))
			| RegionSet(l) -> (pd.markedby(RegionSet(l)))
	in
	let newmarksr =
		let markerupdate = 
			function  m ->
				match m with 
					Dseg(l) ->
						if inset(seg,l) 
						then Angle([]) (* This deletes this GO*)
						else (Dseg(l))
					|Angle(l) ->
						if segdividesangle(seg,l,pd,dot1,pseg1,dot2,pseg2) 
						then Angle([]) 
						else 
							let l2 = 
								doublereplaceinlist(l,(dot1,seg),[],(dot2,seg),[]) in
						Angle(sort_diang(l2))
					| RegionSet(l) -> RegionSet(l)
		in
		function m ->
			let oldmarks = (pd.marks)(m) in
			let newmarks1 = List.map markerupdate oldmarks in
			setremove(Angle([]),newmarks1) 	

	in
	(newmarkedbyr,newmarksr)) in
	{rmap = newrmap;
	 rcmap = newrcmap;
	 graph = newgraph;
	 lmakeup = pd.lmakeup;
	 cmakeup = pd.cmakeup;
	 member = newmember;
	 intersect = newintersect;
	 markers = pd.markers;
	 markedby = newmarkedby;
	 marks = newmarks;
	 lines = pd.lines;
	 circs = pd.circs};;
				 
	
let replace_elt_and_next(elt,list,addlist) =
	if inlist(elt,list)
	then
		let list2 = simple_rotate_to(list,elt) in
		append(addlist,cdr(cdr(list2)))
	else list;;
		
		
let erase_seg(seg,pd) =
	match (pd.graph.emap)(seg) with
		  DotPair(dot1,dot2) when dot1 = dot2 ->
			let nreg = newregion() in
			let ds = ((pd.graph).inc)(dot1) in
			let ds2 = simple_rotate_to(ds,DSSeg(Plain(seg))) in
			let rego = extractDSregion(lastelt(ds2)) in
			let regi = extractDSregion(secondelt(ds2)) in
			let ds3 = striplist(ds2) in
			let ds4 = simple_rotate_to(ds3,DSSeg(Returning(seg))) in
			let newds = striplist(ds4)in
			let newsegs = setremove(seg,(pd.graph).segs) in 
			let newinc = function d ->
				if (d = dot1) & newds = []
				then [Reg(nreg)]
				else if (d = dot1)
				then doublesub(Reg(rego),Reg(regi),Reg(nreg),Reg(nreg),newds)
				else doublesub(Reg(rego),Reg(regi),Reg(nreg),Reg(nreg),((pd.graph).inc)(d))
			in
			let newedgemap = function e ->
				if e = seg
				then NullEnd
				else match ((pd.graph).emap)(e) with
					  Loop(r1,r2) when (r1 = rego) or (r1 = regi) ->
						Loop(nreg,r2)
					| Loop(r1,r2) when (r2 = rego) or (r2 = regi) ->
						Loop(r1,nreg)
					| sse -> sse
			in 
			let newregs = setadjoin(nreg, setremove(regi, setremove(rego, (pd.graph).regs))) in
			let newgraph = 
				{dots = pd.graph.dots;
				 segs = newsegs;
				 inc = newinc;
				 emap = newedgemap;
				 regs = newregs} in
			let regobd = (pd.rmap)(rego) in
			let connectedflag = inlist(Seg(seg),regobd) in
				(* connectedflag = true iff seg is connected to the outside of rego *)
			let regibd = simple_rotate_to((pd.rmap)(regi),Seg(seg)) in
			let newrmap = function reg ->
				match reg with
					  r when r = regi -> []
					| r when r = rego -> []
					| r when r = nreg -> 
						if connectedflag
						then 
							let regobd2 = simple_rotate_to(regobd,Seg(seg)) in
							append(striplist(cdr(regobd2)),cdr(regibd))
						else regobd
					| r -> (pd.rmap)(r)
				in
			let newrcmap = function reg ->
				match reg with
					  r when r = regi -> empty_region_info_struct
					| r when r = rego -> empty_region_info_struct
					| r when r = nreg -> 
						let oibl = ((pd.rcmap)(rego)).int_bd_list in
						let iibl = ((pd.rcmap)(regi)).int_bd_list in
						if connectedflag
						then {int_bd_list = setunion(oibl,iibl)}
						else
							let f = function list -> 
								replace_elt_and_next(Seg(seg),list,cdr(cdr(regibd))) in
							let newoibl = sub_in_list([],[Dot(dot1)],(List.map f oibl)) in
							{int_bd_list = setunion(newoibl,iibl)}
					| r -> (pd.rcmap)(r)
				in
			let newmember = function x ->
				if x = seg then NullGO else (pd.member)(x) in
			let memberof = pd.member(seg) in
			let newintersect = function d ->
				if d = dot1
				then setremove(memberof,(pd.intersect)(d))
				else (pd.intersect)(d) in
	let newmarkedby = function m ->
		match m with 
			RegionSet(rs) ->
				if inset(nreg,rs) 
				then 
					let newrl = setadjoin(rego,
										   setadjoin(regi,setremove(nreg,rs))) in
					let newrl2 = List.fast_sort reg_compare newrl in
					(pd.markedby)(RegionSet(newrl2))
				else (pd.markedby)(RegionSet(rs))
			|Angle(l) ->
				(pd.markedby)(Angle((l)))
			| Dseg(l) -> (pd.markedby)(Dseg(l))
	in
	let newmarks =
		let markerupdate = 
			function  m ->
				match m with 
					RegionSet(rs) ->
						if inset(rego,rs) & inset(regi,rs)
						then
							let newrs = setadjoin(nreg, setremove(rego,setremove(regi,rs))) in
							let newrs2 = List.fast_sort reg_compare newrs in
							(RegionSet(newrs2))
						else if inset(rego,rs) or inset(regi,rs) 
						then
							RegionSet([])  (* This deletes this GO. *)
						else (RegionSet(rs))
					| l -> l
		in
		function m ->
			let oldmarks = (pd.marks)(m) in
			let newmarks1 = List.map markerupdate oldmarks in
			setremove(RegionSet([]),newmarks1) 
	in
			{rmap = newrmap;
			 rcmap = newrcmap;
			 graph = newgraph;
			 lmakeup = pd.lmakeup;
			 cmakeup = pd.cmakeup;
			 member = newmember;
			 intersect = newintersect;
			 markers = pd.markers;
			 markedby = newmarkedby;
			 marks = newmarks;
			 lines = pd.lines;
			 circs = pd.circs}		
			
		| DotPair(dot1,dot2) ->
			let circleflag = 
				(match (pd.member)(seg) with
					Line(dline) -> false
					| Circ(circ) ->  true 
					| _ -> raise BadInput ) in
			let ds11 = ((pd.graph).inc)(dot1) in
			let ds12 = simple_rotate_to(ds11,DSSeg(Plain(seg))) in
			let regl = extractDSregion(lastelt(ds12)) in
			let regr = extractDSregion(secondelt(ds12)) in
			(* regl is on the left side of seg as we walk from dot1 to dot2.  
			   regr is on the right. *)
			if regl = regr then erase_seg_and_disconnect(seg,pd, dot1,dot2,ds12,regl) 
			else 
				let nreg = newregion() in
				let ds13 = striplist(ds12) in
				let newds1 = 
					if ds13 = []
					then [Reg(regl)] 
					else ds13 in
				let ds21 = ((pd.graph).inc)(dot2) in
				let ds22 = simple_rotate_to(ds21,DSSeg(Plain(seg))) in
				let ds23 = striplist(ds22) in
				let newds2 = 
					if ds23 = []
					then [Reg(regl)] 
					else ds23 in			
				let newsegs = setremove(seg,(pd.graph).segs) in 
				let newinc = 
					function d ->
						if (d = dot1) 
						then doublesub(Reg(regl),Reg(regr),Reg(nreg),Reg(nreg),newds1)
						else if (d = dot2)
						then doublesub(Reg(regl),Reg(regr),Reg(nreg),Reg(nreg),newds2)
						else doublesub(Reg(regl),Reg(regr),Reg(nreg),Reg(nreg),((pd.graph).inc)(d))
				in
				let newedgemap = function e ->
					if e = seg
					then NullEnd
					else match ((pd.graph).emap)(e) with
						Loop(r1,r2) when (r1 = regl) or (r1 = regr) ->
							Loop(nreg,r2)
						| Loop(r1,r2) when (r2 = regl) or (r2 = regr) ->
							Loop(r1,nreg)
						| sse -> sse
				in 
				let newregs = setadjoin(nreg, setremove(regl, setremove(regr, (pd.graph).regs))) in
				let newgraph = 
					{dots = pd.graph.dots;
					segs = newsegs;
					inc = newinc;
					emap = newedgemap;
					regs = newregs} in
				let reglbd = (pd.rmap)(regl) in
				let regrbd = (pd.rmap)(regr) in
				let connectedleft = inlist(Seg(seg),reglbd) in
				let connectedright = inlist(Seg(seg),regrbd) in
				(* connected left/right = true iff seg is connected to the outside of 
				   left/right reg *)
				(*  Next, we find boundries of regions.  In the names,
					l/r correspond to the side, and i/o correspond to 
					inner/outer.  We put in dummy empty lists for when
					seg is on the outer boundry but we are finding an inner list
					or seg is on the inner boundry but we are finding an outer list.*)
				let ollist = 
					if connectedleft then simple_rotate_to(reglbd,Seg(seg)) else [] in
				let orlist = 
					if connectedright then simple_rotate_to(regrbd,Seg(seg)) else [] in  
				let illist =
					if connectedleft then [] 
					else simple_rotate_to(dotcomp(dot1,pd,regl),Seg(seg)) in
				let irlist =
					if connectedright then [] 
					else simple_rotate_to(dotcomp(dot1,pd,regr),Seg(seg)) in
				(* Now we compute the outer and (if neccessary) inner boundries of our new region*) 
				let outerbd = 
					match (connectedleft,connectedright) with
						  (true,true) -> append(cdr(cdr(ollist)),cdr(cdr(orlist)))
						| (false,true) -> reglbd
						| (true,false) -> regrbd
						| (false,false) -> raise BadInput (*Should never happen since in this 
															case regl=regr.*)
				in	
				let innerbd = 
					match (connectedleft,connectedright) with
						  (true,true) -> [] (* dummy *)
						| (false,true) -> append(cdr(cdr(illist)),cdr(cdr(orlist)))
						| (true,false) -> append(cdr(cdr(ollist)),cdr(cdr(irlist)))
						| (false,false) -> raise BadInput
				in	
				let newrmap = function reg ->
					match reg with
						  r when r = regl -> []
						| r when r = regr -> []
						| r when r = nreg -> outerbd
						| r -> (pd.rmap)(r)
					in
				let newrcmap = function reg ->
					match reg with
						  r when r = regl -> empty_region_info_struct
						| r when r = regr -> empty_region_info_struct
						| r when r = nreg -> 
							let libl = ((pd.rcmap)(regl)).int_bd_list in
							let ribl = ((pd.rcmap)(regr)).int_bd_list in
							(match (connectedleft,connectedright) with
								  (true, true) -> {int_bd_list = setunion(libl,ribl)}
								| (true, false) ->	
									let f = function list -> 
										if inlist(Seg(seg),list) then innerbd else list in
									let newribl = (List.map f ribl) in
									{int_bd_list = setunion(newribl,libl)}
								| (false, true) ->	
									let f = function list -> 
										if inlist(Seg(seg),list) then innerbd else list in
									let newlibl = (List.map f libl) in
									{int_bd_list = setunion(newlibl,ribl)}
								| _ -> raise BadInput)
						| r -> (pd.rcmap)(r)
					in
				let newmember = function x ->
					if x = seg then NullGO else (pd.member)(x) in
				let memberof = pd.member(seg) in
				let newintersect = function d ->
					if d = dot1 or d=dot2
					then 
						(let dslist = newinc(d) in
						 if goinDSlist(memberof,dslist,pd)
						 then (pd.intersect)(d)
						 else setremove(memberof,(pd.intersect)(d)))
					else (pd.intersect)(d) in
				let (newmarkedby,newmarks) = 
				if circleflag then (pd.markedby,pd.marks)
				else (
				let (pseg1,pseg2) = previoussegs(seg,dot1,dot2, pd) in
				let newmarkedbyr = function m ->
					match m with 
						Dseg(l) ->
							if inset(seg,l) 
							then 
								[]
							else (pd.markedby)(Dseg(l))
						|Angle(l) ->
							let l2 = 
								doublereplaceinlist(l,(dot1,pseg1),(dot1,pseg1)::(dot1,seg)::[],
													  (dot2,pseg2),(dot2,pseg2)::(dot2,seg)::[]) 
							in
							(pd.markedby)(Angle(sort_diang(l2)))
						|RegionSet(rs) ->
							if inset(nreg,rs) 
							then 
								let newrl = setadjoin(regr,
													setadjoin(regl,setremove(nreg,rs))) in
								let newrl2 = List.fast_sort reg_compare newrl in
								(pd.markedby)(RegionSet(newrl2))
							else (pd.markedby)(RegionSet(rs))
							
				in
				let newmarksr =
					let markerupdate = 
						function  m ->
							match m with 
								Dseg(l) ->
									if inset(seg,l) 
									then Angle([]) (* This deletes this GO*)
									else (Dseg(l))
								|Angle(l) ->
									if segdividesangle(seg,l,pd,dot1,pseg1,dot2,pseg2) 
									then Angle([]) 
									else 
										let l2 = 
											doublereplaceinlist(l,(dot1,seg),[],(dot2,seg),[]) in
										Angle(sort_diang(l2))
								|RegionSet(rs) ->
									if inset(regl,rs) & inset(regr,rs)
									then
										let newrs = 
												setadjoin(nreg, setremove(regl,setremove(regr,rs))) in
										let newrs2 = List.fast_sort reg_compare newrs in
										(RegionSet(newrs2))
									else if inset(regl,rs) or inset(regr,rs) 
									then
										Angle([])  (* This deletes this GO. *)
									else (RegionSet(rs))
					in
					function m ->
						let oldmarks = (pd.marks)(m) in
						let newmarks1 = List.map markerupdate oldmarks in
						setremove(Angle([]),newmarks1) 	
				in
				(newmarkedbyr,newmarksr)) in
				{rmap = newrmap;
				 rcmap = newrcmap;
				 graph = newgraph;
				 lmakeup = pd.lmakeup;
				 cmakeup = pd.cmakeup;
				 member = newmember;
				 intersect = newintersect;
				 markers = pd.markers;
				 markedby = newmarkedby;
				 marks = newmarks;
				 lines = pd.lines;
				 circs = pd.circs}		
		| Loop(regi,rego) ->
			let nreg = newregion() in
			let newsegs = setremove(seg,(pd.graph).segs) in 
			let newedgemap = function e ->
				if e = seg
				then NullEnd
				else match ((pd.graph).emap)(e) with
					  Loop(r1,r2) when (r1 = rego) or (r1 = regi) ->
						Loop(nreg,r2)
					| Loop(r1,r2) when (r2 = rego) or (r2 = regi) ->
						Loop(r1,nreg)
					| sse -> sse
			in 
			let newregs = setadjoin(nreg, setremove(regi, setremove(rego, (pd.graph).regs))) in
			let newgraph = 
				{dots = pd.graph.dots;
				 segs = newsegs;
				 inc = pd.graph.inc;
				 emap = newedgemap;
				 regs = newregs} in
			let newrmap = function reg ->
				match reg with
					  r when r = regi -> []
					| r when r = rego -> []
					| r when r = nreg -> (pd.rmap)(rego)
					| r -> (pd.rmap)(r)
				in
			let newrcmap = function reg ->
				match reg with
					  r when r = regi -> empty_region_info_struct
					| r when r = rego -> empty_region_info_struct
					| r when r = nreg -> 
						{int_bd_list = setunion(((pd.rcmap)(regi)).int_bd_list,
												  setremove([Seg(seg)],
															((pd.rcmap)(rego)).int_bd_list))}
					| r -> (pd.rcmap)(r)
				in
			let newmember = function x ->
				if x = seg then NullGO else (pd.member)(x) in
			let newmarkedby = function m ->
		match m with 
			RegionSet(rs) ->
				if inset(nreg,rs) 
				then 
					let newrl = setadjoin(rego,
										   setadjoin(regi,setremove(nreg,rs))) in
					let newrl2 = List.fast_sort reg_compare newrl in
					(pd.markedby)(RegionSet(newrl2))
				else (pd.markedby)(RegionSet(rs))
			|Angle(l) ->
				(pd.markedby)(Angle((l)))
			| Dseg(l) -> (pd.markedby)(Dseg(l))
	in
	let newmarks =
		let markerupdate = 
			function  m ->
				match m with 
					RegionSet(rs) ->
						if inset(rego,rs) & inset(regi,rs)
						then
							let newrs = setadjoin(nreg, setremove(rego,setremove(regi,rs))) in
							let newrs2 = List.fast_sort reg_compare newrs in
							(RegionSet(newrs2))
						else if inset(rego,rs) or inset(regi,rs) 
						then
							RegionSet([])  (* This deletes this GO. *)
						else (RegionSet(rs))
					| l -> l
		in
		function m ->
			let oldmarks = (pd.marks)(m) in
			let newmarks1 = List.map markerupdate oldmarks in
			setremove(RegionSet([]),newmarks1) 
	in
			{rmap = newrmap;
			 rcmap = newrcmap;
			 graph = newgraph;
			 lmakeup = pd.lmakeup;
			 cmakeup = pd.cmakeup;
			 member = newmember;
			 intersect = pd.intersect;
			 markers = pd.markers;
			 markedby = newmarkedby;
			 marks = newmarks;
			 lines = pd.lines;
			 circs = pd.circs}
		| NullEnd -> raise BadInput;;

let rec rec_erase_circle(pd, circle, cm_list) =
	match cm_list with
		  Dot(dot):: rest -> rec_erase_circle(pd, circle, rest)
		| Seg(seg):: rest -> 
			let newpd = erase_seg(seg, pd) in
			rec_erase_circle(newpd,circle, rest)
		| [] ->
			let newcircs = setremove(circle, pd.circs) in
			let newintersect = function d ->
				let oldintersect = (pd.intersect)(d) in
				setremove(Circ(circle),oldintersect)
			in
			let newcmakeup = function c ->
				if c = circle then ([], NullCenter) else (pd.cmakeup)(c) 
			in
			let newpd =
			{rmap = pd.rmap;
			rcmap = pd.rcmap;
			graph = pd.graph;
			lmakeup = pd.lmakeup;
			cmakeup = newcmakeup;
			member = pd.member;
			intersect = newintersect;
			markers = pd.markers;
			markedby = pd.markedby;
			marks = pd.marks;
			lines = pd.lines;
			circs = newcircs}
			in
			pd_register_names(newpd);
			pd_assign_dns(newpd);
			newpd;;


let erase_circle(circle, pd) =
	let cm_list = pi1((pd.cmakeup)(circle)) in
	rec_erase_circle(pd, circle, cm_list);;

let rec rec_erase_line(pd, line, l_list) =
	match l_list with
		  Dot(dot)::Seg(seg)::rest -> 
			if isframedot(dot) 
			then
				let newpd = erase_point(dot,erase_seg(seg,pd)) in
				rec_erase_line(newpd, line, rest)
			else 
				let newpd = erase_seg(seg, pd) in
				rec_erase_line(newpd,line, rest)
		| Dot(dot)::[] ->
			if isframedot(dot) 
			then
				let newpd = erase_point(dot,pd) in
				rec_erase_line(newpd, line, [])
			else 
				rec_erase_line(pd,line,[])
		| [] ->
			let newlines = setremove(line, pd.lines) in
			(*let newintersect = function d ->
				let oldintersect = (pd.intersect)(d) in
				setremove(Line(line),oldintersect)
			in *)
			let newlmakeup = function l ->
				if  l= line then [] else (pd.lmakeup)(l) 
			in
			let newpd =
			{rmap = pd.rmap;
			rcmap = pd.rcmap;
			graph = pd.graph;
			lmakeup = newlmakeup;
			cmakeup = pd.cmakeup;
			member = pd.member;
			intersect = pd.intersect;
			markers = pd.markers;
			markedby = pd.markedby;
			marks = pd.marks;
			lines = newlines;
			circs = pd.circs}
			in
			pd_register_names(newpd);
			pd_assign_dns(newpd);
			newpd
		| _ -> raise BadInput;;

let rec rec_erase_line_ends(pd, line, l_list1,l_list2, l_list3) =
	match l_list1 with
		  Dot(dot)::Seg(seg)::rest -> 
			if isframedot(dot) 
			then
				let newpd = erase_point(dot,erase_seg(seg,pd)) in
				rec_erase_line_ends(newpd, line, rest, l_list2, l_list3)
			else 
				let newpd = erase_seg(seg, pd) in
				rec_erase_line_ends(newpd,line, rest, l_list2, l_list3)
		| [] ->
			(match l_list3 with
				  Seg(seg)::Dot(dot)::rest -> 
					if isframedot(dot) 
					then
						let newpd = erase_point(dot,erase_seg(seg,pd)) in
						rec_erase_line_ends(newpd, line, [],l_list2, rest)
					else 
						let newpd = erase_seg(seg, pd) in
						rec_erase_line_ends(newpd,line, [], l_list2, rest)
				| [] ->
					let newlmakeup = function l ->
						if  l= line then l_list2 else (pd.lmakeup)(l) 
					in
					let newpd =
					{rmap = pd.rmap;
					rcmap = pd.rcmap;
					graph = pd.graph;
					lmakeup = newlmakeup;
					cmakeup = pd.cmakeup;
					member = pd.member;
					intersect = pd.intersect;
					markers = pd.markers;
					markedby = pd.markedby;
					marks = pd.marks;
					lines = pd.lines;
					circs = pd.circs}
					in
					pd_register_names(newpd);
					pd_assign_dns(newpd);
					newpd
				| _ -> raise BadInput)
		| _ -> raise BadInput;;

let erase_line(line, pd) =
	let l_list = (pd.lmakeup)(line) in
	rec_erase_line(pd, line, l_list);;



(* erase_line_ends erases the part of line that doesn't occur between dot1 and dot2 *)
let erase_line_ends(line, dot1, dot2, pd) =
	let l_list = (pd.lmakeup)(line) in
	let (l_list1,l_list2,l_list3) = splitin3(l_list,Dot(dot1),Dot(dot2)) in
	rec_erase_line_ends(pd, line, l_list1,l_list2, l_list3);;
	

(**********************)
(* Construction Rules *)
(**********************)

(* add_dot_to_seg adds a new dot in the middle of the given segment, *)
(* usually breaking it into two new segments*)
let add_dot_to_seg(pd,seg)=
  let container = (pd.member)(seg) in
  let newdot = 
    match seg.ssty with
	Solid -> newdot()
      | Dotted -> newdot()
      | Frame -> newfdot() in
  let lineflag = 
	match seg.ssty with
		Solid -> true
		| _ -> false in
  let ends = pd.graph.emap(seg) in
  let newdots = setadjoin(newdot,pd.graph.dots) in
    match ends with
	DotPair(oldend1,oldend2) ->
	  let newseg1 = 
	    match seg.ssty with
		Solid -> newsseg()
	      | Dotted -> newdottedseg()
	      | Frame -> newfseg() in
	  let newseg2 = 
	    match seg.ssty with
		Solid -> newsseg()
	      | Dotted -> newdottedseg()
	      | Frame -> newfseg() in
	  let pnewseg1 = Plain(newseg1) in
	  let pnewseg2 = Plain(newseg2) in
	  let pseg = Plain(seg) in
	  let newsegs = setadjoin(newseg1,
				  setadjoin(newseg2,
					    setremove(seg,pd.graph.segs))) in
	  let olddslist1 = pd.graph.inc(oldend1) in
	  let olddslist2 = pd.graph.inc(oldend2) in
	  let region1 = 
	    extractDSregion(circular_precedesinlist(DSSeg(pseg),
						    olddslist1)) in
	  let region2 = 
	    extractDSregion(circular_followsinlist(DSSeg(pseg),
						   olddslist1)) in
	  let newdslist1 = sub_in_list(DSSeg(pseg),DSSeg(pnewseg1),olddslist1) in 
	  let newdslist2 = sub_in_list(DSSeg(pseg),DSSeg(pnewseg2),olddslist2) in
	  let newinc = function d ->
	    if d = newdot then 
	      DSSeg(pnewseg1)::Reg(region1)::DSSeg(pnewseg2)::Reg(region2)::[] 
	    else if d = oldend1 && oldend1 = oldend2 then
	      doublesub(DSSeg(Returning(seg)),DSSeg(pseg),DSSeg(pnewseg2),
			DSSeg(pnewseg1),olddslist1) 
	    else if d = oldend1 then newdslist1
	    else if d = oldend2 then newdslist2
	    else pd.graph.inc(d) in  
	  let newemap = extendfunction(extendfunction(pd.graph.emap, 
						      newseg1, 
						      DotPair(oldend1, newdot)),
				       newseg2, 
				       DotPair(newdot,oldend2)) in
	  let newgraph = {dots = newdots;
			  segs = newsegs;
			  inc = newinc;
			  emap = newemap;
			  regs = pd.graph.regs;} in
	  let newrmap = function r ->
	    if (r = region2) 
	    then fix_segs(seg,newseg1,newseg2,oldend1,oldend2,newdot,pd.rmap(r))
	    else if (r = region1)  (*in case we're outside of a loop *)
	    then fix_segs(seg,newseg2,newseg1,oldend2,oldend1,newdot,pd.rmap(r))
	    else pd.rmap(r) in  
	  let newrcmap = function rg -> 
	    match rg with
		r when r = region1 ->
		  let newbdlistset = 
		    fix_segs_listset(seg,newseg2,newseg1,oldend2,oldend1,newdot,
				     (pd.rcmap(r)).int_bd_list)
		  in
		    {int_bd_list = newbdlistset} 
	      | r when r = region2 ->
		  let newbdlistset = 
		    fix_segs_listset(seg,newseg1,newseg2,oldend1,oldend2,newdot,
			    (pd.rcmap(r)).int_bd_list)
		  in
		    {int_bd_list = newbdlistset} 
	      | r -> pd.rcmap(r)
	  in
	  let newlmakeup = function l -> 
	    let old_lmakeup = (pd.lmakeup)(l) in
	      match container with
		  Line(line) when line = l ->
		    let p_dot = precedesinlist(Seg(seg),old_lmakeup) in
		      if p_dot = Dot(oldend1)
		      then replaceinlist(old_lmakeup, Seg(seg), 
					 Seg(newseg1)::Dot(newdot)
					 ::Seg(newseg2)::[])
		      else  replaceinlist(old_lmakeup, Seg(seg), 
					 Seg(newseg2)::Dot(newdot)
					 ::Seg(newseg1)::[])
		| _ -> old_lmakeup
	  in
	  let newcmakeup = function c ->
	    let (dlist,cent) = pd.cmakeup(c) in
	    let new_dlist =
	      match container with
		  Circ(circ) when circ = c ->
		    let p_dot = circular_precedesinlist(Seg(seg),dlist) in
		      if p_dot = Dot(oldend1) 
				   (* correct even if oldend1 = oldend2 *)
		      then replaceinlist(dlist, Seg(seg), 
					 Seg(newseg1)::Dot(newdot)
					 ::Seg(newseg2)::[])
		      else  replaceinlist(dlist, Seg(seg), 
					 Seg(newseg2)::Dot(newdot)
					 ::Seg(newseg1)::[])
		| _ -> dlist
	    in
	      (new_dlist, cent) 
	  in
	  let newmember = function s -> 
	    if (s = newseg1) or (s = newseg2) then container else pd.member(s) in
	  let newintersect = function d ->
	    if d = newdot then 
	      match container with 
		  NullGO -> emptyset 
		| Line(l) -> [Line(l)]
		| Circ(c) -> [Circ(c)]
	    else pd.intersect(d) in
		  let (newmarkedby,newmarks) = 
	if not(lineflag) then (pd.markedby,pd.marks)
	else (
	  let newmarkedbyr = function m ->
	    match m with
		Dseg(set) ->
		  if (inset(newseg1, set) && inset(newseg2,set)) then
		    let newset = setadjoin(seg, 
					   setremove(newseg1, 
						     setremove(newseg2,set))) 
		    in
			let newset2 = List.fast_sort seg_compare newset in
		      pd.markedby(Dseg(newset2))
		  else
		    pd.markedby(Dseg(set))
	      | Angle(a) -> 
				let a2 = doublereplaceinlist(a,(oldend1,newseg1),[(oldend1,seg)],
											   (oldend2,newseg2),[(oldend2,seg)]) in
				let a3 = sort_diang(a2) in
				pd.markedby(Angle(a3))
		  |RegionSet(rs) -> (pd.markedby)(RegionSet(rs))
	  in
	  let newmarksr = function m ->
	    mapmarkedinward(seg,oldend1,newseg1,oldend2,newseg2,pd.marks(m))
	  in
	  (newmarkedbyr,newmarksr)) in
	  let newpd = 
	     {rmap = newrmap;
	      rcmap = newrcmap;
	      graph = newgraph;
	      lmakeup = newlmakeup;
	      cmakeup = newcmakeup;
	      lines = pd.lines;
	      circs = pd.circs;
	      member = newmember;
	      intersect = newintersect;
	      markers = pd.markers;
	      markedby = newmarkedby;
	      marks = newmarks;} in
	    (newdot,pnewseg1,oldend1,oldend2,pnewseg2,newpd)
      | Loop(region1, region2) ->
	  let newdslist = [DSSeg(Plain(seg));Reg(region1);
			   DSSeg(Returning(seg));Reg(region2)] in
	  let newinc = function d ->
	    if d = newdot then newdslist
	    else pd.graph.inc(d) in
	  let newemap = extendfunction(pd.graph.emap, 
				       seg, 
				       DotPair(newdot, newdot)) in
	  let newgraph = {dots = newdots;
			  segs = pd.graph.segs;
			  inc = newinc;
			  emap = newemap;
			  regs = pd.graph.regs;} in
	  let newrmap = function r ->
	    if (r = region1) 
	    then [Seg(seg); Dot(newdot)]
	    else if (r = region2)  
	    then replaceinlist(pd.rmap(r),Seg(seg), 
			       Seg(seg) :: Dot(newdot) ::[]) 
	    else pd.rmap(r) in  
	  let newrcmap = function rg -> 
	    match rg with
		r when r = region2 ->
		  let newbdlistset = 
		    replaceinlistset(Seg(seg), 
				     Seg(seg) :: Dot(newdot) :: [],
				     (pd.rcmap(r)).int_bd_list)
		  in
		    {int_bd_list = newbdlistset;} 
	      | r -> pd.rcmap(r)
	  in
	  let newlmakeup = pd.lmakeup in
	  let newcmakeup = function c ->
	    let (dlist,cent) = pd.cmakeup(c) in
	      (replaceinlist(dlist, Seg(seg), 
			     Seg(seg)::Dot(newdot)::[]),
	       cent) 
	  in
	  let newmember = pd.member in
	  let newintersect = function d ->
	    if d = newdot then 
	      match pd.member(seg) with 
		  NullGO -> emptyset 
		| Circ(c) -> [Circ(c)]
		| Line(l) -> [Line(l)]
	    else pd.intersect(d) in
	  let newmarkedby = pd.markedby in
	  let newmarks = pd.marks in
	    (newdot,
	     Plain(seg),
	     newdot,
	     newdot,
	     Returning(seg),
	     {rmap = newrmap;
	      rcmap = newrcmap;
	      graph = newgraph;
	      lmakeup = newlmakeup;
	      cmakeup = newcmakeup;
	      lines = pd.lines;
	      circs = pd.circs;
	      member = newmember;
	      intersect = newintersect;
	      markers = pd.markers;
	      markedby = newmarkedby;
	      marks = newmarks;
	     })
      |NullEnd -> raise BadInput;;



(* add_dot_to_reg adds a new dot in the interior of the given region *)
let add_dot_to_reg(pd,reg)=
  let newdot = newdot() in
  let newdots = setadjoin(newdot,pd.graph.dots) in
  let newinc = function d ->
    if d = newdot then 
      Reg(reg)::[] 
    else pd.graph.inc(d) in
  let newgraph = {dots = newdots;
		  segs = pd.graph.segs;
		  inc = newinc;
		  emap = pd.graph.emap;
		  regs = pd.graph.regs;} in
  let newrcmap = function rg -> 
    match rg with
	r when r = reg ->
	    {int_bd_list = setadjoin([Dot(newdot)],(pd.rcmap(reg)).int_bd_list);} 
      | r -> pd.rcmap(r)
  in
  let newintersect = function d ->
    if d = newdot then emptyset else pd.intersect(d) 
  in
    (newdot,
     {rmap = pd.rmap;
      rcmap = newrcmap;
      graph = newgraph;
      lmakeup = pd.lmakeup;
      cmakeup = pd.cmakeup;
      lines = pd.lines;
      circs = pd.circs;
      member = pd.member;
      intersect = newintersect;
      markers = pd.markers;
      markedby = pd.markedby;
      marks = pd.marks;
     });;

type prev_seg_type = PSeg of segment| EmptyLineSeg 
		     | EmptyCircleSeg of center;;

let endcheckok(pd,prev_seg) =
  match prev_seg with
      PSeg(segment) ->
	(match pd.member(segment) with
	     Circ(circ) ->
	       (match pd.cmakeup(circ) with
		    (list,CDot(dot)) -> 
		      (centerinsideofcwlist(pd,dot,list) &
		       circle_line_intersections_ok(pd,circ,list))
		  | _ -> raise BadInput)
	   | Line(line) -> line_circle_intersections_ok(pd,line)
	   | _ -> raise BadInput)
    | _ -> raise BadInput;;


(* endfix removes the extra copy of the starting/ending dot from circles when
they are finished.*)
let endfix(pd,prev_seg,dot) =
  match prev_seg with
      PSeg(seg)-> 
	let container = (pd.member)(seg) in 
	  (match container with
	       Line(dline) -> pd
	     | Circ(circ) -> 
		 let newintersect(givendot) =
		   if givendot = dot then cdr((pd.intersect)(dot)) 
		   else (pd.intersect)(givendot) in
		 let newcmakeup(givencirc) =
		   if givencirc = circ then 
		     (match (pd.cmakeup)(circ) with
			  (list,cent)-> (cdr(list),cent)) 
		   else (pd.cmakeup)(givencirc) in
		   {rmap = pd.rmap;
		    rcmap = pd.rcmap;
		    graph = pd.graph;
		    lmakeup = pd.lmakeup;
		    cmakeup = newcmakeup;
		    lines = pd.lines;
		    circs = pd.circs;
		    member = pd.member;
		    intersect = newintersect;
		    markers = pd.markers;
		    markedby = pd.markedby;
		    marks = pd.marks;}
	     | _ -> raise BadInput)
    | _ -> raise BadInput;;




(* possible_extensions finds all possible diagrams in which the *)
(* line going through prev_seg is extended to goal *)
let rec possible_extensions(pd,dot,prev_seg, goal) =
(* pd_assign_dns(pd);
 printpd(pd);  for debugging ............. *)
  if satisfiesgoal(dot, goal) 
  then 
    let newpd = endfix(pd,prev_seg,dot) in
      (if endcheckok(newpd,prev_seg) 
      then  
		(pd_assign_dns(newpd);
		[newpd] )
	  else [])
  else if isframedot(dot) then [] else
    let inclist = pd.graph.inc(dot) in
      match prev_seg with
	  PSeg(segment) -> 
	    (match pd.member(segment) with
		 Line(line) -> 
		   rec_possible_extensions(pd,
					   viable_extensions(inclist,
							     pd.member,
							     Plain(segment)), 
					   dot, Line(line), goal)
	       | Circ(circ) ->
		   rec_possible_extensions(pd,
					   viable_extensions(inclist,
							     pd.member,
							     Plain(segment)), 
					   dot, Circ(circ), goal)
	       | NullGO -> [])
	| EmptyLineSeg -> 
	    let newline = newline() in
	    let newlmakeup = 
	      function l -> 
		if l = newline then [Dot(dot)] else pd.lmakeup(l) in
	    let newintersect = 
	      function d ->
		if d = dot then setadjoin(Line(newline),pd.intersect(dot))
		else pd.intersect(d) in
	    let newlines = setadjoin(newline,pd.lines) in
	    let newpd  = 
	      {rmap = pd.rmap;
	       rcmap = pd.rcmap;
	       graph = pd.graph;
	       lmakeup = newlmakeup;
	       cmakeup = pd.cmakeup;
	       lines = newlines;
	       circs = pd.circs;
	       member = pd.member;
	       intersect = newintersect;
	       markers = pd.markers;
	       markedby = pd.markedby;
	       marks = pd.marks;} in
	      rec_possible_extensions(newpd, rEIify(inclist),
				      dot,Line(newline),goal)
	| EmptyCircleSeg(center) -> 
		if circle_already_drawn(pd, dot, center)
		then [pd]
		else
	    let newcirc = newcirc() in
	    let newcmakeup = 
	      function l -> 
		if l = newcirc then ([Dot(dot)],center) else pd.cmakeup(l) in
	    let newintersect = 
	      function d ->
		if d = dot then setadjoin(Circ(newcirc),pd.intersect(dot))
		else pd.intersect(d) in
	    let newcircs = setadjoin(newcirc,pd.circs) in
	    let newpd  = 
	      {rmap = pd.rmap;
	       rcmap = pd.rcmap;
	       graph = pd.graph;
	       lmakeup = pd.lmakeup;
	       cmakeup = newcmakeup;
	       lines = pd.lines;
	       circs = newcircs;
	       member = pd.member;
	       intersect = newintersect;
	       markers = pd.markers;
	       markedby = pd.markedby;
	       marks = pd.marks;} in
	      rec_possible_extensions(newpd, rEIify(inclist),
				      dot,Circ(newcirc),goal)
and rec_possible_extensions(pd, ext_list, dot, container, goal) = 
    match ext_list with
	SI(seg):: rest ->
	  let newcontainer = pd.member(seg) in
	    (match (newcontainer,container) with
		 (Line(newline),Line(dline)) ->
		   append(extendline(pd,dline,newline, seg, dot, goal), 
			  rec_possible_extensions(pd,rest,dot,container,goal))
	       | _-> rec_possible_extensions(pd,rest,dot,container,goal))
      | RI(rseg1,region,rseg2)::rest -> 
	  append(extendintoregion(pd,RT(rseg1,region,rseg2),dot,container,goal),
		 rec_possible_extensions(pd,rest,dot,container,goal))
      | SR(region)::rest -> 
	  append(extendintoregion(pd,SingReg(region),dot,container,goal), 
		 rec_possible_extensions(pd,rest,dot,container,goal))
      | _ -> []
(* extendline continues the oldline along the newline *)
and extendline(pd,oldline,newline, newseg, dot, goal) =
  let oldlinelist = pd.lmakeup(oldline) in
  let newlinelist = pd.lmakeup(newline) in
  let firstold = firstelt(oldlinelist) in
  let firstnew = firstelt(newlinelist) in
  let fixedoldlinelist = 
    if firstold = Dot(dot)
    then List.rev(oldlinelist)
    else oldlinelist
  in
  let  fixednewlinelist =
    if firstnew = Dot(dot)
    then newlinelist
    else List.rev(newlinelist)
  in
  let (first,shortnewlinelist) = 
    match fixednewlinelist with 
	outfirst::outshort -> (outfirst,outshort)
      | _ -> raise BadInput in
  let totallist = 
	if first = Dot(dot) 
	then
		append(fixedoldlinelist, shortnewlinelist) 
	else(* This happens if dot is in the middle of newline, 
	        which should only happen if we are starting a new segment at dot
			and we start along a pre-existing line that the dot is on *)
		if precedesinlist(Dot(dot),newlinelist) = Seg(newseg)
		then List.rev(newlinelist)
		else newlinelist
  in
    Hashtbl.clear intersects_array;
    if intersectokline(totallist,
		       pd.intersect,
		       intersects_array,
		       ExceptPair(oldline.lnum,newline.lnum),
		       Line(oldline)) 
    then
      let newlmakeup = 
	function x ->
	  if x = oldline then totallist else pd.lmakeup(x) in
      let newmembermap =
	function x ->
	  let oldval = pd.member(x) in
	    if oldval = Line(newline) then Line(oldline) else oldval
      in
      let newintersectmap = 
			function d ->
				if d = dot
				then
					setremove(Line(newline),(pd.intersect)(d))
				else
				sub_in_list(Line(newline),Line(oldline),pd.intersect(d))
      in	  
      let newpd = 
	{rmap = pd.rmap;
	 rcmap = pd.rcmap;
	 graph = pd.graph;
	 lmakeup = newlmakeup;
	 cmakeup = pd.cmakeup;
	 lines = setremove(newline,pd.lines);
	 circs = pd.circs;
	 member = newmembermap;
	 intersect = newintersectmap;
	 markers = pd.markers;
	 markedby = pd.markedby;
	 marks = pd.marks;} 
      in
      let (newseg,newdot) =
	match  lasttwoelts(totallist) with
	    (Seg(nseg),Dot(ndot)) -> (nseg,ndot)
	  | _ -> raise BadInput 
      in
	possible_extensions(newpd,newdot,PSeg(newseg),goal)
    else []
(* There are four case to consider when extending a line:  *)
(* The starting dot could be on the outer edge of the region being *)
(* extended into, or it could be in the interior; likewise the *)
(* dot extended to could be on the outside or inside of the region.  *)
(* So we have four functions for the four cases: *)
(* rec_extend_thru_reg  o->o   *)
(*            into      o->i   *)
(*            out       i->o   *)
(*            inside    i->i   *)
(*
	In each of the following functions
		pd = the diagram
		ereg = the region being entered from the dot 
		dot = dot we are starting at
		container = the line or circle being extended
		goal = goal
	and in later functions
		delist = list of segs/dots on boundry of ereg
*)
and extendintoregion(pd,ereg,dot,container,goal) =
  let region = extractregion(ereg) in
  if region.rname="outerregion" then [] 
  else
    let delist = dEIify(pd.rmap(region),Out,pd) in
    let intlist = (pd.rcmap(region)).int_bd_list in
      if edge_elt(dot,pd,region) then
	append(rec_extend_thru_reg(pd,ereg,
				   dot,container,goal,delist),
	       rec_extend_into_reg(pd,ereg,
				   dot,container,goal,intlist))
      else 
	let dcomp = dotcomp(dot,pd,region) in
	  append(rec_extend_out_reg(pd,ereg,
				    dot,container,goal,delist,dcomp),
		 rec_extend_inside_reg(pd,ereg,
				       dot,container,goal,intlist,dcomp))
and rec_extend_thru_reg(pd,ereg,dot,container,goal,delist) =
  match delist with
      DI(ndseg1,newdot,ndseg2)::rest ->
	if ((unsafetohitdot(pd,container,newdot,goal)))
	then rec_extend_thru_reg(pd,ereg,dot,container,goal,rest)
	else append(joinodots(pd,ereg,
			      dot,DT(ndseg1,newdot,ndseg2),container,goal),
		    rec_extend_thru_reg(pd,ereg,dot,
					container,goal,rest))
    | SD(newdot)::rest ->
	if ((newdot = dot) or (unsafetohitdot(pd,container,newdot,goal)))
	then rec_extend_thru_reg(pd,ereg,dot,container,goal,rest)
	else append(joinodots(pd,ereg,
			      dot,SingDot(newdot),container,goal),
		    rec_extend_thru_reg(pd,ereg,dot,
					container,goal,rest))
    | SSI(seg)::rest ->
	if (unsafetohitseg(pd,container,seg,goal))
	then rec_extend_thru_reg(pd,ereg,dot,container,goal,rest)
	else append(joinodotseg(pd,ereg,dot,SingSeg(seg),container,goal),
		    rec_extend_thru_reg(pd,ereg,
					dot,container,goal,rest))
    | STI(dot1,seg,dot2)::rest ->
	if (unsafetohitseg(pd,container,seg,goal))
	then rec_extend_thru_reg(pd,ereg,dot,container,goal,rest)
	else append(joinodotseg(pd,ereg,dot,ST(dot1,seg,dot2),container,goal),
		    rec_extend_thru_reg(pd,ereg,
					dot,container,goal,rest))
    | _ -> []
and joinodotseg(pd,ereg,dot,eseg,container,goal) = 
  let region = extractregion(ereg) in
  let seg = extractsegment(eseg) in
  let (newdot,newseg1,segend1,segend2,newseg2, newpd) = add_dot_to_seg(pd,seg) in
  let newereg = 
    if dot = segend1 & dot = segend2 
    then replaceinRT(replaceinRT(ereg,Plain(seg),newseg1),
		     Returning(seg),newseg2)
    else if dot = segend1 
    then replaceinRT(ereg,Plain(seg),newseg1)
    else if dot = segend2
    then replaceinRT(ereg,Plain(seg),newseg2)
    else ereg 
in
    match eseg with
	ST(dot1,ss,dot2) when dot1 = dot2 ->
	  let prec = circular_precedesinlist(DSSeg(newseg2),
					     ((newpd.graph).inc)(dot1)) in
	    if prec = Reg(region)
	    then joinodots(newpd,newereg,dot,DT(newseg1,newdot,newseg2),
			   container,goal)
	    else joinodots(newpd,newereg,dot,DT(newseg2,newdot,newseg1),
			   container,goal)
      | ST(dot1,ss,dot2) ->
	  if segend1 = dot1 
	  then joinodots(newpd,newereg,dot,DT(newseg1,newdot,newseg2),
			   container,goal)
	  else  joinodots(newpd,newereg,dot,DT(newseg2,newdot,newseg1),
			   container,goal)
      | _ -> raise BadInput
(* joinodots assumes that both dots are on the boundry of the region *)
and joinodots(pd,ereg,dot,enewdot,container,goal) =
  let region = extractregion(ereg) in
  let newdot = extractdot(enewdot) in
(*   printpd(pd);   for debugging ................... *)
  let newregion1 = newregion() in
  let newregion2 = newregion() in
  let oldedgelist = pd.rmap(region) in
  let dboldlist = append(oldedgelist,append(oldedgelist,oldedgelist)) in
  let eolddot = exreg2exdot(eflip(ereg),dot) in
  let samedot_diffangle = ((dot = newdot) & not(eolddot = enewdot)) in
    match samedot_diffangle with
	false -> 
 (let (firsthalf,secondhalf) = 
    if eolddot = enewdot then ([Dot(dot)],rotateto(dboldlist,enewdot))
    else 
      tsplit(dboldlist,
	     eolddot,
	     enewdot) in
  let circleflag = 
	 match container with
	Line(dline) -> false
      | Circ(circ) ->  true 
      | _ -> raise BadInput in
  let newseg = if circleflag then newdottedseg() else newsseg() in
  let pnewseg = Plain(newseg) in
  let newedgelist1 = Seg(newseg)::firsthalf in
  let newedgelist2 = Seg(newseg)::secondhalf in
  let newsegset = setadjoin(newseg,pd.graph.segs) in
  let newedgemap = function seg -> 
    if seg = newseg then DotPair(dot,newdot) else pd.graph.emap(seg) in
  let oldinc = pd.graph.inc in
  let olddslist1 = oldinc(dot) in
  let olddslist2 = oldinc(newdot) in
  let newdslist1 = 
    rep_reg(ereg,
	    [Reg(newregion1);DSSeg(pnewseg);Reg(newregion2)],
	    olddslist1) in
  let newdslist2 = 
    rep_reg(eflip(exdot2exreg(enewdot,region)),
	    [Reg(newregion2);DSSeg(pnewseg);Reg(newregion1)],
	    olddslist2) in
  let eqdslist = 
    rep_reg(ereg,
	    [Reg(newregion2);DSSeg(Plain(newseg));Reg(newregion1);
	     DSSeg(Returning(newseg));
	     Reg(newregion2)],
	    olddslist1) in
  let (moddslist1,moddslist2) = 
    if eolddot = enewdot  (* we're returning to same sect. of same dot *)
    then (eqdslist,eqdslist)
    else (newdslist1,newdslist2) in
(*  let fixeddslist1 =      fix_regions(region,newregion1,newregion2,
		  firsthalf,newdslist1,dot,Reverse) in 
  let fixeddslist2 =      fix_regions(region,newregion1,newregion2,
		  firsthalf,newdslist2,newdot,Reverse) in 
	for debugging ............... *) 
  let newinc = function d ->
    if (d = dot) then 
      fix_regions(region,newregion1,newregion2,
		  firsthalf,moddslist1,d,Reverse) 
    else if (d = newdot) then  
      fix_regions(region,newregion1,newregion2,
		  firsthalf,moddslist2,d,Reverse) 
    else 
      fix_regions(region,newregion1,newregion2,
		  firsthalf,pd.graph.inc(d),d,Reverse) in
  let newregs = setadjoin(newregion1,
			  setadjoin(newregion2, 
				    setremove(region,pd.graph.regs))) in
  let newgraphstruct = {dots = pd.graph.dots;
			segs = newsegset;
			inc = newinc;
			emap = newedgemap;
			regs = newregs} in
  let newrmap = function r ->
    if r = newregion1 then newedgelist1
    else if r = newregion2 then newedgelist2
    else pd.rmap(r) in
  let newlmakeup = 
    match container with 
	Line(dline) -> 
	  (function l -> 
	    if l = dline 
	    then 
	      let oldlist = pd.lmakeup(dline) in
		match oldlist with
		    first::rest when first = Dot(dot) -> 
		      Dot(newdot)::Seg(newseg)::oldlist
		  | first::rest -> append(oldlist, [Seg(newseg); Dot(newdot)])
		  | _ -> raise BadInput
	    else pd.lmakeup(l)) 
      | Circ(circ) -> pd.lmakeup 
      | _ -> raise BadInput in
  let newcmakeup = 
    match container with 
	Circ(circ) -> 
	  (function c -> 
	    if c = circ 
	    then 
	      let (oldlist,center) = pd.cmakeup(circ) in
		match oldlist with
		    first::rest when first = Dot(dot) -> 
		      (Dot(newdot)::Seg(newseg)::oldlist,center)
			(* if this is finishing off a circle, it will have *)
			(* to be fixed later. *)
		  | first::rest -> 
		      (append(oldlist, [Seg(newseg); Dot(newdot)]),center)
		  | _ -> raise BadInput
	    else pd.cmakeup(c)) 
      | Line(dline) -> pd.cmakeup 
      | _ -> raise BadInput in
  let newmember = function s -> 
    if s = newseg then container else pd.member(s) in
  let newintersect = 
    function d ->
	  if d = newdot then setadjoin(container, pd.intersect(newdot))
      else pd.intersect(d) in
  let innards =  (pd.rcmap(region)).int_bd_list in
  let newregion1struct =  empty_region_info_struct in
  let newregion2struct = empty_region_info_struct in
  let newrcmap = 
    function r ->
      if (r = newregion1) then newregion1struct 
      else if (r = newregion2) then newregion2struct 
      else pd.rcmap(r) 
  in
    let (newmarkedby,newmarks) = 
	if circleflag then (pd.markedby,pd.marks)
	else (
  let sds1 = ssegextract(newinc(dot)) in
  let sds2 = ssegextract(newinc(newdot)) in
  let pseg1 = circular_precedesinlist(newseg,sds1) in
  let pseg2 = circular_precedesinlist(newseg,sds2) in
  let newmarkedbyr = function m ->
		match m with 
			Dseg(l) -> (pd.markedby)(Dseg(l))
			|Angle(l) ->
				if segdividesangle(newseg,l,pd,dot,pseg1,newdot,pseg2) 
				then [] 
				else 
					let l2 = 
						doublereplaceinlist(l,(dot,newseg),[],(newdot,newseg),[]) in
					(pd.markedby)(Angle(sort_diang(l2)))
			| RegionSet(rs) ->
				if inset(newregion1,rs) & inset(newregion2,rs)
				then
					let newrs = 
							setadjoin(region, setremove(newregion1,setremove(newregion2,rs))) in
					let newrs2 = List.fast_sort reg_compare newrs in
					pd.markedby(RegionSet(newrs2))
				else pd.markedby(RegionSet(rs))
	in
	let newmarksr =
		let markerupdate = 
			function  m ->
				match m with 
					Dseg(l) -> Dseg(l)
					|Angle(l) ->
						let l2 = 
							doublereplaceinlist(l,(dot,pseg1),(dot,pseg1)::(dot,newseg)::[],
												(newdot,pseg2),(newdot,pseg2)::(newdot,newseg)::[]) in
						Angle(sort_diang(l2))
					|RegionSet(rs) ->
							if inset(region,rs) 
							then 
								let newrl = setadjoin(newregion1,
													setadjoin(newregion2,setremove(region,rs))) in
								let newrl2 = List.fast_sort reg_compare newrl in
								(RegionSet(newrl2))
							else (RegionSet(rs))
		in
		function m ->
			let oldmarks = (pd.marks)(m) in
			let newmarks1 = List.map markerupdate oldmarks in
			newmarks1
	in
	(newmarkedbyr,newmarksr))in
  let newpd ={rmap = newrmap;
				  rcmap = newrcmap;
				  graph = newgraphstruct;
				  lmakeup = newlmakeup;
				  cmakeup = newcmakeup;
				  lines = pd.lines;
				  circs = pd.circs;
				  member = newmember;
				  intersect = newintersect;
				  markers = pd.markers;
				  markedby = newmarkedby;
				  marks = newmarks} in
  let list = distribute_innards([newpd], 
				newregion1,
				newregion2,
				innards,
				region) in
  let f = function diagram -> 
    possible_extensions(diagram,newdot,PSeg(newseg),updategoal(goal)) 
  in
    List.concat(List.map f list))
      | true ->
 (let (firsthalf,secondhalf) = 
    if eolddot = enewdot then ([Dot(dot)],rotateto(dboldlist,enewdot))
    else 
      tsplit(dboldlist,
	     eolddot,
	     enewdot) in
  let circleflag = 
	 match container with
	Line(dline) -> false
      | Circ(circ) ->  true 
      | _ -> raise BadInput in
  let newseg = if circleflag then newdottedseg() else newsseg() in
  let pnewseg = Plain(newseg) in
  let newedgelist1 = Seg(newseg)::firsthalf in
  let newedgelist2 = Seg(newseg)::secondhalf in
  let newsegset = setadjoin(newseg,pd.graph.segs) in
  let newedgemap = function seg -> 
    if seg = newseg then DotPair(dot,newdot) else pd.graph.emap(seg) in
  let oldinc = pd.graph.inc in
  let olddslist1 = oldinc(dot) in
(*  let olddslist2 = oldinc(newdot) in *)
  let jdequallist1 = 
    rep_reg(eflip(exdot2exreg(enewdot,region)),
	    [Reg(newregion2);DSSeg(Returning(newseg));Reg(newregion1)],
(* Sometimes labels the wrong side as returning, but that *)
(* one gets pruned when circles are checked. *)
	    rep_reg(ereg,
		    [Reg(newregion1);DSSeg(pnewseg);Reg(newregion2)],
		    olddslist1)) in
 (* let jdequallist2 = 
    rep_reg(eflip(exdot2exreg(enewdot,region)),
	    [Reg(newregion2);DSSeg(pnewseg);Reg(newregion1)],
	    rep_reg(ereg,
		    [Reg(newregion1);DSSeg(Returning(newseg));Reg(newregion2)],
		    olddslist1)) in *)
  let newinc = function d ->
    if (d = dot) then 
      fix_regions(region,newregion1,newregion2,
		  firsthalf,jdequallist1,d,Reverse) 
    else 
      fix_regions(region,newregion1,newregion2,
		  firsthalf,pd.graph.inc(d),d,Reverse) in
(*  let newinc2 = function d ->
    if (d = dot) then 
      fix_regions(region,newregion1,newregion2,
		  firsthalf,jdequallist2,d,Reverse) 
    else 
      fix_regions(region,newregion1,newregion2,
		  firsthalf,pd.graph.inc(d),d,Reverse) in *)
  let newregs = setadjoin(newregion1,
			  setadjoin(newregion2, 
				    setremove(region,pd.graph.regs))) in
  let newgraphstruct = {dots = pd.graph.dots;
			segs = newsegset;
			inc = newinc;
			emap = newedgemap;
			regs = newregs} in
  (*let newgraphstruct2 = {dots = pd.graph.dots;
			segs = newsegset;
			inc = newinc2;
			emap = newedgemap;
			regs = newregs} in *)
  let newrmap = function r ->
    if r = newregion1 then newedgelist1
    else if r = newregion2 then newedgelist2
    else pd.rmap(r) in
  let newlmakeup = 
    match container with 
	Line(dline) -> 
	  (function l -> 
	    if l = dline 
	    then 
	      let oldlist = pd.lmakeup(dline) in
		match oldlist with
		    first::rest when first = Dot(dot) -> 
		      Dot(newdot)::Seg(newseg)::oldlist
		  | first::rest -> append(oldlist, [Seg(newseg); Dot(newdot)])
		  | _ -> raise BadInput
	    else pd.lmakeup(l)) 
      | Circ(circ) -> pd.lmakeup 
      | _ -> raise BadInput in
  let newcmakeup = 
    match container with 
	Circ(circ) -> 
	  (function c -> 
	    if c = circ 
	    then 
	      let (oldlist,center) = pd.cmakeup(circ) in
		match oldlist with
		    first::rest when first = Dot(dot) -> 
		      (Dot(newdot)::Seg(newseg)::oldlist,center)
			(* if this is finishing off a circle, it will have *)
			(* to be fixed later. *)
		  | first::rest -> 
		      (append(oldlist, [Seg(newseg); Dot(newdot)]),center)
		  | _ -> raise BadInput
	    else pd.cmakeup(c)) 
      | Line(dline) -> pd.cmakeup 
      | _ -> raise BadInput in
  let newmember = function s -> 
    if s = newseg then container else pd.member(s) in
  let newintersect = 
    function d ->
      if d = newdot then setadjoin(container, pd.intersect(newdot))
      else pd.intersect(d) in
  let innards =  (pd.rcmap(region)).int_bd_list in
  let newregion1struct =  empty_region_info_struct in
  let newregion2struct = empty_region_info_struct in
  let newrcmap = 
    function r ->
      if (r = newregion1) then newregion1struct 
      else if (r = newregion2) then newregion2struct 
      else pd.rcmap(r) 
  in
    let (newmarkedby,newmarks) = 
	if circleflag then (pd.markedby,pd.marks)
	else (
  let sds1 = ssegextract(newinc(dot)) in
  let sds2 = ssegextract(newinc(newdot)) in
  let pseg1 = circular_precedesinlist(newseg,sds1) in
  let pseg2 = circular_precedesinlist(newseg,sds2) in
  let newmarkedbyr = function m ->
		match m with 
			Dseg(l) -> (pd.markedby)(Dseg(l))
			|Angle(l) ->
				if segdividesangle(newseg,l,pd,dot,pseg1,newdot,pseg2) 
				then [] 
				else 
					let l2 = 
						doublereplaceinlist(l,(dot,newseg),[],(newdot,newseg),[]) in
					(pd.markedby)(Angle(sort_diang(l2)))
			| RegionSet(rs) ->
				if inset(newregion1,rs) & inset(newregion2,rs)
				then
					let newrs = 
							setadjoin(region, setremove(newregion1,setremove(newregion2,rs))) in
					let newrs2 = List.fast_sort reg_compare newrs in
					pd.markedby(RegionSet(newrs2))
				else pd.markedby(RegionSet(rs))
	in
	let newmarksr =
		let markerupdate = 
			function  m ->
				match m with 
					Dseg(l) -> Dseg(l)
					|Angle(l) ->
						let l2 = 
							doublereplaceinlist(l,(dot,pseg1),(dot,pseg1)::(dot,newseg)::[],
												(newdot,pseg2),(newdot,pseg2)::(newdot,newseg)::[]) in
						Angle(sort_diang(l2))
					|RegionSet(rs) ->
							if inset(region,rs) 
							then 
								let newrl = setadjoin(newregion1,
													setadjoin(newregion2,setremove(region,rs))) in
								let newrl2 = List.fast_sort reg_compare newrl in
								(RegionSet(newrl2))
							else (RegionSet(rs))
		in
		function m ->
			let oldmarks = (pd.marks)(m) in
			let newmarks1 = List.map markerupdate oldmarks in
			newmarks1
	in
	(newmarkedbyr,newmarksr)) in
  let newpd ={rmap = newrmap;
				  rcmap = newrcmap;
				  graph = newgraphstruct;
				  lmakeup = newlmakeup;
				  cmakeup = newcmakeup;
				  lines = pd.lines;
				  circs = pd.circs;
				  member = newmember;
				  intersect = newintersect;
				  markers = pd.markers;
				  markedby = newmarkedby;
				  marks = newmarks} in
  let list = distribute_innards([newpd], 
				newregion1,
				newregion2,
				innards,
				region) in
 (* let list2 = distribute_innards([{rmap = newrmap;
				  rcmap = newrcmap;
				  graph = newgraphstruct2;
				  lmakeup = newlmakeup;
				  cmakeup = newcmakeup;
				  lines = pd.lines;
				  circs = pd.circs;
				  member = newmember;
				  intersect = newintersect;
				  markers = pd.markers;
				  markedby = pd.markedby;
				  marks = pd.marks}], 
				newregion1,
				newregion2,
				innards,
				region) in *)
  let f = function diagram -> 
    possible_extensions(diagram,newdot,PSeg(newseg),updategoal(goal)) 
  in
(*    append(List.concat(List.map f list),List.concat(List.map f list2)))*)
    List.concat(List.map f list))
and distribute_innards(set,region1,region2,innards, oldregion) = 
  match innards with 
      first::rest -> 
	let newset = dist1comp(first,set,region1,region2,oldregion) in
	  distribute_innards(newset,region1,region2,rest,oldregion)
    | _ -> set
and dist1comp(comp,set,region1,region2,oldregion) = 
  match set with
      first::rest ->
	(* pd_assign_dns(first);    
	printpd(first);   for debugging *)
	let (newemap1,newemap2) = 
	  match comp with
	      Seg(singseg)::[] ->
		(match first.graph.emap(singseg) with
		     Loop(oldinnerreg,oldouterreg) ->
		       ((function seg ->
			   if seg = singseg then Loop(oldinnerreg,region1)
			   else first.graph.emap(seg)),
			(function seg ->
			   if seg = singseg then Loop(oldinnerreg,region1)
			   else first.graph.emap(seg)))
		   | _ -> raise BadInput)
	    | _ -> (first.graph.emap,first.graph.emap) in
	let newinc1 = 
	  function dot -> 
	    if inlist(Dot(dot),comp) 
	    then sub_in_list(Reg(region2),Reg(region1),first.graph.inc(dot))
		(* oldregion already got changed to region2 by fix_regions*)(*changed 5/12/2010*)
	    else first.graph.inc(dot) in
	let newinc2 = 
		first.graph.inc in
	(* function dot -> 
	    if inlist(Dot(dot),comp) 
	    then sub_in_list(Reg(oldregion),Reg(region2),first.graph.inc(dot))
	    else first.graph.inc(dot) in *)
	let newgraph1 = {dots = first.graph.dots;
			 segs = first.graph.segs;
			 inc = newinc1;
			 emap = newemap1;
			 regs = first.graph.regs;} in
	let newgraph2 = {dots = first.graph.dots;
			 segs = first.graph.segs;
			 inc = newinc2;
			 emap = newemap2;
			 regs = first.graph.regs;} in
	let oldcomp1 = (first.rcmap(region1)).int_bd_list in
	let oldcomp2 = (first.rcmap(region2)).int_bd_list in
	let newcomp1 = comp :: oldcomp1 in
	let newcomp2 = comp :: oldcomp2 in
	let newristruct1 = {int_bd_list = newcomp1;} in
	let newristruct2 = {int_bd_list = newcomp2;} in
	let newrcmap1 = 
	  function r ->
	    if r = region1 then newristruct1 else first.rcmap(r) in
	let newrcmap2 = 
	  function r ->
	    if r = region2 then newristruct2 else first.rcmap(r) in
	let newpd1 = 
	  {rmap = first.rmap;
	   rcmap = newrcmap1;
	   graph = newgraph1;
	   lmakeup = first.lmakeup;
	   cmakeup = first.cmakeup;
	   lines = first.lines;
	   circs = first.circs;
	   member = first.member;
	   intersect = first.intersect;
	   markers = first.markers;
	   markedby = first.markedby;
	   marks = first.marks} in
	let newpd2 = 
	  {rmap = first.rmap;
	   rcmap = newrcmap2;
	   graph = newgraph2;
	   lmakeup = first.lmakeup;
	   cmakeup = first.cmakeup;
	   lines = first.lines;
	   circs = first.circs;
	   member = first.member;
	   intersect = first.intersect;
	   markers = first.markers;
	   markedby = first.markedby;
	   marks = first.marks} 
	in
	  newpd1 :: newpd2 :: dist1comp(comp,rest,region1,region2,oldregion)
    | _ -> emptyset
and rec_extend_into_reg(pd,ereg,dot,container,goal,intlist) =
  match intlist with
      first::rest ->  
	append(extend_odot_to_comp(pd,ereg,dot,
				   container,goal,first),
	       rec_extend_into_reg(pd,ereg,dot,container,goal,rest))
    | _ -> []
and extend_odot_to_comp(pd,ereg,dot,container,goal,comp) = 
  rec_extend_odot_to_comp(pd,ereg,dot,container,goal,
			  dEIify(comp,In,pd),comp)
and rec_extend_odot_to_comp(pd,ereg,dot,container,goal,
			    comp,origcomp) =
  match comp  with
      DI(ndseg1,newdot,ndseg2)::rest ->
	if ((unsafetohitdot(pd,container,newdot,goal)))
	then rec_extend_odot_to_comp(pd,ereg,
				     dot,container,goal,rest,origcomp)
	else append(joinoidots(pd,ereg,dot,DT(ndseg1,newdot,ndseg2),
			       container,goal,origcomp,OI),
		    rec_extend_odot_to_comp(pd,ereg,dot,
					    container,goal,rest,origcomp))
    | SD(newdot)::rest ->
	if ((unsafetohitdot(pd,container,newdot,goal)))
	then rec_extend_odot_to_comp(pd,ereg,
				     dot,container,goal,rest,origcomp)
	else append(joinoidots(pd,ereg,
			       dot,SingDot(newdot),container,goal,origcomp,OI),
		    rec_extend_odot_to_comp(pd,ereg,dot,
					    container,goal,rest,origcomp))
    | SSI(seg)::rest ->
	if (unsafetohitseg(pd,container,seg,goal))
	then rec_extend_odot_to_comp(pd,ereg,
				     dot,container,goal,rest,origcomp)
	else append(joinoidotseg(pd,ereg,dot,SingSeg(seg),container,goal),
		    rec_extend_odot_to_comp(pd,ereg,
					    dot,container,goal,rest,origcomp))
    | STI(dot1,seg,dot2)::rest ->
	if (unsafetohitseg(pd,container,seg,goal))
	then rec_extend_odot_to_comp(pd,ereg,
				     dot,container,goal,rest,origcomp)
	else append(joinoidotseg(pd,ereg,dot,ST(dot1,seg,dot2),container,goal),
		    rec_extend_odot_to_comp(pd,ereg,
					    dot,container,goal,rest,origcomp))
    | _ -> []
and joinoidotseg(pd,ereg,dot,eseg,container,goal) = 
  let region = extractregion(ereg) in
  let seg = extractsegment(eseg) in
  let (newdot,newseg1,segend1,segend2,newseg2, newpd) = add_dot_to_seg(pd,seg) in
    match eseg with
	SingSeg(ss) ->
	  let prec = circular_precedesinlist(Reg(region),
					     ((newpd.graph).inc)(newdot)) in
	    if prec = DSSeg(newseg2) 
	    then joinoidots(newpd,ereg,dot,DT(newseg1,newdot,newseg2),
			    container,goal,dotcomp(newdot,newpd,region),OI)
	    else joinoidots(newpd,ereg,dot,DT(newseg2,newdot,newseg1),
			    container,goal,dotcomp(newdot,newpd,region),OI)
      | ST(dot1,ss,dot2) when dot1 = dot2 ->
	  joinoidots(newpd,ereg,dot,DT(newseg2,newdot,newseg1),
		     container,goal,dotcomp(newdot,newpd,region),OI)
	    (* since we're approching from the outside *)
      | ST(dot1,ss,dot2) ->
	  if segend1 = dot1 
	    then joinoidots(newpd,ereg,dot,DT(newseg1,newdot,newseg2),
			    container,goal,dotcomp(newdot,newpd,region),OI)
	    else joinoidots(newpd,ereg,dot,DT(newseg2,newdot,newseg1),
			    container,goal,dotcomp(newdot,newpd,region),OI)
and joinoidots(pd,ereg,dot,enewdot,
	       container,goal,comp,calledfrom) =
(*	printpd(pd);  for debugging *)
  let newdot = extractdot(enewdot) in
  let region = extractregion(ereg) in
  let oldedgelist = pd.rmap(region) in
  let dboldlist = append(append(oldedgelist,oldedgelist),oldedgelist) in
  let outlist = rotateto(dboldlist,
			exreg2exdot(eflip(ereg),dot)) in  
  let dbcomplist = append(comp,append(comp,comp)) in
  let inlist = rotateto(dbcomplist,
			enewdot) in
  let circleflag = 
	 match container with
	Line(dline) -> false
      | Circ(circ) ->  true 
      | _ -> raise BadInput in
  let newseg = if circleflag then newdottedseg() else newsseg() in
  let pnewseg = Plain(newseg) in
  let newedgelist = append(outlist,append(Seg(newseg)::inlist,[Seg(newseg)])) in
  let newsegset = setadjoin(newseg,pd.graph.segs) in
  let newedgemap = function seg -> 
    if seg = newseg then DotPair(dot,newdot) else pd.graph.emap(seg) in
  let oldinc = pd.graph.inc in
  let olddslist1 = oldinc(dot) in
  let olddslist2 = oldinc(newdot) in
  let newdslist1 = 
    rep_reg(ereg,
	    [Reg(region);DSSeg(pnewseg);Reg(region)],
	    olddslist1) in
  let newdslist2 = 
    rep_reg(eflip(exdot2exreg(enewdot,region)),
	    [Reg(region);DSSeg(pnewseg);Reg(region)],
	    olddslist2) in
  let newinc = function d ->
    if (d = dot) then newdslist1
    else if (d = newdot) then newdslist2 
    else oldinc(d) in
  let newgraphstruct = {dots = pd.graph.dots;
			segs = newsegset;
			inc = newinc;
			emap = newedgemap;
			regs = pd.graph.regs} in
  let newrmap = function r ->
    if r = region then newedgelist
    else pd.rmap(r) in
  let newlmakeup = 
    match container with 
	Line(dline) -> 
	  (function l -> 
	    if l = dline 
	    then 
	      let oldlist = pd.lmakeup(dline) in
		match (oldlist,calledfrom) with
		    (first::rest,OI) when first = Dot(dot) -> 
		      Dot(newdot)::Seg(newseg)::oldlist
		  | (first::rest,OI) -> 
		      append(oldlist, [Seg(newseg); Dot(newdot)])
		  | (first::rest,IO) when first = Dot(newdot) -> 
		      Dot(dot)::Seg(newseg)::oldlist
		  | (first::rest,IO) -> 
		      append(oldlist, [Seg(newseg); Dot(dot)])
		  | _ -> raise BadInput
	    else pd.lmakeup(l)) 
      | Circ(circ) -> pd.lmakeup 
      | _ -> raise BadInput in
  let newcmakeup = 
    match container with 
	Circ(circ) -> 
	  (function c -> 
	    if c = circ 
	    then 
	      let (oldlist,center) = pd.cmakeup(circ) in
		match (oldlist,calledfrom) with
		    (first::rest, OI) when first = Dot(dot) -> 
		      (Dot(newdot)::Seg(newseg)::oldlist,center)
			(* if this is finishing off a circle, it will have *)
			(* to be fixed later. *)
		  | (first::rest, OI) -> 
		      (append(oldlist, [Seg(newseg); Dot(newdot)]),center)
		  | (first::rest, IO) when first = Dot(newdot) -> 
		      (Dot(dot)::Seg(newseg)::oldlist,center)
		  | (first::rest, IO) -> 
		      (append(oldlist, [Seg(newseg); Dot(dot)]),center)
		  | _ -> raise BadInput
	    else pd.cmakeup(c)) 
      | Line(dline) -> pd.cmakeup 
      | _ -> raise BadInput in
  let newmember = function s -> 
    if s = newseg then container else pd.member(s) in
  let targetdot =
	match calledfrom with
		IO -> dot
		| OI -> newdot in
  let newintersect = 
    function d ->
      if d = targetdot then setadjoin(container, pd.intersect(targetdot))
      else pd.intersect(d) in
  let innards =  (pd.rcmap(region)).int_bd_list in
  let newinnards = removefromlist(innards,comp) in
  let newrstruct = {int_bd_list = newinnards;} in
  let newrcmap = 
    function r ->
      if (r = region) then newrstruct 
      else pd.rcmap(r) 
  in
    let (newmarkedby,newmarks) = 
	if circleflag then (pd.markedby,pd.marks)
	else (
let sds1 = ssegextract(newinc(dot)) in
  let sds2 = ssegextract(newinc(newdot)) in
  let pseg1 = circular_precedesinlist(newseg,sds1) in
  let pseg2 = circular_precedesinlist(newseg,sds2) in
  let newmarkedbyr = function m ->
		match m with 
			Dseg(l) -> (pd.markedby)(Dseg(l))
			|Angle(l) ->
				if segdividesangle(newseg,l,pd,dot,pseg1,newdot,pseg2) 
				then [] 
				else 
					let l2 = 
						doublereplaceinlist(l,(dot,newseg),[],(newdot,newseg),[]) in
					(pd.markedby)(Angle(sort_diang(l2)))
			| RegionSet(rs) ->
				pd.markedby(RegionSet(rs))
	in
	let newmarksr =
		let markerupdate = 
			function  m ->
				match m with 
					Dseg(l) -> Dseg(l)
					|Angle(l) ->
						let l2 = 
							doublereplaceinlist(l,(dot,pseg1),(dot,pseg1)::(dot,newseg)::[],
												(newdot,pseg2),(newdot,pseg2)::(newdot,newseg)::[]) in
						Angle(sort_diang(l2))
					|RegionSet(rs) ->
							 (RegionSet(rs))
		in
		function m ->
			let oldmarks = (pd.marks)(m) in
			let newmarks1 = List.map markerupdate oldmarks in
			newmarks1
	in
	(newmarkedbyr,newmarksr)) in
  let newpd ={rmap = newrmap;
				  rcmap = newrcmap;
				  graph = newgraphstruct;
				  lmakeup = newlmakeup;
				  cmakeup = newcmakeup;
				  lines = pd.lines;
				  circs = pd.circs;
				  member = newmember;
				  intersect = newintersect;
				  markers = pd.markers;
				  markedby = newmarkedby;
				  marks = newmarks} in
    match calledfrom with
	OI -> possible_extensions(newpd,newdot,PSeg(newseg),updategoal(goal))
      | IO -> possible_extensions(newpd,dot,PSeg(newseg),updategoal(goal))
and rec_extend_out_reg(pd,ereg,dot,container,goal,delist,dcomp) =
  match delist with
      DI(ndseg1,newdot,ndseg2)::rest ->
	if ((unsafetohitdot(pd,container,newdot,goal)))
	then rec_extend_out_reg(pd,ereg,dot,
				container,goal,rest,dcomp)
	else append(joiniodots(pd,ereg,dot,
			       DT(ndseg1,newdot,ndseg2),container,goal,dcomp),
		    rec_extend_out_reg(pd,ereg,dot,
				       container,goal,rest,dcomp))
    | SD(newdot)::rest ->
	if ((unsafetohitdot(pd,container,newdot,goal)))
	then rec_extend_out_reg(pd,ereg,dot,
				container,goal,rest,dcomp)
	else append(joiniodots(pd,ereg,dot,
			       SingDot(newdot),container,goal,dcomp),
		    rec_extend_out_reg(pd,ereg,dot,
				       container,goal,rest,dcomp))
    | SSI(seg)::rest ->
	if (unsafetohitseg(pd,container,seg,goal))
	then rec_extend_out_reg(pd,ereg,dot,
				container,goal,rest,dcomp)
	else append(joiniodotseg(pd,ereg,dot,SingSeg(seg),
				 container,goal,dcomp),
		    rec_extend_out_reg(pd,ereg,dot,
				       container,goal,rest,dcomp))
    | STI(dot1,seg,dot2)::rest ->
	if (unsafetohitseg(pd,container,seg,goal))
	then rec_extend_out_reg(pd,ereg,dot,
				container,goal,rest,dcomp)
	else append(joiniodotseg(pd,ereg,dot,ST(dot1,seg,dot2),
				 container,goal,dcomp),
		    rec_extend_out_reg(pd,ereg,dot,
				       container,goal,rest,dcomp))
    | _ -> []
and joiniodotseg(pd,ereg,dot,eseg,container,goal,dcomp) = 
  let region = extractregion(ereg) in
  let seg = extractsegment(eseg) in
  let (newdot,newseg1,segend1,segend2,newseg2, newpd) = add_dot_to_seg(pd,seg) in
    match eseg with
	SingSeg(ss) ->
	  let prec = circular_precedesinlist(Reg(region),
					     ((newpd.graph).inc)(newdot)) in
	    if prec = DSSeg(newseg2) 
	    then joiniodots(newpd,ereg,dot,DT(newseg1,newdot,newseg2),
			   container,goal,dcomp)
	    else joiniodots(newpd,ereg,dot,DT(newseg2,newdot,newseg1),
			   container,goal,dcomp)
      | ST(dot1,ss,dot2) when dot1 = dot2 -> 
	  joiniodots(newpd,ereg,dot,DT(newseg1,newdot,newseg2),
			   container,goal,dcomp)
	    (* since we're coming from the inside *)
      | ST(dot1,ss,dot2) ->
	  if segend1 = dot1 
	  then joiniodots(newpd,ereg,dot,DT(newseg1,newdot,newseg2),
			   container,goal,dcomp)
	  else  joiniodots(newpd,ereg,dot,DT(newseg2,newdot,newseg1),
			   container,goal,dcomp)
and joiniodots(pd,ereg,dot,enewdot,container,goal,comp) = 
  let (newereg,newenewdot,newfirstdot) = swapexregdot(ereg,enewdot,dot) in
    joinoidots(pd,newereg,newfirstdot,newenewdot,container,goal,comp,IO)
and rec_extend_inside_reg(pd,ereg,dot,
			  container,goal,intlist,fromcomp) =
  match intlist with
      first::rest ->  
	append(extend_idot_to_comp(pd,ereg,dot,
				   container,goal,first,fromcomp),
	       rec_extend_inside_reg(pd,ereg,dot,
				     container,goal,rest,fromcomp))
    | _ -> []
and extend_idot_to_comp(pd,ereg,dot,
			container,goal,tocomp,fromcomp) = 
    if tocomp = fromcomp 
    then rec_extend_in_comp(pd,ereg,dot,
			    container,goal,dEIify(tocomp,In,pd),tocomp)
    else  rec_extend_idot_to_comp(pd,ereg,dot,container,
				  goal,dEIify(tocomp,In,pd),tocomp,fromcomp)
and rec_extend_idot_to_comp(pd,ereg,dot,
			    container,goal,comp,tocomp,fromcomp) =
  match comp  with
      DI(ndseg1,newdot,ndseg2)::rest ->
	if (unsafetohitdot(pd,container,newdot,goal))
	then rec_extend_idot_to_comp(pd,ereg,dot,container,
				     goal,rest,tocomp,fromcomp)
	else append(joiniidots(pd,ereg,dot,
			       DT(ndseg1,newdot,ndseg2),
			       container,goal,tocomp,fromcomp),
		    rec_extend_idot_to_comp(pd,ereg,dot,
					    container,goal,rest,tocomp,fromcomp))
    | SD(newdot)::rest ->
	if (unsafetohitdot(pd,container,newdot,goal))
	then rec_extend_idot_to_comp(pd,ereg,dot,container,
				     goal,rest,tocomp,fromcomp)
	else append(joiniidots(pd,ereg,dot,
			       SingDot(newdot),
			       container,goal,tocomp,fromcomp),
		    rec_extend_idot_to_comp(pd,ereg,dot,
					    container,goal,rest,tocomp,fromcomp))
    | SSI(seg)::rest ->
	if (unsafetohitseg(pd,container,seg,goal))
	then rec_extend_idot_to_comp(pd,ereg,dot,container,
				     goal,rest,tocomp,fromcomp)
	else append(joiniidotseg(pd,ereg,dot,SingSeg(seg),container,
				 goal,tocomp,fromcomp),
		    rec_extend_idot_to_comp(pd,ereg,dot,
					    container,goal,rest,tocomp,fromcomp))
    | STI(dot1,seg,dot2)::rest ->
	if (unsafetohitseg(pd,container,seg,goal))
	then rec_extend_idot_to_comp(pd,ereg,dot,container,
				     goal,rest,tocomp,fromcomp)
	else append(joiniidotseg(pd,ereg,dot,ST(dot1,seg,dot2),container,
				 goal,tocomp,fromcomp),
		    rec_extend_idot_to_comp(pd,ereg,dot,
					    container,goal,rest,tocomp,fromcomp))
    | _ -> []
and joiniidotseg(pd,ereg,dot,eseg,container,goal,tocomp,fromcomp) = 
  let region = extractregion(ereg) in
  let seg = extractsegment(eseg) in
  let (newdot,newseg1,segend1,segend2,newseg2, newpd) = add_dot_to_seg(pd,seg) in
    match eseg with
	SingSeg(ss) ->
	  let prec = circular_precedesinlist(Reg(region),
					     ((newpd.graph).inc)(newdot)) in
	    if prec = DSSeg(newseg2) 
	    then joiniidots(newpd,ereg,dot,DT(newseg1,newdot,newseg2),
			   container,goal,dotcomp(newdot,newpd,region),fromcomp)
	    else joiniidots(newpd,ereg,dot,DT(newseg2,newdot,newseg1),
			   container,goal,dotcomp(newdot,newpd,region),fromcomp)
      | ST(dot1,ss,dot2) when dot1 = dot2 ->
	  joiniidots(newpd,ereg,dot,DT(newseg2,newdot,newseg1),
		     container,goal,dotcomp(newdot,newpd,region),fromcomp)
	    (* since we're coming from the outside *)
      | ST(dot1,ss,dot2) ->
	  if segend1 = dot1 
	  then joiniidots(newpd,ereg,dot,DT(newseg1,newdot,newseg2),
			   container,goal,dotcomp(newdot,newpd,region),fromcomp)
	  else joiniidots(newpd,ereg,dot,DT(newseg2,newdot,newseg1),
			   container,goal,dotcomp(newdot,newpd,region),fromcomp)
and joiniidots(pd,ereg,dot,enewdot,
	       container,goal,tocomp,fromcomp) =
  let newdot = extractdot(enewdot) in
  let region = extractregion(ereg) in
  let dbfromlist = triple(fromcomp) in
  let fromlist = rotateto(dbfromlist,
			  exreg2exdot(eflip(ereg),dot)) in
  let dbtolist = triple(tocomp) in
  let tolist = rotateto(dbtolist,
			enewdot) in
  let circleflag = 
	 match container with
	Line(dline) -> false
      | Circ(circ) ->  true 
      | _ -> raise BadInput in
  let newseg = if circleflag then newdottedseg() else newsseg() in
  let pnewseg = Plain(newseg) in
  let newcomp = append(tolist,append(Seg(newseg)::fromlist, [Seg(newseg)])) in
  let newsegset = setadjoin(newseg,pd.graph.segs) in
  let newedgemap = function seg -> 
    if seg = newseg then DotPair(dot,newdot) else pd.graph.emap(seg) in
  let oldinc = pd.graph.inc in
  let olddslist1 = oldinc(dot) in
  let olddslist2 = oldinc(newdot) in
  let newdslist1 = 
    rep_reg(ereg,
	    [Reg(region);DSSeg(pnewseg);Reg(region)],
	    olddslist1) in
  let newdslist2 = 
    rep_reg(eflip(exdot2exreg(enewdot,region)),
	    [Reg(region);DSSeg(pnewseg);Reg(region)],
	    olddslist2) in
  let newinc = function d ->
    if (d = dot) then newdslist1
    else if (d = newdot) then newdslist2 
    else oldinc(d) in
  let newgraphstruct = {dots = pd.graph.dots;
			segs = newsegset;
			inc = newinc;
			emap = newedgemap;
			regs = pd.graph.regs} in
  let oldcomplist = (pd.rcmap(region)).int_bd_list in
  let newinnards = newcomp :: removefromlist(removefromlist(oldcomplist,
							     tocomp),
					      fromcomp) in
  let newlmakeup = 
    match container with 
	Line(dline) -> 
	  (function l -> 
	    if l = dline 
	    then 
	      let oldlist = pd.lmakeup(dline) in
		match oldlist with
		    first::rest when first = Dot(dot) -> 
		      Dot(newdot)::Seg(newseg)::oldlist
		  | first::rest -> append(oldlist, [Seg(newseg); Dot(newdot)])
		  | _ -> raise BadInput
	    else pd.lmakeup(l)) 
      | Circ(circ) -> pd.lmakeup 
      | _ -> raise BadInput in
  let newcmakeup = 
    match container with 
	Circ(circ) -> 
	  (function c -> 
	    if c = circ 
	    then 
	      let (oldlist,center) = pd.cmakeup(circ) in
		match oldlist with
		    first::rest when first = Dot(dot) -> 
		      (Dot(newdot)::Seg(newseg)::oldlist,center)
			(* if this is finishing off a circle, it will have *)
			(* to be fixed later. *)
		  | first::rest -> 
		      (append(oldlist, [Seg(newseg); Dot(newdot)]),center)
		  | _ -> raise BadInput
	    else pd.cmakeup(c)) 
      | Line(dline) -> pd.cmakeup 
      | _ -> raise BadInput in
  let newmember = function s -> 
    if s = newseg then container else pd.member(s) in
  let newintersect = 
    function d ->
      if d = newdot then setadjoin(container, pd.intersect(newdot))
      else pd.intersect(d) in
  let newrstruct = {int_bd_list = newinnards;} in
  let newrcmap = 
    function r ->
      if (r = region) then newrstruct 
      else pd.rcmap(r) 
  in
    let (newmarkedby,newmarks) = 
	if circleflag then (pd.markedby,pd.marks)
	else (
  let sds1 = ssegextract(newinc(dot)) in
  let sds2 = ssegextract(newinc(newdot)) in
  let pseg1 = circular_precedesinlist(newseg,sds1) in
  let pseg2 = circular_precedesinlist(newseg,sds2) in
  let newmarkedbyr = function m ->
		match m with 
			Dseg(l) -> (pd.markedby)(Dseg(l))
			|Angle(l) ->
				if segdividesangle(newseg,l,pd,dot,pseg1,newdot,pseg2) 
				then [] 
				else 
					let l2 = 
						doublereplaceinlist(l,(dot,newseg),[],(newdot,newseg),[]) in
					(pd.markedby)(Angle(sort_diang(l2)))
			| RegionSet(rs) ->
				pd.markedby(RegionSet(rs))
	in
	let newmarksr =
		let markerupdate = 
			function  m ->
				match m with 
					Dseg(l) -> Dseg(l)
					|Angle(l) ->
						let l2 = 
							doublereplaceinlist(l,(dot,pseg1),(dot,pseg1)::(dot,newseg)::[],
												(newdot,pseg2),(newdot,pseg2)::(newdot,newseg)::[]) in
						Angle(sort_diang(l2))
					|RegionSet(rs) ->
							(RegionSet(rs))
		in
		function m ->
			let oldmarks = (pd.marks)(m) in
			let newmarks1 = List.map markerupdate oldmarks in
			newmarks1
	in
	(newmarkedbyr,newmarksr)) in
  let newpd ={rmap = pd.rmap;
				  rcmap = newrcmap;
				  graph = newgraphstruct;
				  lmakeup = newlmakeup;
				  cmakeup = newcmakeup;
				  lines = pd.lines;
				  circs = pd.circs;
				  member = newmember;
				  intersect = newintersect;
				  markers = pd.markers;
				  markedby = newmarkedby;
				  marks = newmarks} in
    possible_extensions(newpd,newdot,PSeg(newseg),updategoal(goal))
and rec_extend_in_comp(pd,ereg,dot,container,goal,comp,origcomp) =
  match comp  with
      DI(ndseg1,newdot,ndseg2)::rest ->
	if (unsafetohitdot(pd,container,newdot,goal))
	then rec_extend_in_comp(pd,ereg,dot,container,
				     goal,rest,origcomp)
	else append(joincompdots(pd,ereg,dot,
				 DT(ndseg1,newdot,ndseg2),container,goal,origcomp),
		    rec_extend_in_comp(pd,ereg,dot,
					    container,goal,rest,origcomp))
    | SSI(seg)::rest ->
	if (unsafetohitseg(pd,container,seg,goal))
	then rec_extend_in_comp(pd,ereg,dot,container,
				     goal,rest,origcomp)
	else append(joincompdotseg(pd,ereg,dot,SingSeg(seg),container,goal),
		    rec_extend_in_comp(pd,ereg,dot,
					    container,goal,rest,origcomp))
    | STI(dot1,seg,dot2)::rest ->
	if (unsafetohitseg(pd,container,seg,goal))
	then rec_extend_in_comp(pd,ereg,dot,container,
				     goal,rest,origcomp)
	else append(joincompdotseg(pd,ereg,dot,ST(dot1,seg,dot2),container,goal),
		    rec_extend_in_comp(pd,ereg,dot,
					    container,goal,rest,origcomp))
    | [SD(newdot)] -> (* MIght Need to fix this!!!!!!!!!!!!!!!!!! *)
	if (unsafetohitdot(pd,container,newdot,goal))
	then []
	else joincompdots(pd,ereg,dot,
			  SingDot(newdot),container,goal,origcomp)

    | _ -> []
and joincompdotseg(pd,ereg,dot,eseg,container,goal) = 
  let region = extractregion(ereg) in
 (*   printpd(pd); for debugging ................*) 
  let seg = extractsegment(eseg) in
  let (newdot,newseg1,segend1,segend2,newseg2, newpd) = 
    add_dot_to_seg(pd,seg) in
  let newereg = 
    if dot = segend1 & dot = segend2 
    then replaceinRT(replaceinRT(ereg,Plain(seg),newseg1),
		     Returning(seg),newseg2)
    else if dot = segend1 
    then replaceinRT(ereg,Plain(seg),newseg1)
    else if dot = segend2
    then replaceinRT(ereg,Plain(seg),newseg2)
    else ereg 
  in
    match eseg with
	ST(dot1,ss,dot2) when dot1 = dot2 ->
	  joincompdots(newpd,newereg,dot,DT(newseg2,newdot,newseg1),
		       container,goal,dotcomp(newdot,newpd,region))
	    (* since we're coming from the outside *)
      | ST(dot1,ss,dot2) ->
	  if segend1 = dot1 
	  then joincompdots(newpd,newereg,dot,DT(newseg1,newdot,newseg2),
			   container,goal,dotcomp(newdot,newpd,region))
	  else joincompdots(newpd,newereg,dot,DT(newseg2,newdot,newseg1),
			   container,goal,dotcomp(newdot,newpd,region))
      | _ -> raise BadInput
and joincompdots(pd,ereg,dot,enewdot,
		 container,goal,comp) =
  let newdot = extractdot(enewdot) in
  let region = extractregion(ereg) in
  let dbcomplist = triple(comp) in
   (*  printpd(pd);  for debugging.......... *)
  let eolddot = exreg2exdot(eflip(ereg),dot) in
  let (firsthalf,secondhalf) = 
    if eolddot = enewdot then ([Dot(dot)],rotateto(dbcomplist,enewdot))
    else 
      tsplit(dbcomplist,
	     eolddot,
	     enewdot) in
  let circleflag = 
	 match container with
	Line(dline) -> false
      | Circ(circ) ->  true 
      | _ -> raise BadInput in
  let newseg = if circleflag then newdottedseg() else newsseg() in
  let pnewseg = Plain(newseg) in
  let newregiono = newregion() in
  let newregioni = newregion() in
  let newcomp1 = Seg(newseg)::firsthalf in
  let newcomp2 = Seg(newseg)::secondhalf in
  let newrbound1 = newcomp2 in
  let newrbound2 = newcomp1 in 
  let newsegset = setadjoin(newseg,pd.graph.segs) in
  let newedgemapbasic = function seg -> 
    if seg = newseg then DotPair(dot,newdot) else pd.graph.emap(seg) in
  let newedgemap =
    match pd.rmap(region) with
	Seg(outerseg)::[] ->
	  (match pd.graph.emap(outerseg) with
	      Loop(oldinnerreg,oldouterreg) ->
		(function seg -> 
		  if seg = outerseg then Loop(newregiono,oldouterreg)
		  else newedgemapbasic(seg))
	     | _ -> raise BadInput)
      | _ -> newedgemapbasic in
  let oldinc = pd.graph.inc in
  let olddslistd = oldinc(dot) in
  let olddslistn = oldinc(newdot) in
	(* Begin new version, 4/30/2010 *)
	(* The d version is for the old dot and the n version is for the new dot.
	   The 1 / 2 versions are for the two ways we can connect the dots around the 
	   outside of the components.*)
	let (moddslist1d,moddslist1n,moddslist2d,moddslist2n) =
		if (eolddot = enewdot) then
			match ereg with
				SingReg(reg) ->
					let equaldslist1 = 
						[Reg(newregiono);DSSeg(pnewseg);
						 Reg(newregioni);DSSeg(Returning(newseg))] in 
				(*	let equaldslist2 =
						[Reg(newregiono);DSSeg(Returning(newseg));
						 Reg(newregioni);DSSeg(pnewseg)] in *)
					(equaldslist1,equaldslist1,equaldslist1,equaldslist1)
				| _ ->
					let equaldslist1 =
						simple_rotate_to(
						rep_reg(ereg,
							[Reg(newregioni);DSSeg(Returning(newseg));
							Reg(newregiono);DSSeg(pnewseg);
							Reg(newregioni)],
							olddslistd), DSSeg(pnewseg)) in
					let equaldslist2 = 
						simple_rotate_to(
						rep_reg(ereg,
							[Reg(newregiono);DSSeg(pnewseg);Reg(newregioni);
							DSSeg(Returning(newseg));
							Reg(newregiono)],
							olddslistd), DSSeg(pnewseg)) in
					(equaldslist1,equaldslist1,equaldslist2,equaldslist2)
		else if (dot = newdot) then
			let jdequallist1 = 
				simple_rotate_to(
				rep_reg(eflip(exdot2exreg(enewdot,region)),
						[Reg(newregioni);DSSeg(Returning(newseg));Reg(newregiono)],
						rep_reg(ereg,
							[Reg(newregiono);DSSeg(pnewseg);Reg(newregioni)],
							olddslistd)), DSSeg(pnewseg)) in
			let jdequallist2 = 
				simple_rotate_to(
				rep_reg(eflip(exdot2exreg(enewdot,region)),
						[Reg(newregiono);DSSeg(pnewseg);Reg(newregioni)],
						rep_reg(ereg,
							[Reg(newregioni);DSSeg(Returning(newseg));Reg(newregiono)],
							olddslistd)), DSSeg(pnewseg)) in
			(jdequallist1,jdequallist1,jdequallist2,jdequallist2)
		else
			let newdslist1d = 
				rep_reg(ereg,
					[Reg(newregiono);DSSeg(pnewseg);Reg(newregioni)],
					olddslistd) in
			let newdslist2d = 
				rep_reg(ereg,
					[Reg(newregioni);DSSeg(pnewseg);Reg(newregiono)],
					olddslistd) in
			let newdslist1n = 
				rep_reg(eflip(exdot2exreg(enewdot,region)),
					[Reg(newregioni);DSSeg(pnewseg);Reg(newregiono)],
					olddslistn) in
			let newdslist2n = 
				rep_reg(eflip(exdot2exreg(enewdot,region)),
					[Reg(newregiono);DSSeg(pnewseg);Reg(newregioni)],
					olddslistn) in
			(newdslist1d,newdslist1n,newdslist2d,newdslist2n) 
	in 
	(* end new code from 4/30/2010 *)
  (*let fixednewdslist1n =
      fix_regions(region,newregioni,newregiono,
		  secondhalf,newdslist1n,newdot,Reverse)  in *)
    (* for debugging ...... *)
  let newinc1 = function d ->
    if (d = dot) then
      fix_regions(region,newregioni,newregiono,
		  secondhalf,moddslist1d,d,Reverse) 
    else if (d = newdot) then 
      fix_regions(region,newregioni,newregiono,
		  secondhalf,moddslist1n,d,Reverse) 
    else 
      fix_regions(region,newregioni,newregiono,
		  secondhalf,pd.graph.inc(d),d,Reverse) in 
  let newinc2 = function d ->
    if (d = dot) then 
      fix_regions(region,newregioni,newregiono,
		  firsthalf,moddslist2d,d,Reverse) 
    else if (d = newdot) then 
      fix_regions(region,newregioni,newregiono,
		  firsthalf,moddslist2n,d,Reverse) 
    else 
      fix_regions(region,newregioni,newregiono,
		  firsthalf,pd.graph.inc(d),d,Reverse) in
  let newregs = setadjoin(newregioni,
			  setadjoin(newregiono, 
				    setremove(region,pd.graph.regs))) in
  let newgraphstruct1 = {dots = pd.graph.dots;
			 segs = newsegset;
			 inc = newinc1;
			 emap = newedgemap;
			 regs = newregs} in
  let newgraphstruct2 = {dots = pd.graph.dots;
			 segs = newsegset;
			 inc = newinc2;
			 emap = newedgemap;
			 regs = newregs} in
  let newrmap1 = function r ->
    if r = newregioni then newrbound1
    else if r = newregiono then pd.rmap(region)
    else pd.rmap(r) in
  let newrmap2 = function r ->
    if r = newregioni then newrbound2
    else if r = newregiono then pd.rmap(region)
    else pd.rmap(r) in
  let newlmakeup = 
    match container with 
	Line(dline) -> 
	  (function l -> 
	    if l = dline 
	    then 
	      let oldlist = pd.lmakeup(dline) in
		match oldlist with
		    first::rest when first = Dot(dot) -> 
		      Dot(newdot)::Seg(newseg)::oldlist
		  | first::rest -> append(oldlist, [Seg(newseg); Dot(newdot)])
		  | _ -> raise BadInput
	    else pd.lmakeup(l)) 
      | Circ(circ) -> pd.lmakeup
      | _ -> raise BadInput in
  let newcmakeup = 
    match container with 
	Circ(circ) -> 
	  (function c -> 
	    if c = circ 
	    then 
	      let (oldlist,center) = pd.cmakeup(circ) in
		match oldlist with
		    first::rest when first = Dot(dot) -> 
		      (Dot(newdot)::Seg(newseg)::oldlist,center)
			(* if this is finishing off a circle, it will have *)
			(* to be fixed later. *)
		  | first::rest -> 
		      (append(oldlist, [Seg(newseg); Dot(newdot)]),center)
		  | _ -> raise BadInput
	    else pd.cmakeup(c)) 
      | Line(dline) -> pd.cmakeup 
      | _ -> raise BadInput in
(*  let test =
    match container with
	Circ(circ) -> firstcomp(newcmakeup(circ))
      | _ -> [] in *)
    (*for debugging .......... *)
  let newmember = function s -> 
    if s = newseg then container else pd.member(s) in
  let newintersect = 
    function d ->
      if d = newdot then setadjoin(container, pd.intersect(newdot))
      else pd.intersect(d) in
  let innards =  removefromlist((pd.rcmap(region)).int_bd_list,comp) in
  let newregionostruct1 =  {int_bd_list = [newcomp1];} in
  let newregionostruct2 = {int_bd_list = [newcomp2];} in
  let newrcmap1 = 
    function r ->
      if (r = newregioni) then empty_region_info_struct 
      else if (r = newregiono) then newregionostruct1 
      else pd.rcmap(r) in
  let newrcmap2 = 
    function r ->
      if (r = newregioni) then empty_region_info_struct 
      else if (r = newregiono) then newregionostruct2
      else pd.rcmap(r) 
  in
  
  let (newmarkedby1,newmarks1) = 
	if circleflag then (pd.markedby,pd.marks)
	else (
		let sds11 = ssegextract(newinc1(dot)) in
		let sds21 = ssegextract(newinc1(newdot)) in
		let pseg11 = circular_precedesinlist(newseg,sds11) in
		let pseg21 = circular_precedesinlist(newseg,sds21) in
		let newmarkedby1r = function m ->
			match m with 
				Dseg(l) -> (pd.markedby)(Dseg(l))
				|Angle(l) ->
					if segdividesangle(newseg,l,pd,dot,pseg11,newdot,pseg21) 
					then [] 
					else 
						let l2 = 
							doublereplaceinlist(l,(dot,newseg),[],(newdot,newseg),[]) in
						(pd.markedby)(Angle(sort_diang(l2)))
				| RegionSet(rs) ->
					if inset(newregioni,rs) & inset(newregiono,rs)
					then
						let newrs = 
								setadjoin(region, setremove(newregioni,setremove(newregiono,rs))) in
						let newrs2 = List.fast_sort reg_compare newrs in
						pd.markedby(RegionSet(newrs2))
					else pd.markedby(RegionSet(rs))
		in
		let newmarks1r =
			let markerupdate = 
				function  m ->
					match m with 
						Dseg(l) -> Dseg(l)
						|Angle(l) ->
							let l2 = 
								doublereplaceinlist(l,(dot,pseg11),(dot,pseg11)::(dot,newseg)::[],
													(newdot,pseg21),(newdot,pseg21)::(newdot,newseg)::[]) in
							Angle(sort_diang(l2))
					|RegionSet(rs) ->
							if inset(region,rs) 
							then 
								let newrl = setadjoin(newregiono,
													setadjoin(newregioni,setremove(region,rs))) in
								let newrl2 = List.fast_sort reg_compare newrl in
								(RegionSet(newrl2))
							else (RegionSet(rs))
			in
			function m ->
				let oldmarks = (pd.marks)(m) in
				let newmarks11 = List.map markerupdate oldmarks in
				newmarks11
		in 
		(newmarkedby1r,newmarks1r)) in
    let (newmarkedby2,newmarks2) = 
	if circleflag then (pd.markedby,pd.marks)
	else (
  let sds12 = ssegextract(newinc2(dot)) in
  let sds22 = ssegextract(newinc2(newdot)) in
  let pseg12 = circular_precedesinlist(newseg,sds12) in
  let pseg22 = circular_precedesinlist(newseg,sds22) in
  let newmarkedby2r = function m ->
		match m with 
			Dseg(l) -> (pd.markedby)(Dseg(l))
			|Angle(l) ->
				if segdividesangle(newseg,l,pd,dot,pseg12,newdot,pseg22) 
				then [] 
				else 
					let l2 = 
						doublereplaceinlist(l,(dot,newseg),[],(newdot,newseg),[]) in
					(pd.markedby)(Angle(sort_diang(l2)))
			| RegionSet(rs) ->
				if inset(newregioni,rs) & inset(newregiono,rs)
				then
					let newrs = 
							setadjoin(region, setremove(newregioni,setremove(newregiono,rs))) in
					let newrs2 = List.fast_sort reg_compare newrs in
					pd.markedby(RegionSet(newrs2))
				else pd.markedby(RegionSet(rs))
	in
	let newmarks2r =
		let markerupdate = 
			function  m ->
				match m with 
					Dseg(l) -> Dseg(l)
					|Angle(l) ->
						let l2 = 
							doublereplaceinlist(l,(dot,pseg12),(dot,pseg12)::(dot,newseg)::[],
												(newdot,pseg22),(newdot,pseg22)::(newdot,newseg)::[]) in
						Angle(sort_diang(l2))
					|RegionSet(rs) ->
							if inset(region,rs) 
							then 
								let newrl = setadjoin(newregioni,
													setadjoin(newregiono,setremove(region,rs))) in
								let newrl2 = List.fast_sort reg_compare newrl in
								(RegionSet(newrl2))
							else (RegionSet(rs))
		in
		function m ->
			let oldmarks = (pd.marks)(m) in
			let newmarks12 = List.map markerupdate oldmarks in
			newmarks12
	in 
	(newmarkedby2r,newmarks2r)) in
  let list =
	if (eolddot = enewdot) then
			match ereg with
				SingReg(reg) ->
			distribute_innards([{rmap = newrmap1;
				rcmap = newrcmap1;
				graph = newgraphstruct1;
				lmakeup = newlmakeup;
				cmakeup = newcmakeup;
				lines = pd.lines;
				circs = pd.circs;
				member = newmember;
				intersect = newintersect;
				markers = pd.markers;
				markedby = newmarkedby1;
				marks = newmarks1}], 
			      newregioni,
			      newregiono,
			      innards,
				  region)
				|_->
			append(distribute_innards([{rmap = newrmap1;
				rcmap = newrcmap1;
				graph = newgraphstruct1;
				lmakeup = newlmakeup;
				cmakeup = newcmakeup;
				lines = pd.lines;
				circs = pd.circs;
				member = newmember;
				intersect = newintersect;
				markers = pd.markers;
				markedby = newmarkedby1;
				marks = newmarks1}], 
			      newregioni,
			      newregiono,
			      innards,
				  region),
	   distribute_innards([{rmap = newrmap2;
				rcmap = newrcmap2;
				graph = newgraphstruct2;
				lmakeup = newlmakeup;
				cmakeup = newcmakeup;
				lines = pd.lines;
				circs = pd.circs;
				member = newmember;
				intersect = newintersect;
				markers = pd.markers;
				markedby = newmarkedby2;
				marks = newmarks2}], 
			      newregioni,
			      newregiono,
			      innards,
				  region))
			else
			if (dot = newdot)
			(* in this case, we only return the version in which the new segment
			leaves from ereg, since the case where it returns will be generated when
			we consider leaving from the other eregion.*)
			then
			distribute_innards([{rmap = newrmap1;
				rcmap = newrcmap1;
				graph = newgraphstruct1;
				lmakeup = newlmakeup;
				cmakeup = newcmakeup;
				lines = pd.lines;
				circs = pd.circs;
				member = newmember;
				intersect = newintersect;
				markers = pd.markers;
				markedby = newmarkedby1;
				marks = newmarks1}], 
			      newregioni,
			      newregiono,
			      innards,
				  region)
			else
    append(distribute_innards([{rmap = newrmap1;
				rcmap = newrcmap1;
				graph = newgraphstruct1;
				lmakeup = newlmakeup;
				cmakeup = newcmakeup;
				lines = pd.lines;
				circs = pd.circs;
				member = newmember;
				intersect = newintersect;
				markers = pd.markers;
				markedby = newmarkedby1;
				marks = newmarks1}], 
			      newregioni,
			      newregiono,
			      innards,
				  region),
	   distribute_innards([{rmap = newrmap2;
				rcmap = newrcmap2;
				graph = newgraphstruct2;
				lmakeup = newlmakeup;
				cmakeup = newcmakeup;
				lines = pd.lines;
				circs = pd.circs;
				member = newmember;
				intersect = newintersect;
				markers = pd.markers;
				markedby = newmarkedby2;
				marks = newmarks2}], 
			      newregioni,
			      newregiono,
			      innards,
				  region)) in
  let f = function diagram -> 
    possible_extensions(diagram,newdot,PSeg(newseg),updategoal(goal)) 
  in
    List.concat(List.map f list);;


let joinoidots_return_pdseg(pd,ereg,dot,enewdot,
	       container,goal,comp,calledfrom) =
  let newdot = extractdot(enewdot) in
  let region = extractregion(ereg) in
  let oldedgelist = pd.rmap(region) in
  let dboldlist = append(append(oldedgelist,oldedgelist),oldedgelist) in
  let outlist = rotateto(dboldlist,
			 exreg2exdot(eflip(ereg),dot)) in
  let dbcomplist = append(comp,append(comp,comp)) in
  let inlist = rotateto(dbcomplist,
			enewdot) in
  let circleflag = 
	 match container with
	Line(dline) -> false
      | Circ(circ) ->  true 
      | _ -> raise BadInput in
  let newseg = if circleflag then newdottedseg() else newsseg() in
  let pnewseg = Plain(newseg) in
  let newedgelist = append(outlist,append(Seg(newseg)::inlist,[Seg(newseg)])) in
  let newsegset = setadjoin(newseg,pd.graph.segs) in
  let newedgemap = function seg -> 
    if seg = newseg then DotPair(dot,newdot) else pd.graph.emap(seg) in
  let oldinc = pd.graph.inc in
  let olddslist1 = oldinc(dot) in
  let olddslist2 = oldinc(newdot) in
  let newdslist1 = 
    rep_reg(ereg,
	    [Reg(region);DSSeg(pnewseg);Reg(region)],
	    olddslist1) in
  let newdslist2 = 
    rep_reg(eflip(exdot2exreg(enewdot,region)),
	    [Reg(region);DSSeg(pnewseg);Reg(region)],
	    olddslist2) in
  let newinc = function d ->
    if (d = dot) then newdslist1
    else if (d = newdot) then newdslist2 
    else oldinc(d) in
  let newgraphstruct = {dots = pd.graph.dots;
			segs = newsegset;
			inc = newinc;
			emap = newedgemap;
			regs = pd.graph.regs} in
  let newrmap = function r ->
    if r = region then newedgelist
    else pd.rmap(r) in
  let newlmakeup = 
    match container with 
	Line(dline) -> 
	  (function l -> 
	    if l = dline 
	    then 
	      let oldlist = pd.lmakeup(dline) in
		match oldlist with
		    first::rest when first = Dot(dot) -> 
		      Dot(newdot)::Seg(newseg)::oldlist
		  | first::rest -> append(oldlist, [Seg(newseg); Dot(newdot)])
		  | _ -> raise BadInput
	    else pd.lmakeup(l)) 
      | Circ(circ) -> pd.lmakeup 
      | _ -> raise BadInput in
  let newcmakeup = 
    match container with 
	Circ(circ) -> 
	  (function c -> 
	    if c = circ 
	    then 
	      let (oldlist,center) = pd.cmakeup(circ) in
		match oldlist with
		    first::rest when first = Dot(dot) -> 
		      (Dot(newdot)::Seg(newseg)::oldlist,center)
			(* if this is finishing off a circle, it will have *)
			(* to be fixed later. *)
		  | first::rest -> 
		      (append(oldlist, [Seg(newseg); Dot(newdot)]),center)
		  | _ -> raise BadInput
	    else pd.cmakeup(c)) 
      | Line(dline) -> pd.cmakeup 
      | _ -> raise BadInput in
  let newmember = function s -> 
    if s = newseg then container else pd.member(s) in
  let newintersect = 
    function d ->
      if d = newdot then setadjoin(container, pd.intersect(newdot))
      else pd.intersect(d) in
  let innards =  (pd.rcmap(region)).int_bd_list in
  let newinnards = removefromlist(innards,comp) in
  let newrstruct = {int_bd_list = newinnards;} in
  let newrcmap = 
    function r ->
      if (r = region) then newrstruct 
      else pd.rcmap(r) 
  in
    let (newmarkedby,newmarks) = 
	if circleflag then (pd.markedby,pd.marks)
	else (
  let sds1 = ssegextract(newinc(dot)) in
  let sds2 = ssegextract(newinc(newdot)) in
  let pseg1 = circular_precedesinlist(newseg,sds1) in
  let pseg2 = circular_precedesinlist(newseg,sds2) in
  let newmarkedbyr = function m ->
		match m with 
			Dseg(l) -> (pd.markedby)(Dseg(l))
			|Angle(l) ->
				if segdividesangle(newseg,l,pd,dot,pseg1,newdot,pseg2) 
				then [] 
				else 
					let l2 = 
						doublereplaceinlist(l,(dot,newseg),[],(newdot,newseg),[]) in
					(pd.markedby)(Angle(sort_diang(l2)))
			| RegionSet(rs) ->
				pd.markedby(RegionSet(rs))
	in
	let newmarksr =
		let markerupdate = 
			function  m ->
				match m with 
					Dseg(l) -> Dseg(l)
					|Angle(l) ->
						let l2 = 
							doublereplaceinlist(l,(dot,pseg1),(dot,pseg1)::(dot,newseg)::[],
												(newdot,pseg2),(newdot,pseg2)::(newdot,newseg)::[]) in
						Angle(sort_diang(l2))
					|RegionSet(rs) ->
							(RegionSet(rs))
		in
		function m ->
			let oldmarks = (pd.marks)(m) in
			let newmarks1 = List.map markerupdate oldmarks in
			newmarks1
	in
	(newmarkedbyr,newmarksr)) in 
  let newpd ={rmap = newrmap;
				  rcmap = newrcmap;
				  graph = newgraphstruct;
				  lmakeup = newlmakeup;
				  cmakeup = newcmakeup;
				  lines = pd.lines;
				  circs = pd.circs;
				  member = newmember;
				  intersect = newintersect;
				  markers = pd.markers;
				  markedby = newmarkedby;
				  marks = newmarks} in
    (newpd,newseg)

and joinodots_return_seg_reg(pd,ereg,dot,enewdot,container) =
  let region = extractregion(ereg) in
  let newdot = extractdot(enewdot) in
(*     printpd(pd);     for debugging ................... *)
  let newregion1 = newregion() in
  let newregion2 = newregion() in
  let oldedgelist = pd.rmap(region) in
  let dboldlist = append(oldedgelist,append(oldedgelist,oldedgelist)) in
  let eolddot = exreg2exdot(eflip(ereg),dot) in
  let (firsthalf,secondhalf) = 
    if eolddot = enewdot then ([Dot(dot)],rotateto(dboldlist,enewdot))
    else 
      tsplit(dboldlist,
	     eolddot,
	     enewdot) in
  let circleflag = 
	 match container with
	Line(dline) -> false
      | Circ(circ) ->  true 
      | _ -> raise BadInput in
  let newseg = if circleflag then newdottedseg() else newsseg() in
  let pnewseg = Plain(newseg) in
  let newedgelist1 = Seg(newseg)::firsthalf in
  let newedgelist2 = Seg(newseg)::secondhalf in
  let newsegset = setadjoin(newseg,pd.graph.segs) in
  let newedgemap = function seg -> 
    if seg = newseg then DotPair(dot,newdot) else pd.graph.emap(seg) in
  let oldinc = pd.graph.inc in
  let olddslist1 = oldinc(dot) in
  let olddslist2 = oldinc(newdot) in
  let newdslist1 = 
    rep_reg(ereg,
	    [Reg(newregion1);DSSeg(pnewseg);Reg(newregion2)],
	    olddslist1) in
  let newdslist2 = 
    rep_reg(eflip(exdot2exreg(enewdot,region)),
	    [Reg(newregion2);DSSeg(pnewseg);Reg(newregion1)],
	    olddslist2) in
  let eqdslist = 
    rep_reg(ereg,
	    [Reg(newregion2);DSSeg(Plain(newseg));Reg(newregion1);
	     DSSeg(Returning(newseg));
	     Reg(newregion2)],
	    olddslist1) in
  let (moddslist1,moddslist2) = 
    if eolddot = enewdot
    then (eqdslist,eqdslist)
    else (newdslist1,newdslist2) in
(* let fixeddslist1 =      fix_regions(region,newregion1,newregion2,
		  firsthalf,newdslist1,dot,Reverse) in 
  let fixeddslist2 =      fix_regions(region,newregion1,newregion2,
		  firsthalf,newdslist2,newdot,Reverse) in *)
(* for debugging ............... *) 
  let newinc = function d ->
    if (d = dot) then 
      fix_regions(region,newregion1,newregion2,
		  firsthalf,moddslist1,d,Reverse) 
    else if (d = newdot) then  
      fix_regions(region,newregion1,newregion2,
		  firsthalf,moddslist2,d,Reverse) 
    else 
      fix_regions(region,newregion1,newregion2,
		  firsthalf,pd.graph.inc(d),d,Reverse) in
  let newregs = setadjoin(newregion1,
			  setadjoin(newregion2, 
				    setremove(region,pd.graph.regs))) in
  let newgraphstruct = {dots = pd.graph.dots;
			segs = newsegset;
			inc = newinc;
			emap = newedgemap;
			regs = newregs} in
  let newrmap = function r ->
    if r = newregion1 then newedgelist1
    else if r = newregion2 then newedgelist2
    else pd.rmap(r) in
  let newlmakeup = 
    match container with 
	Line(dline) -> 
	  (function l -> 
	    if l = dline 
	    then 
	      let oldlist = pd.lmakeup(dline) in
		match oldlist with
		    first::rest when first = Dot(dot) -> 
		      Dot(newdot)::Seg(newseg)::oldlist
		  | first::rest -> append(oldlist, [Seg(newseg); Dot(newdot)])
		  | _ -> raise BadInput
	    else pd.lmakeup(l)) 
      | Circ(circ) -> pd.lmakeup 
      | _ -> raise BadInput in
  let newcmakeup = 
    match container with 
	Circ(circ) -> 
	  (function c -> 
	    if c = circ 
	    then 
	      let (oldlist,center) = pd.cmakeup(circ) in
		match oldlist with
		    first::rest when first = Dot(dot) -> 
		      (Dot(newdot)::Seg(newseg)::oldlist,center)
			(* if this is finishing off a circle, it will have *)
			(* to be fixed later. *)
		  | first::rest -> 
		      (append(oldlist, [Seg(newseg); Dot(newdot)]),center)
		  | _ -> raise BadInput
	    else pd.cmakeup(c)) 
      | Line(dline) -> pd.cmakeup 
      | _ -> raise BadInput in
  let newmember = function s -> 
    if s = newseg then container else pd.member(s) in
  let newintersect = 
    function d ->
      if d = newdot then setadjoin(container, pd.intersect(newdot))
      else pd.intersect(d) in
  let newregion1struct =  empty_region_info_struct in
  let newregion2struct = empty_region_info_struct in
  let newrcmap = 
    function r ->
      if (r = newregion1) then newregion1struct 
      else if (r = newregion2) then newregion2struct 
      else pd.rcmap(r) in
  let (newmarkedby,newmarks) = 
	if circleflag then (pd.markedby,pd.marks)
	else (
  let sds1 = ssegextract(newinc(dot)) in
  let sds2 = ssegextract(newinc(newdot)) in
  let pseg1 = circular_precedesinlist(newseg,sds1) in
  let pseg2 = circular_precedesinlist(newseg,sds2) in
  let newmarkedbyr = function m ->
		match m with 
			Dseg(l) -> (pd.markedby)(Dseg(l))
			|Angle(l) ->
				if segdividesangle(newseg,l,pd,dot,pseg1,newdot,pseg2) 
				then [] 
				else 
					let l2 = 
						doublereplaceinlist(l,(dot,newseg),[],(newdot,newseg),[]) in
					(pd.markedby)(Angle(sort_diang(l2)))
			| RegionSet(rs) ->
				if inset(newregion1,rs) & inset(newregion2,rs)
				then
					let newrs = 
							setadjoin(region, setremove(newregion1,setremove(newregion2,rs))) in
					let newrs2 = List.fast_sort reg_compare newrs in
					pd.markedby(RegionSet(newrs2))
				else pd.markedby(RegionSet(rs))
	in
	let newmarksr =
		let markerupdate = 
			function  m ->
				match m with 
					Dseg(l) -> Dseg(l)
					|Angle(l) ->
						let l2 = 
							doublereplaceinlist(l,(dot,pseg1),(dot,pseg1)::(dot,newseg)::[],
												(newdot,pseg2),(newdot,pseg2)::(newdot,newseg)::[]) in
						Angle(sort_diang(l2))
					|RegionSet(rs) ->
							if inset(region,rs) 
							then 
								let newrl = setadjoin(newregion1,
													setadjoin(newregion2,setremove(region,rs))) in
								let newrl2 = List.fast_sort reg_compare newrl in
								(RegionSet(newrl2))
							else (RegionSet(rs))
		in
		function m ->
			let oldmarks = (pd.marks)(m) in
			let newmarks1 = List.map markerupdate oldmarks in
			newmarks1
	in
	(newmarkedbyr,newmarksr)) in
  let newpd ={rmap = newrmap;
				  rcmap = newrcmap;
				  graph = newgraphstruct;
				  lmakeup = newlmakeup;
				  cmakeup = newcmakeup;
				  lines = pd.lines;
				  circs = pd.circs;
				  member = newmember;
				  intersect = newintersect;
				  markers = pd.markers;
				  markedby = newmarkedby;
				  marks = newmarks} in
	(newpd, 
	newseg,
	newregion2)
	 

(********************)
(* Display Diagrams *)
(********************)			

(* Display diagrams add possible coordinates for points. 
   First, we create display diagrams with placeholder coordinates.
   Second, we do some processing of the diagram to make it appropriate 
   to be laid out.  The newdiagram must be simple and connected, so we
   add some new invisible edges/dots.  We also add new dots for region labels.
   Third, we create a string representing the diagram in gml format.
   Fourth, we call an external C++ routine using OGDF to lay out the 
   display diagram.
   Fifth, the external routine returns a string with coordinates, and we 
   import these coordinates into our display diagram.

 *)

type dot_coord = XY of (float * float) | NullCoord;;
type dot_hw = HW of (float * float) | NullHW;;
type edge_coord = dot_coord list;;

type display_dot_type = NormalDot | InvisibleDot | FaceMarker of int;;
type display_edge_type = NormalEdge | InvisibleEdge | StandInUnmarked 
			 | StandInMarked of int;;

type display_diagram =
    {diag: pd;
     dotmap: (dot -> (dot_coord * dot_hw * display_dot_type));
     edgemap: (segment -> (edge_coord * display_edge_type));};;

let dd_initial(pd) =
  {diag = pd;
   dotmap = (function d -> (NullCoord,NullHW,NormalDot));
   edgemap = (function s -> ([],NormalEdge));};;

(* diagram processing *)

(* any self loops get three dots b/c the graph must be simple *)
let rec  remove_self_loops(dd) = 
  rec_remove_self_loops(dd,dd.diag.graph.segs) 
and rec_remove_self_loops(dd,segset) =
  match segset with
      first::rest -> rec_remove_self_loops(remove_one_loop(dd,first),rest)
    | _ -> dd
and remove_one_loop(dd,seg) =
  match dd.diag.graph.emap(seg) with
      Loop(r1,r2) -> 
	let (newdot1,discard2,discard3,discard4,discard5,pd2) =
	  add_dot_to_seg(dd.diag,seg) in
	let (newdot2,pnewseg1,oldend1,oldend2,pnewseg2,pd3) =
	  add_dot_to_seg(pd2,seg) in
	let (newdot3,pnewseg3,oldend3,oldend4,pnewseg4,pd4) =
	  add_dot_to_seg(pd3,sse2seg(pnewseg2)) in  
	let newedgemap = 
	  extendfunction(
	  extendfunction(extendfunction(dd.edgemap,sse2seg(pnewseg1),
					([],StandInMarked(seg.snum))),
			 sse2seg(pnewseg3),([],StandInUnmarked)),
			 sse2seg(pnewseg4),([],StandInUnmarked)) in
	let newdotmap = 
	  extendfunction(
	  extendfunction(extendfunction(dd.dotmap,newdot1,
					(NullCoord,NullHW,InvisibleDot)),
			 newdot2, (NullCoord,NullHW,InvisibleDot)),
			 newdot3, (NullCoord,NullHW,InvisibleDot)) in
	  {diag = pd4;
	   dotmap = newdotmap;
	   edgemap = newedgemap;}
    | DotPair(d1,d2) when d1 = d2 -> 
	let (newdot1,pnewseg1,oldend1,oldend2,pnewseg2,pd3) =
	  add_dot_to_seg(dd.diag,seg) in
	let (newdot2,pnewseg3,oldend3,oldend4,pnewseg4,pd4) =
	  add_dot_to_seg(pd3,sse2seg(pnewseg2)) in 
	let newedgemap = 
	  extendfunction(
	  extendfunction(extendfunction(dd.edgemap,sse2seg(pnewseg1),
					([],StandInMarked(seg.snum))),
			 sse2seg(pnewseg3),([],StandInUnmarked)),
			 sse2seg(pnewseg4),([],StandInUnmarked)) in
	let newdotmap = 
	  extendfunction(extendfunction(dd.dotmap,newdot1,
					(NullCoord,NullHW,InvisibleDot)),
			 newdot2, (NullCoord,NullHW,InvisibleDot)) in
	  {diag = pd4;
	   dotmap = newdotmap;
	   edgemap = newedgemap;}
    | _ -> dd;;
	
let get_odot(dot,ends)=
	match ends with
		DotPair(dot1,dot2) when dot1 = dot ->
			dot2
		| DotPair(dot1,dot2) when dot2 = dot ->
			dot1
		| _ -> raise BadInput;;

let dd_add_dot_to_seg(dd,seg) =
	let (newdot,pnewseg1,oldend1,oldend2,pnewseg2,pd3) =
	  add_dot_to_seg(dd.diag,seg) in
	let newedgemap = 
	  extendfunction(extendfunction(dd.edgemap,sse2seg(pnewseg1),
					([],StandInMarked(seg.snum))),
			 sse2seg(pnewseg2),([],StandInUnmarked)) in
	let newdotmap = 
	  extendfunction(dd.dotmap,newdot,
			 (NullCoord,NullHW,InvisibleDot)) in
	  {diag = pd3;
	   dotmap = newdotmap;
	   edgemap = newedgemap;};;
	
let rec  make_simple_one_dot(dd,dot,seglist,odots) =
	match seglist with
	segend::rest ->
		let seg = sse2seg(segend) in
		let odot = get_odot(dot,dd.diag.graph.emap(seg)) in
			if inset(odot,odots)
			then make_simple_one_dot(dd_add_dot_to_seg(dd,seg),dot,rest,odots)
			else make_simple_one_dot(dd,dot,rest,odot::odots)
	| _ -> dd;;	
	
let rec  rec_make_simple(dd, dotlist) =
	match dotlist with
	dot::rest -> 
		rec_make_simple(
		make_simple_one_dot(dd,dot,segextract(dd.diag.graph.inc(dot)),[]),rest)
	| _ -> dd;;
	
let make_simple(dd)=
	rec_make_simple(dd, dd.diag.graph.dots);; 


let rec get_first_edot(list) =
  match list with
      DI(sse1,dot,sse2)::rest -> DI(sse1,dot,sse2)
    | SD(dot)::rest -> SD(dot)
    | first::rest -> get_first_edot(rest)
    | _ -> raise BadInput;;

let is_facemarker(ddt) =
  match ddt with
     (_,_, FaceMarker(i)) -> true
    | _ -> false;;

let rec get_labeled_edot(list,dmap) =
  rec_get_labeled_edot(list,[],dmap)
and rec_get_labeled_edot(slist,olist,dmap) =
  match slist with
      Dot(dot)::Seg(seg)::rest  when is_facemarker(dmap(dot)) ->
	(DI(Plain(seg),dot,Plain(seg)),append(slist,olist))
    | Dot(dot)::[] when is_facemarker(dmap(dot)) ->
	(match olist with
	     Seg(seg)::rest ->
	       	(DI(Plain(seg),dot,Plain(seg)),append(slist,olist))
	   | _ -> raise BadInput)
    | first::rest -> rec_get_labeled_edot(rest,append(olist,[first]),dmap)
    | _ -> raise BadInput;;
  



let get_boundry_dots(pd,reg) =
  let outside_boundry = pd.rmap(reg) in
  let outerdot = get_first_edot(dEIify(outside_boundry,Out,pd)) in
  let ris = pd.rcmap(reg) in
  let ibl = ris.int_bd_list in
  let in_dEIify = function x -> dEIify(x,In,pd) in
  let outlist = List.map dei2edot
		  (List.map get_first_edot (List.map in_dEIify ibl)) in
    (outerdot,outlist,ibl);;

let fakeline = Line(newline());;

let update_ereg(ereg,seg) =
  match ereg with
      RT(sse1,dot,sse2) -> RT(Plain(seg),dot,sse2)
    | _ -> raise BadInput;;

let update2_ereg(ereg,seg,nreg) =
  match ereg with
      RT(sse1,reg,sse2) -> RT(Plain(seg),nreg,sse2)
    | _ -> raise BadInput;;
      

let rec rec_attach_component(pd,ereg,edgemap,outdot,indotlist,complist) =
  match indotlist with
      enewdot::rest -> 
	let firstcomp = firstelt(complist) in
	let (newpd,newseg) =
	  joinoidots_return_pdseg(pd,eflip(ereg),outdot,enewdot,fakeline,
				  DotGoal(extractdot(enewdot)),
				  firstcomp,OI) in
	let newedgemap = 
	  extendfunction(edgemap,newseg,([],InvisibleEdge)) in
	  rec_attach_component(newpd,update_ereg(ereg,newseg),newedgemap,
			       outdot,rest,cdr(complist))
    | _ -> (pd,edgemap);;


let rec make_connected(dd) = 
  rec_make_connected(dd,dd.diag.graph.regs)
and rec_make_connected(dd,regs) =
  match regs with
      first::rest -> rec_make_connected(connect_into_one_reg(dd,first),
					rest)
    | _ -> dd
and connect_into_one_reg(dd,reg) =
  let (newdot,pd) = add_dot_to_reg(dd.diag,reg) in
  let (eoutdot,inlist,ibl) = get_boundry_dots(pd,reg) in
  let (outdot,ereg) = dEIified_dot_2_ereg(eoutdot,reg) in
  let (newpd,newedgemap) = 
    rec_attach_component(pd,ereg,dd.edgemap,outdot,inlist,ibl) in
  let newdotmap = extendfunction(dd.dotmap, newdot, 
				 (NullCoord,NullHW,
				  FaceMarker(reg.rnum))) in
    {diag=newpd;
     dotmap = newdotmap;
     edgemap = newedgemap;};;

let rec make_double_connected(dd) =
  rec_make_dconnected(dd,dd.diag.graph.regs)
and rec_make_dconnected(dd,regs) =
  match regs with
      first::rest -> rec_make_dconnected(dconnect_into_one_reg(dd,first),
					 rest)
    | _ -> dd
and dconnect_into_one_reg(dd,reg) =
  let pd = dd.diag in
  let blist = pd.rmap(reg) in
  let (anchor,r_blist) = get_labeled_edot(blist,dd.dotmap) in
  let de_blist = dEIify(r_blist,Out,pd) in
  let (adot,ereg) = dEIified_dot_2_ereg(anchor,reg) in
    rec_dconnect(dd,ereg,anchor,adot,de_blist)
and rec_dconnect(dd,ereg,anchor,adot,de_blist) =
  match (de_blist,anchor) with
      (DI(sse1,dot,sse2)::rest, DI(asse1,adot,asse2)) 
	 when sse1 = asse2 or sse2 = asse1 or adot = dot ->
	   (* the first elt of the list is adjacent to the anchor, *)
	   (* and therefore already connected.  *)
	   rec_dconnect(dd,ereg,anchor,adot,rest)
    | (DI(sse1,dot,sse2)::rest,_) ->
	let (newdd,newereg) =
	  dconnect_2pts(adot,DI(sse1,dot,sse2),dd,ereg)
	in
	  rec_dconnect(newdd,newereg,anchor,adot,rest)
    | (first::rest,_) -> rec_dconnect(dd,ereg,anchor,adot,rest)
    | _ -> dd
and dconnect_2pts(adot,newpoint,dd,ereg) =
  let pd = dd.diag in
  let (newpd,newseg,newreg) =
    joinodots_return_seg_reg(pd,ereg,adot,
			     dei2edot(newpoint),fakeline) in
  let newedgemap = 
    extendfunction(dd.edgemap,newseg,([],InvisibleEdge)) in
  let newereg = update2_ereg(ereg,newseg,newreg) in
    ({diag=newpd;
      dotmap = dd.dotmap;
      edgemap = newedgemap;},
     newereg);;


let pd2dd(pd) = 
	let dd = make_connected(make_simple(remove_self_loops(dd_initial(pd)))) in
	pd_register_names(dd.diag);
	dd;;


let pd2dcdd(pd) = make_double_connected(pd2dd(pd));;


(* Output to GML format *)

let fix_float(string) = 
 if String.contains string '.'
 then string
 else string^".0";;

let good_string_of_float float = 
  fix_float(string_of_float float);;

let rec output2gdtformatstring(dd) =
	let out = "<UNDISECTION> \n"^"<NODELIST> \n" in
	let out2 = output_nodelist_2gdtstring("",dd,dd.diag.graph.dots) in
    let out3 = "</NODELIST> \n"^"</UNDISECTION> \n" in
	out^out2^out3
and output_nodelist_2gdtstring(outstring,dd,nodelist) =
  match nodelist with
      first::rest -> 
		let newoutstring = output_node_2gdtstring(outstring,dd,first) in
			output_nodelist_2gdtstring(newoutstring,dd,rest)
	  | _ -> outstring
and output_node_2gdtstring(outstring,dd,node) =
  let newout1 = "<NODE> "^(string_of_int node.dnum)^" " in
  let newout2 =output_edges_2gdtstring("",dd,node,(dd.diag.graph.inc)(node)) in
  let newout3 = " </NODE> \n" in
	outstring^newout1^newout2^newout3
and output_edges_2gdtstring(outstring,dd,node,edgelist) =
  match edgelist with
      DSSeg(edge)::rest ->
		let newout =  "<EDGE> "^(string_of_int (sse2seg(edge)).snum)^" -- " in
			output_edges_2gdtstring(outstring^newout,dd,node,rest)
    | first::rest -> output_edges_2gdtstring(outstring,dd,node,rest)
    | _ -> outstring;;


let rec find_first_fdot(dotlist) =
  match dotlist with
      dot::rest when (isframedot(dot)) -> dot
    | dot::rest -> find_first_fdot(rest)
    | _ -> raise BadInput;;

let rec find_ext_seg(dslist) =
  match dslist with
      DSSeg(seg)::Reg(reg)::rest when reg = outerregion -> sse2seg(seg) 
    | first::rest -> find_ext_seg(rest)
    | _ -> raise BadInput;;

let get_ext_face_info(dd) = 
  let dot = find_first_fdot(dd.diag.graph.dots) in
  let dslist = (dd.diag.graph.inc)(dot) in
  let dbdslist  =double(dslist) in
  let seg = find_ext_seg(dbdslist) in
    (dot,seg);;




let output_one_node_2gml(out,dd,node) = 
  let output string = output_string out string in
  let (x_coord,y_coord,h_coord,w_coord,disp_dot_type) =
    match (dd.dotmap)(node) with
	(XY(x,y),HW(h,w),ddt) -> (x,y,h,w,ddt)
      | _ -> raise BadInput 
  in
    match disp_dot_type with
	NormalDot ->
	  (output "   node [ \n";
	   output "     id ";
	   output (string_of_int (node.dnum));
	   output " \n";
	   output "     label \"";
	   output (string_of_int node.dnum);
	   output "\" \n";
	   output "       labelAnchor \"c\"\n ";
	   output "     graphics [ \n";
	   output "       x ";
	   output (good_string_of_float x_coord);
	   output " \n ";
	   output "       y ";
	   output (good_string_of_float y_coord);
	   output " \n ";
	   output "       h ";
	   output (good_string_of_float h_coord);
	   output " \n ";
	   output "       w ";
	   output (good_string_of_float w_coord);
	   output " \n ";
	   output "       type \"oval\"\n";
	   output "       width .3 \n";
	   output "       fill \"#FFFFE4\"\n";
	   output "       outline \"#000000\"\n";
	   output "     ]\n";
	   output "     LabelGraphics  [\n";
	   output "       type \"text\"\n";
	  (* output "       fill \"#000000\"\n";*)
	   output "       anchor \"c\"\n";
	   output "     ]\n";
	   output "   ]   \n";)
      | FaceMarker(faceid) ->
	  (output "   node [ \n";
	   output "     id ";
	   output (string_of_int (node.dnum));
	   output " \n";
	   output "     label \"";
	   output (string_of_int faceid);
	   output "\" \n";
	   output "       labelAnchor \"c\" \n";
	   output "     graphics [ \n";
	   output "       x ";
	   output (good_string_of_float x_coord);
	   output " \n ";
	   output "       y ";
	   output (good_string_of_float y_coord);
	   output " \n ";
	   output "       h ";
	   output (good_string_of_float h_coord);
	   output " \n ";
	   output "       w ";
	   output (good_string_of_float w_coord);
	   output " \n ";
	   output "       type \"rectangle\"\n";
	   output "       width .3 \n";
	   output "       fill \"#FFFFE4\"\n";
	(*   output "       outline \"#FFFFFF\"\n"; *)
	   output "     ]\n";
	   output "     LabelGraphics  [\n";
	   output "       type \"text\"\n";
	   output "       fill \"#FF0000\"\n";
	   output "       anchor \"c\"\n";
	   output "     ]\n";
	   output "   ]   \n";)
      |InvisibleDot ->
	  (output "   node [ \n";
	   output "     id ";
	   output (string_of_int (node.dnum));
	   output " \n";
	   output "       labelAnchor \"c\" \n";
	   output "     graphics [ \n";
	   output "        x ";
	   output (good_string_of_float x_coord);
	   output " \n ";
	   output "       y ";
	   output (good_string_of_float y_coord);
	   output " \n ";
	   output "       h ";
	   output "0.01";
	   output " \n ";
	   output "       w ";
	   output "0.01";
	   output " \n ";
	   output "       type \"rectangle\"\n";
	   output "       width 0.001 \n";
	   output "       fill \"#FFFFFF\"\n";
	   output "       outline \"#FFFFFF\"\n";
	   output "     ]\n";
	   output "     LabelGraphics  [\n";
	   output "       type \"text\"\n";
	  (* output "       fill \"#000000\"\n";*)
	   output "       anchor \"c\"\n";
	   output "     ]\n";
	   output "   ]   \n";);;	

let rec output_bendlist_2gml(out,bend_list) = 
  let output string = output_string out string in
    output "       Line [ \n";
    rec_output_bendlist_2gml(out,bend_list);
    output "       ] \n";
and rec_output_bendlist_2gml(out,bend_list) =
  let output string = output_string out string in
    match bend_list with
	XY(x_coord,y_coord)::rest ->
	  (output "         point [ \n";
	   output "           x ";
	   output (good_string_of_float x_coord);
	   output " \n";
	   output "           y ";
	   output (good_string_of_float y_coord);
	   output " \n";
	   output "         ] \n";
	   rec_output_bendlist_2gml(out,rest);)
      | _ -> ();;

	 

let output_one_edge_2gml(out,dd,edge,color) = 
  let output string = output_string out string in
  let (bend_list,disp_edge_type) = (dd.edgemap)(edge) in
  let (enddot1,enddot2) = 
    match (dd.diag.graph.emap)(edge) with 
	DotPair(dot1,dot2) -> (dot1,dot2)
      | _ -> raise BadInput
  in
  let (dot1_coord,hw,dot1_ddt) = (dd.dotmap)(enddot1) in
  let (sourcedot,targetdot) = (* make sure source/target match bendlist *)
    if dot1_coord = firstelt(bend_list) 
    then (enddot1,enddot2)
    else (enddot2,enddot1) in   
  let edge_type = edge.ssty in
    match disp_edge_type with
	InvisibleEdge -> ()
      | _ ->
	  (output "   edge [ \n";
	   output "     source ";
	   output (string_of_int (sourcedot.dnum));
	   output " \n";
	   output "     target ";
	   output (string_of_int (targetdot.dnum));
	   output " \n";
	   output "     label \"";
	   (match disp_edge_type with
	       NormalEdge ->
		 output (string_of_int (edge.snum))
	     | StandInUnmarked ->
		 output " " 
	     | StandInMarked(marker) ->
		 output (string_of_int marker)
	     | _ -> raise BadInput);		 
	   output "\" \n";
	   output "     graphics [ \n";
	   output "       type \"line\"\n";
	   output "       arrow \"none\" \n";
	   ( match edge_type with 
	       Dotted ->
		 (output "       style \"dashed_edge\"";
		  output "       width 0.15  \n";
		  output_color_line(out,color)) 
	     | Solid -> 
		 (output "       width 0.15  \n";
		  output_color_line(out,color)) 
	     | Frame -> 
		 (output "       width 0.293595  \n";
		  output_color_line(out,black)) );
	   output_bendlist_2gml(out,bend_list);
	   output "     ]\n";
	   output "     LabelGraphics  [\n";
	   output "       type \"text\"\n";
	   (*output "       fill \"#000000\"\n";*)
	   output "       anchor \"e\"\n";
	   output "     ]\n";
	   output "   ]   \n";)


let rec output_nodes_2gml(out,dd,dots) =
  match dots with
      first::rest -> 
	(output_one_node_2gml(out,dd,first);
	 output_nodes_2gml(out,dd,rest))
    | _ -> ();;

let rec output_edges_2gml(out,dd,edges) =
  match edges with
      first::rest -> 
	let geo_obj = (dd.diag.member)(first) in
	let index = 
	  match geo_obj with
	      Line(l) -> l.lnum
	    | Circ(c) -> c.cnum
	    | _ -> 0 in
	let color = array_lookup_color(index) in
	(output_one_edge_2gml(out,dd,first,color);
	 output_edges_2gml(out,dd,rest))
    | _ -> ();;
    
let output2gml(dd, filename, label) =
  let out = open_out(filename) in 
  let output string = output_string out string in
  (*let lines = dd.diag.lines in
  let circs = dd.diag.circs in
  let array = color_array in
    reset_color_counter();
    rec_color_lines(lines,array);
    rec_color_circs(circs,array);*)
    output "Creator \"CDEG\" \n";
    output "Version 1.4  \n \n";
    output "graph [ \n \n";
    output (( "label \" "^label)^" \"  \n");
    output "directed 0 \n \n";
    output_nodes_2gml(out,dd,dd.diag.graph.dots);
    output_edges_2gml(out,dd,dd.diag.graph.segs);
    output "] \n";
    close_out(out);;



let output2gml(dd,filename) = output2gml(dd,filename, "   ");;


(* input coordinates from string *)

open Genlex;;

let gml_lex = 
  Genlex.make_lexer ["[";"]";"node";"label";"x";
		     "y";"w";
		     "h";"edge";"Line";"point"];;
		     
let rec next_token intokens =
	match Stream.next intokens with
		Ident(string1) -> next_token intokens
		| token -> token;;
		
let rec get_label intokens =
	match Stream.next intokens with
		Kwd(string1) when string1 = "label" ->
			let string2 = 
				match Stream.next intokens with
					String(string3)-> string3
					| _ -> raise BadInput
			in
				int_of_string(string2)
		| _ -> get_label intokens;;

let njunk intokens  = 
  ignore (Stream.next intokens);;
  
(* we ignore any information after the node height to the end of the node *)  
let rec finish_node( intokens) =
	match (Stream.next intokens) with
		Kwd(string1) when string1 = "]" ->
			njunk intokens;
			()
		|_ -> finish_node intokens;;

let rec find_Line_in_stream(intokens) =
	match (Stream.next intokens) with
		Kwd(string1) when string1 = "Line" ->
			njunk intokens;
			()
		|_ -> find_Line_in_stream(intokens);;

		
let get_float_from_stream(intokens) =
  match (Stream.next intokens) with
	Float(float_value) -> float_value
    | Int(int_value) -> float_of_int(int_value)
    | _ -> raise BadInput;;
	
let rec get_ncoords_from_stream(intokens) = 
  match Stream.next intokens with
	Kwd(string1) when string1 = "x" ->
		let x_coord = get_float_from_stream(intokens) in
			njunk intokens; (* should be "y" *)
			let y_coord = get_float_from_stream(intokens) in
				njunk intokens; (* should be "w" *)		
				let w_coord = get_float_from_stream(intokens) in
					njunk intokens; (* should be "h" *)
					let h_coord = get_float_from_stream(intokens) in
						finish_node(intokens);
						(x_coord,y_coord,w_coord,h_coord)
	| token -> get_ncoords_from_stream(intokens);;

(* get_bend_list_from_stream assumes we have just seen "Line [" *)
let rec get_bend_list_from_stream(intokens,list) =
	match (Stream.next intokens) with
      Kwd(string) when string = "point" ->
		njunk intokens;
		njunk intokens; (* should be [ x *)
		let x_coord = get_float_from_stream(intokens) in
			njunk intokens; (* should be "y" *)
			let y_coord = get_float_from_stream(intokens) in	
				njunk intokens;
				get_bend_list_from_stream(intokens, XY(x_coord,y_coord)::list)
    | Kwd(string) when string = "]" ->
		njunk intokens;
		njunk intokens; (* get rid of rest of edge entry ]'s *)
		list
    | _ -> raise BadInput;;

let update_one_node_from_stream(dd,intokens) =
	let nodeid = get_label(intokens) in
		let (x_coord,y_coord,w_coord,h_coord) =	get_ncoords_from_stream(intokens) in
			let dot = getdot(nodeid) in
				let (old_dot_coord,old_hw_coord,disp_dot_type) =(dd.dotmap)(dot) in
					let newdotmap = 
						extendfunction(dd.dotmap,dot,(XY(x_coord,y_coord),
										HW(h_coord,w_coord),
										disp_dot_type)) in
						{diag= dd.diag;
						dotmap = newdotmap;
						edgemap = dd.edgemap;};;

let update_one_edge_from_stream(dd, intokens) =
	let edgeid	 = get_label(intokens) in
		find_Line_in_stream(intokens);
		let plist = get_bend_list_from_stream(intokens,[]) in
			let edge = getseg(edgeid) in
			let (old_ecoord,disp_edge_type) =
				(dd.edgemap)(edge) in
			let newedgemap = 
				extendfunction(dd.edgemap,edge,(plist, disp_edge_type)) in
				{diag= dd.diag;
				dotmap = dd.dotmap;
				edgemap = newedgemap;};;

let rec update_dd_from_stream(dd,intokens) =
	let ntok = Stream.next intokens in
	match ntok with
	Kwd(string1) when string1 = "node" ->
		let ndd = update_one_node_from_stream(dd, intokens) in
			update_dd_from_stream(ndd, intokens)
	|Kwd(string1) when string1 = "edge" ->
		let ndd = update_one_edge_from_stream(dd, intokens) in
			update_dd_from_stream(ndd, intokens)
	|Kwd(string1) when string1 = "]" -> 
		dd
	|_ -> raise BadInput;;




let update_dd_from_gml_string(dd,returnstring) =
  let instream = Stream.of_string returnstring in
  let intokens = gml_lex instream in
	for i = 1 to 6 do
		njunk intokens;
	done;
	update_dd_from_stream(dd,intokens);;


(* module for external layout routine *)      
module Clayout =
	struct
		(*external layout: int -> int -> int = "layout_stub"*)
		external layouts: int -> int -> string -> string = "layouts_stub"
	end;;
	  

let run_external_string(dd,outputstring) =
	let (ext_face_dot,ext_face_seg) = get_ext_face_info(dd) in
		Clayout.layouts(ext_face_dot.dnum)(ext_face_seg.snum)(outputstring);;

let update_dd(dd) =
  let outputstring =output2gdtformatstring(dd)in
 (* print_string("\n ***** 2 ***** \n");
  print_string(outputstring);
  read_line();*)
  let returnstring =run_external_string(dd,outputstring)in
  (* print_string("\n ***** 3 ***** \n");
  read_line();*)
   let newdd = update_dd_from_gml_string(dd,returnstring) in   
    newdd;;
	
(* Output to gml format file *)	

let gmloutputfile = "outputgraph.gml";;

let run_gw() = 
	print_string("Diagram saved.\n");; 

let quiet_output_pd(pd,filename) =
  let dd = pd2dd(pd) in
  let newdd = update_dd(dd) in
    output2gml(newdd,filename);;

let output_gml_pd(pd,filename) =
  let dd = pd2dd(pd) in
  let newdd = update_dd(dd) in
    output2gml(newdd,filename);
    run_gw();;

(****************)
(*  Graphics    *)
(****************)

(* Drawing display diagrams graphically *)

(*set constants *)	
let dot_length = 8.0;;
let box_pad = 3;;
let circle_pad = 3;;
let default_width = 1;;
let frame_width = 3;;
let margin_size = 30;;
let edge_label_color = 0xB0E2FF;;
let dot_label_color = 0xFFFFE4;;
let face_label_color = 0xEE6363;;	
(*let max_screen_x = 1300;;
let max_screen_y = 800;;
let max_screen_x = 1200;;
let max_screen_y = 750;;*)
let max_screen_x = 700;;
let max_screen_y = 520;;


let scalefactor = ref 1.0;;


let print_coord(x,y) =
	print_int(x);
	print_string(", ");
	print_int(y);
	print_string("\n");;
	
let print_fcoord(x,y) =
	print_float(x);
	print_string(", ");
	print_float(y);
	print_string("\n");;

(* This is where we can scale/adjust coordinates for the graphics window.
We flip the y axis to account for the difference between gml and xwindow conventions*)
let adjust_coords(x, y) =
	let window_height = Graphics.size_y() in
	if !scalefactor = 1.0
	then (int_of_float(x)+margin_size, window_height - (int_of_float(y)+margin_size))
	else 
		(int_of_float(float_of_int(int_of_float(x)+margin_size) *. !scalefactor),
		 window_height - (int_of_float(float_of_int(int_of_float(y)+margin_size) *. !scalefactor)));;
		


let draw_m_dotted_lineto m xto yto =
	let x = Graphics.current_x() in
	let y = Graphics.current_y() in
	let fdx = float_of_int(xto - x) in
	let fdy = float_of_int(yto - y) in
	let fm = float_of_int(m) in 
	let ndx = fdx /. fm in 
	let ndy = fdy /. fm in 
	for i = 1 to m / 2 do 
		Graphics.lineto (x + int_of_float(float_of_int((2 * i)-1) *. ndx) )
						(y + int_of_float(float_of_int((2 * i)-1) *. ndy) )		;
		Graphics.moveto (x + int_of_float(float_of_int(2 * i) *. ndx) )
						(y + int_of_float(float_of_int(2 * i) *. ndy) )		;
	done;
(*	if (m mod 2 = 1) then 
		begin 
		Graphics.rlineto ndx ndy;
		end; *)
	Graphics.lineto xto yto;;

	
let draw_dotted_lineto xto yto =
	let x = Graphics.current_x() in
	let y = Graphics.current_y() in
	
	let dx = float_of_int(xto - x) in
	let dy = float_of_int(yto - y) in 
	let d = sqrt(dx ** 2.0 +. dy ** 2.0) in 
	let m = int_of_float(d /. dot_length) in
	draw_m_dotted_lineto m xto yto;;
	
let draw_labeled_box(txt, xc, yc, bgcolor, outlinecolor, textcolor) =
	let (tsx,tsy) = Graphics.text_size(txt) in
	let (startx,starty) = (xc - tsx / 2 - box_pad , yc - tsy / 2 - box_pad) in
		Graphics.set_color(bgcolor);
		Graphics.fill_rect startx starty (tsx + 2 * box_pad) (tsy + 2 * box_pad);
		Graphics.set_color(outlinecolor);
		Graphics.draw_rect startx starty (tsx + 2 * box_pad) (tsy + 2 * box_pad);
		Graphics.moveto (startx + box_pad) (starty + box_pad);
		Graphics.set_color(textcolor);
		Graphics.draw_string(txt);;

let draw_labeled_circle(txt, xc, yc, bgcolor, outlinecolor, textcolor) =
	let (tsx,tsy) = Graphics.text_size(txt) in
	let (ftsx,ftsy) = (float_of_int(tsx),float_of_int(tsy)) in
	let rf = sqrt((ftsx *. 0.5)**2.0 +. (ftsy *. 0.5)**2.0) in
	let radius = (circle_pad + int_of_float(rf)) in
	let (startx,starty) = (xc - tsx / 2  , yc - tsy / 2 ) in
		Graphics.set_color(bgcolor);
		Graphics.fill_circle xc yc radius;
		Graphics.set_color(outlinecolor);
		Graphics.draw_circle xc yc radius;
		Graphics.moveto startx starty;
		Graphics.set_color(textcolor);
		Graphics.draw_string(txt);;
		
		
let rec draw_line_seq(bend_list, color, width) = 
	Graphics.set_color(color);
	Graphics.set_line_width(width);
	match bend_list with
	XY(x_coord,y_coord)::rest ->
		let (x,y) = adjust_coords(x_coord,y_coord) in
		Graphics.moveto x y;
		rec_draw_line_seq(rest);
		Graphics.set_line_width(default_width)
	| _ -> raise BadInput;
and rec_draw_line_seq(bend_list) =
    match bend_list with
	XY(x_coord,y_coord)::rest ->
		let (x,y) = adjust_coords(x_coord,y_coord) in
		Graphics.lineto x y;
		rec_draw_line_seq(rest)
	| _ -> ();;



let rec draw_dotted_line_seq(bend_list, color, width) = 
	Graphics.set_color(color);
	Graphics.set_line_width(width);
	match bend_list with
	XY(x_coord,y_coord)::rest ->
		let (x,y) = adjust_coords(x_coord,y_coord) in
		Graphics.moveto x y;
		rec_draw_dotted_line_seq(rest);
		Graphics.set_line_width(default_width)
	| _ -> raise BadInput;
and rec_draw_dotted_line_seq(bend_list) =
    match bend_list with
	XY(x_coord,y_coord)::rest ->
		let (x,y) = adjust_coords(x_coord,y_coord) in
		draw_dotted_lineto x y;
		rec_draw_dotted_line_seq(rest);
	| _ -> ();;
	 
let find_first_midpoint(bend_list) =
	match bend_list with
		XY(x_coord1,y_coord1)::XY(x_coord2,y_coord2)::rest ->
			adjust_coords(((x_coord1 +. x_coord2) /. 2.0), ((y_coord1 +. y_coord2) /. 2.0))
		| _ -> raise BadInput;;

let draw_one_edge(dd,edge) = 
  let (bend_list,disp_edge_type) = (dd.edgemap)(edge) in
  let edge_type = edge.ssty in
    match disp_edge_type with
	InvisibleEdge -> ()
	| _ ->
			let geo_obj = (dd.diag.member)(edge) in
			let index = 
				match geo_obj with
					Line(l) -> l.lnum
					| Circ(c) -> c.cnum
					| _ -> 0 in
			let color = array_lookup_color(index) in
			begin
			match edge_type with
				Solid ->
					draw_line_seq(bend_list,color,default_width)
				| Dotted ->
					draw_dotted_line_seq(bend_list,color,default_width)
				| Frame ->
					draw_line_seq(bend_list,color,frame_width)
			end;
			begin
			match disp_edge_type with
				NormalEdge ->
					let ltxt = string_of_int(lookup_dn(edge.snum)) in
					let (x_coord,y_coord) = find_first_midpoint(bend_list) in
						draw_labeled_box(ltxt, x_coord, y_coord, edge_label_color, Graphics.blue, Graphics.black)
				| StandInMarked(marker) ->
					let ltxt = string_of_int(lookup_dn(marker)) in
					let (x_coord,y_coord) = find_first_midpoint(bend_list) in
						draw_labeled_box(ltxt, x_coord, y_coord, edge_label_color, Graphics.blue, Graphics.black)
				| StandInUnmarked -> ()
				| _ -> raise BadInput
			end;;


		
		
let draw_node(dd,node) = 
  let (x_orig,y_orig,h_coord,w_coord,disp_dot_type) =
    match (dd.dotmap)(node) with
	(XY(x,y),HW(h,w),ddt) -> (x,y,h,w,ddt)
      | _ -> raise BadInput 
  in
  let (x_coord,y_coord) = adjust_coords(x_orig,y_orig) in
    match disp_dot_type with
	NormalDot ->
		let ltxt = string_of_int(lookup_dn(node.dnum)) in
		draw_labeled_circle(ltxt,x_coord,y_coord,dot_label_color,Graphics.black,Graphics.black)
	| FaceMarker(faceid) ->
		let ltxt = string_of_int(lookup_dn(faceid)) in
		draw_labeled_box(ltxt, x_coord, y_coord, face_label_color,Graphics.black,Graphics.black)
      |InvisibleDot -> ();;	

let rec draw_nodes(dd,dots) =
  match dots with
      first::rest -> 
		(draw_node(dd,first);
		draw_nodes(dd,rest))
		| _ -> ();;

let rec draw_edges(dd,edges) =
	match edges with
		first::rest -> 
	(draw_one_edge(dd,first);
	 draw_edges(dd,rest))
    | _ -> ();;


let rec frame_coordinate_list(edges,edgemap,co_list) =
	match edges with
		first::rest ->
			begin
			if first.ssty = Frame 
			then 
				let (bend_list,disp_edge_type) = edgemap(first) in
					frame_coordinate_list(rest,edgemap, bend_list@co_list)
			else
				frame_coordinate_list(rest,edgemap,co_list);
			end;
		| _ -> co_list;;


let rec max_coords_from_list(c_list, x_max, y_max) =
	match c_list with
		XY(x,y)::rest ->
			let newx = (if x > x_max then x else x_max) in
			let newy = (if y > y_max then y else y_max) in
				max_coords_from_list(rest,newx,newy)
		| _ -> (int_of_float(x_max),int_of_float(y_max));;

let get_max_coord(dd) =
	let edges = dd.diag.graph.segs in
	let fcoordlist = frame_coordinate_list(edges, dd.edgemap,[]) in
	max_coords_from_list(fcoordlist,0.0,0.0);;

let draw_dd(dd) =
	let (max_x, max_y) = get_max_coord(dd) in
	let (x_dim, y_dim) = (max_x + 2 * margin_size, max_y + 2 * margin_size) in
	let (x_dim_scaled, y_dim_scaled) =
		if x_dim < max_screen_x && y_dim < max_screen_y then (x_dim,y_dim)
		else 
			(let xrat = float_of_int(max_screen_x) /. float_of_int(x_dim)   in
			 let yrat = float_of_int(max_screen_y) /. float_of_int(y_dim)  in
			 let sf =
				if xrat > yrat
				then yrat
				else  xrat
			 in
			 scalefactor := sf;
			 (int_of_float(float_of_int(x_dim) *. sf),int_of_float(float_of_int(y_dim) *. sf))) in
	let (x_dims, y_dims) = (string_of_int(x_dim_scaled),string_of_int(y_dim_scaled)) in
	let open_str = " "^x_dims^"x"^y_dims^"+450-800" in
	Graphics.open_graph open_str;
	Graphics.resize_window x_dim_scaled y_dim_scaled;
	Graphics.set_window_title "CDEG diagram";
(*	let lines = dd.diag.lines in
	let circs = dd.diag.circs in
	let array = (Array.create (!countervalue +1) 0) in
		reset_color_counter();
		rec_color_lines(lines,array);
		rec_color_circs(circs,array);*)
		draw_edges(dd,dd.diag.graph.segs);
		draw_nodes(dd,dd.diag.graph.dots);;

let output_pd(pd) =
  let dd = pd2dd(pd) in
  let newdd = update_dd(dd) in
  draw_dd(newdd);;

(****************)
(*  Front End   *)
(****************)

exception BadRequest;;

let save_path = "saved";;

type action_type = 
  SaveState of string | Load of string | SetPD of int | ViewPD 
    | AddDotToSeg of int | AddDotToReg of int | ConnectDots of int * int 
    | DrawCirc of int * int | PrintDiag | PrintSingDiag 
	| Help | ExtendSeg of int | ExtendtoRay of int * int
    | MarkRadii of int  |MarkCombine of markables
	| FreeMarkSeg of dseg * dseg | FreeMarkAng of di_angle * di_angle | FreeMarkReg of regset * regset
    | SegAdd of dseg*dseg*dseg*dseg 
    | AngAdd of di_angle * di_angle *di_angle * di_angle
	| RegAdd of regset * regset * regset * regset
    | SegSubtract of dseg*dseg*dseg*dseg 
    | AngSubtract of di_angle * di_angle *di_angle * di_angle
	| RegSubtract of regset * regset * regset * regset
    | ApplyCS of dseg*dseg | ApplyCA of di_angle * di_angle | ApplyCR of regset * regset
    | ApplyEFP of int * int * int * di_angle * int * int
	| EraseFree |SaveGML of string
	| EraseCircle of int | EraseLine of int | EraseDot of dot 
	| EraseLineEnds of int * int * int | EraseMarker of int | EraseUnusedMarkers
	| ApplySAS of trianglesides * trianglesides 
	| ApplySSS of trianglesides * trianglesides 
	| MarkOne of markables |WarrantyDisclaimer | PrintLicenseInfo
    | Quit | Error;;

let perform_act(action,diag_array,cur_pd_index) = 
  match action with
      SaveState(path) -> 
	(let outpathstring = if path = "" then save_path else path in
	 let out = open_out(outpathstring) in
	   Marshal.to_channel out 
			(diag_array,namearray,displaynamearray,reversedisplaynamearray, !countervalue, !displayname_countervalue)
	     [Marshal.Closures];
	   close_out(out);
	   (diag_array,cur_pd_index))
    | Load(path) ->
	(let outpathstring = if path = "" then save_path else path in
	 let inchannel = open_in(outpathstring) in
	 let (newdiag_array,narray, oldlookup, oldrlookup, cv, dncv) =  
	   (Marshal.from_channel inchannel 
	   : (diagramarray * (int, arrayelt) Hashtbl.t  *
	       (int, int) Hashtbl.t * (int, int) Hashtbl.t
		   * int * int) )
	 in
	   close_in(inchannel);
	   countervalue := cv;
	   displayname_countervalue := dncv;
	   copy_hashtbl(narray, namearray);
	   (* copies narray into namearray *)
	   copy_hashtbl(oldlookup, displaynamearray);
	   copy_hashtbl(oldrlookup, reversedisplaynamearray);
	   (newdiag_array,1))
    | SetPD(pd_index) ->
	let da_length = List.length(diag_array) in
	  if pd_index > da_length or pd_index < 0 
	  then raise BadRequest
	  else (diag_array,pd_index)
    | ViewPD ->
	let pd = getelt(cur_pd_index,diag_array) in
	  printmarkings(pd);
	  output_pd(pd);
	  (diag_array,cur_pd_index)
    | SaveGML(path) ->
	let outpathstring = if path = "" then gmloutputfile else path in
	let pd = getelt(cur_pd_index,diag_array) in
	  printmarkings(pd);
	  output_gml_pd(pd,outpathstring);
	  (diag_array,cur_pd_index)
    | AddDotToSeg(seg_index) ->
	(try 
	  let pd = getelt(cur_pd_index,diag_array) in
	  let seg = getseg(seg_index) in
	  let (newdot,pnewseg1,oldend1,oldend2,pnewseg2,newpd) = 
	    add_dot_to_seg(pd,seg) in
	  assign_dn(newdot.dnum);
	  assign_dn((sse2seg(pnewseg1)).snum);
	  assign_dn((sse2seg(pnewseg2)).snum);
	  let new_da = replace_nth_elt(diag_array,cur_pd_index,[newpd]) in
	    (new_da,cur_pd_index) 
	with  Undefined -> raise BadRequest)
    | AddDotToReg(reg_index) ->
	(try 
	  let pd = getelt(cur_pd_index,diag_array) in
	  let reg = getreg(reg_index) in
	  let (newdot,newpd) = add_dot_to_reg(pd,reg) in
	  assign_dn(newdot.dnum);
	  let new_da = replace_nth_elt(diag_array,cur_pd_index,[newpd]) in
	    (new_da,cur_pd_index) 
	with  Undefined -> raise BadRequest)
    | ConnectDots(dot1_index, dot2_index) ->
	(try 
	  let pd = getelt(cur_pd_index,diag_array) in
	  let dot1 = getdot(dot1_index) in
	  let dot2 = getdot(dot2_index) in
	  if isframedot(dot1) or isframedot(dot2)
	  then raise BadRequest
	  else
	  let new_pds = possible_extensions(pd,dot1,EmptyLineSeg,
					    DotGoal(dot2)) in
	  let new_da = replace_nth_elt(diag_array,cur_pd_index,new_pds) in
	    (new_da,cur_pd_index) 
	with  Undefined -> raise BadRequest)
    | ExtendSeg(index) ->
	(try 
	  let pd = getelt(cur_pd_index,diag_array) in
	  let seg = getseg(index) in
	  let line = 
	    (match (pd.member)(seg) with
		 Line(l) -> l
	       | _ -> raise BadRequest) in
	  let list = (pd.lmakeup)(line) in
	  let (dot1,seg1,dot2,seg2) = 
	    match (list, lasttwoelts(list)) with
		(Dot(d1)::Seg(s1)::_,(Seg(s2),Dot(d2))) -> (d1,s1,d2,s2)
	      | _ -> raise BadInput
	  in
	  let new_pds1 = 
(*	    if seg1 = seg 
	    then  *)
	      possible_extensions(pd,dot1,PSeg(seg1),FrameGoal)
(*	    else  possible_extensions(pd,dot2,PSeg(seg2),FrameGoal) *)
	  in
	  let f = function x -> possible_extensions(x,dot2,PSeg(seg2),
						    FrameGoal) in
	  let new_pds2 = List.flatten (List.map f new_pds1) in 
	  let new_da = replace_nth_elt(diag_array,cur_pd_index,new_pds2) in
	    (new_da,cur_pd_index) 
	with  Undefined -> raise BadRequest)
   | ExtendtoRay(segindex,dotindex) ->
	(try 
	  let pd = getelt(cur_pd_index,diag_array) in
	  let seg = getseg(segindex) in
	  let dot = getdot(dotindex) in
	  let line = 
	    (match (pd.member)(seg) with
		 Line(l) -> l
	       | _ -> raise BadRequest) in
	  let list = (pd.lmakeup)(line) in
	  let (dot1,seg1,dot2,seg2) = 
	    match (list, lasttwoelts(list)) with
		(Dot(d1)::Seg(s1)::_,(Seg(s2),Dot(d2))) -> (d1,s1,d2,s2)
	      | _ -> raise BadInput
	  in
	  let new_pds =
		if dot = dot1
		then possible_extensions(pd,dot1,PSeg(seg1),FrameGoal)
		else if dot = dot2
		then possible_extensions(pd,dot2,PSeg(seg2),FrameGoal)
		else raise BadRequest
	  in
	  let new_da = replace_nth_elt(diag_array,cur_pd_index,new_pds) in
	    (new_da,cur_pd_index) 
	with  Undefined -> raise BadRequest)
    | DrawCirc(center_index,radius_index) ->
	(try 
	  let pd = getelt(cur_pd_index,diag_array) in
	  let center_dot = getdot(center_index) in
	  let radius_dot = getdot(radius_index) in
	  let new_pds = 
	    possible_extensions(pd,radius_dot,
				EmptyCircleSeg(CDot(center_dot)),
				StartDot(radius_dot)) in
	  let new_da = replace_nth_elt(diag_array,cur_pd_index,new_pds) in
	    (new_da,cur_pd_index) 
	with  Undefined -> raise BadRequest)
    | MarkRadii(i) ->
	(try 
	   let pd = getelt(cur_pd_index,diag_array) in
	   let seg = getseg(i) in
	   let circle = 
	     (match (pd.member)(seg) with 
		  Circ(circ) -> circ
		| _ -> raise BadRequest)
	   in
	   let newpd = mark_radii(pd,circle) in
	   let new_da = replace_nth_elt(diag_array,cur_pd_index,[newpd]) in
	     (new_da,cur_pd_index) 
	 with  Undefined -> raise BadRequest)
    | MarkCombine(markable) ->
	(try 
	   let pd = getelt(cur_pd_index,diag_array) in
	   let newpd = marker_fix(pd,markable) in
	   let new_da = replace_nth_elt(diag_array,cur_pd_index,[newpd]) in
	     (new_da,cur_pd_index) 
	 with  Undefined -> raise BadRequest)
	| MarkOne(markable) ->
	(try 
	   let pd = getelt(cur_pd_index,diag_array) in
	   let newpd = add_single_marker(pd,markable) in
	   let new_da = replace_nth_elt(diag_array,cur_pd_index,[newpd]) in
	     (new_da,cur_pd_index) 
	 with  Undefined -> raise BadRequest)
	| FreeMarkSeg(dseg1,dseg2) ->
	(try 
	   let pd = getelt(cur_pd_index,diag_array) in
	   let newpd = mark_segs(pd,dseg1,dseg2) in
	   let new_da = replace_nth_elt(diag_array,cur_pd_index,[newpd]) in
	     (new_da,cur_pd_index) 
	 with  Undefined -> raise BadRequest)
	| FreeMarkAng(dang1,dang2) ->
	(try 
	   let pd = getelt(cur_pd_index,diag_array) in
	   let newpd = mark_angs(pd,dang1,dang2) in
	   let new_da = replace_nth_elt(diag_array,cur_pd_index,[newpd]) in
	     (new_da,cur_pd_index) 
	 with  Undefined -> raise BadRequest)
	| FreeMarkReg(regs1,regs2) ->
	(try 
	   let pd = getelt(cur_pd_index,diag_array) in
	   let newpd = mark_regs(pd,regs1,regs2) in
	   let new_da = replace_nth_elt(diag_array,cur_pd_index,[newpd]) in
	     (new_da,cur_pd_index) 
	 with  Undefined -> raise BadRequest)
    | SegAdd(dseg1a,dseg1b,dseg2a,dseg2b) ->
	(try 
	   let pd = getelt(cur_pd_index,diag_array) in
	   let newpd = marker_union_seg(pd,dseg1a,dseg1b,dseg2a,dseg2b) in
	   let new_da = replace_nth_elt(diag_array,cur_pd_index,[newpd]) in
	     (new_da,cur_pd_index) 
	 with  Undefined -> raise BadRequest)
    | AngAdd(dseg1a,dseg1b,dseg2a,dseg2b) ->
	(try 
	   let pd = getelt(cur_pd_index,diag_array) in
	   let newpd = marker_union_ang(pd,dseg1a,dseg1b,dseg2a,dseg2b) in
	   let new_da = replace_nth_elt(diag_array,cur_pd_index,[newpd]) in
	     (new_da,cur_pd_index) 
	 with  Undefined -> raise BadRequest)
	| RegAdd(regs1a,regs1b,regs2a,regs2b) ->
	(try 
	   let pd = getelt(cur_pd_index,diag_array) in
	   let newpd = marker_union_reg(pd,regs1a,regs1b,regs2a,regs2b) in
	   let new_da = replace_nth_elt(diag_array,cur_pd_index,[newpd]) in
	     (new_da,cur_pd_index) 
	 with  Undefined -> raise BadRequest) 
    | SegSubtract(dseg1a,dseg1b,dseg2a,dseg2b) ->
	(try 
	   let pd = getelt(cur_pd_index,diag_array) in
	   let newpd = marker_subtract_seg(pd,dseg1a,dseg1b,dseg2a,dseg2b) in
	   let new_da = replace_nth_elt(diag_array,cur_pd_index,[newpd]) in
	     (new_da,cur_pd_index) 
	 with  Undefined -> raise BadRequest)
    | AngSubtract(dseg1a,dseg1b,dseg2a,dseg2b) ->
	(try 
	   let pd = getelt(cur_pd_index,diag_array) in
	   let newpd = marker_subtract_ang(pd,dseg1a,dseg1b,dseg2a,dseg2b) in
	   let new_da = replace_nth_elt(diag_array,cur_pd_index,[newpd]) in
	     (new_da,cur_pd_index) 
	 with  Undefined -> raise BadRequest)
    | RegSubtract(regs1a,regs1b,regs2a,regs2b) ->
	(try 
	   let pd = getelt(cur_pd_index,diag_array) in
	   let newpd = marker_subtract_reg(pd,regs1a,regs1b,regs2a,regs2b) in
	   let new_da = replace_nth_elt(diag_array,cur_pd_index,[newpd]) in
	     (new_da,cur_pd_index) 
	 with  Undefined -> raise BadRequest)
    | ApplyCS(dseg1,dseg2) ->
	let pd = getelt(cur_pd_index,diag_array) in
	  if cs_applies(pd,dseg1,dseg2)
	  then 
	    (print_string("OK. \n");
	     let new_da = replace_nth_elt(diag_array,cur_pd_index,[]) in
		 let newcpi =
			if cur_pd_index = 1 then 1 else (cur_pd_index - 1) in
	       (new_da,newcpi))
	  else 
	    (print_string("Doesn't apply. \n");
	     (diag_array,cur_pd_index))
    | ApplyCA(dang1,dang2) ->
	let pd = getelt(cur_pd_index,diag_array) in
	  if ca_applies(pd,dang1,dang2)
	  then 
	    (print_string("OK. \n");
	     let new_da = replace_nth_elt(diag_array,cur_pd_index,[]) in
		 let newcpi =
			if cur_pd_index = 1 then 1 else (cur_pd_index - 1) in
	       (new_da,newcpi))
	  else 
	    (print_string("Doesn't apply. \n");
	     (diag_array,cur_pd_index))
    | ApplyCR(regs1,regs2) ->
	let pd = getelt(cur_pd_index,diag_array) in
	  if cr_applies(pd,regs1,regs2)
	  then 
	    (print_string("OK. \n");
	     let new_da = replace_nth_elt(diag_array,cur_pd_index,[]) in
		 let newcpi =
			if cur_pd_index = 1 then 1 else (cur_pd_index - 1) in
	       (new_da,newcpi))
	  else 
	    (print_string("Doesn't apply. \n");
	     (diag_array,cur_pd_index))
    | ApplyEFP(tsindex,sindex1,sindex2, dang, stadindex,stasindex) ->
	  let pd = getelt(cur_pd_index,diag_array) in
	  let transeg = getseg(rlookup_dn(tsindex)) in
	  let trans = 
		(match (pd.member)(transeg) with 
			  Line(line2) -> line2
			| _ -> raise BadRequest) in
	  let seg1 = getseg(rlookup_dn(sindex1)) in
	  let seg2 = getseg(rlookup_dn(sindex2)) in
	  let stangdot = getdot(rlookup_dn(stadindex)) in
	  let stangseg = getseg(rlookup_dn(stasindex)) in
	  if efp_applies(pd,trans,seg1,seg2,dang,stangdot,stangseg)
	  then 
	    (print_string("OK. \n");
	     let new_da = replace_nth_elt(diag_array,cur_pd_index,[]) in
		 let newcpi =
			if cur_pd_index = 1 then 1 else (cur_pd_index - 1) in
	       (new_da,newcpi))
	  else 
	    (print_string("Doesn't apply. \n");
	     (diag_array,cur_pd_index))
    | EraseFree ->
	    (print_string("OK. \n");
	     let new_da = replace_nth_elt(diag_array,cur_pd_index,[]) in

		 let newcpi =
			if cur_pd_index = 1 then 1 else (cur_pd_index - 1) in
	       (new_da,newcpi))
    | Help ->
	print_string("Options are:\n");
	print_string("<a>dd dot to segment, ");
	print_string("draw <c>ircle,\n");
	print_string("<d>elete objects, ");
	print_string("<e>rase diagram, ");
	print_string("get <h>elp, \n");
	print_string("apply <m>arker inference rules, ");
	print_string("con<n>ect dots, \n");
	print_string("extend segment in <o>ne direction, \n");
	print_string("<p>rint diagram as text, ");
	print_string("<q>uit, \n");
	print_string("add dot to <r>egion, ");
	print_string("<s>ave/load diagrams, \n");  
	print_string("se<t> pd, or ");	
	print_string("e<x>tend segment. \n");	
	(diag_array,cur_pd_index)
    | PrintDiag -> 
	printpdlist(diag_array);
	(diag_array,cur_pd_index)
	| PrintSingDiag -> 
	let pd = getelt(cur_pd_index,diag_array) in
	printpd(pd);
	(diag_array,cur_pd_index)
	| ApplySAS(trianglesides1,trianglesides2) ->
	(try 
	   let pd = getelt(cur_pd_index,diag_array) in
	   let newpd = sas_triangleupdate(pd,trianglesides1,trianglesides2) in
	   let new_da = replace_nth_elt(diag_array,cur_pd_index,[newpd]) in
	     (new_da,cur_pd_index) 
	 with  Undefined -> raise BadRequest)
	| ApplySSS(trianglesides1,trianglesides2) ->
	(try 
	   let pd = getelt(cur_pd_index,diag_array) in
	   let newpd = sss_triangleupdate(pd,trianglesides1,trianglesides2) in
	   let new_da = replace_nth_elt(diag_array,cur_pd_index,[newpd]) in
	     (new_da,cur_pd_index) 
	 with  Undefined -> raise BadRequest)
	| EraseDot(dot) ->
		(try 
	   let pd = getelt(cur_pd_index,diag_array) in
	   let newpd = erase_point(dot,pd)in
	   let new_da = replace_nth_elt(diag_array,cur_pd_index,[newpd]) in
	     (new_da,cur_pd_index) 
	 with  Undefined -> raise BadRequest)
	| EraseMarker(index) ->
		(try 
	   let pd = getelt(cur_pd_index,diag_array) in
	   let marker = getmarker(rlookup_dn(index)) in
	   let newpd = erase_marker(marker,pd)in
	   let new_da = replace_nth_elt(diag_array,cur_pd_index,[newpd]) in
	     (new_da,cur_pd_index) 
	 with  Undefined -> raise BadRequest)
	| EraseUnusedMarkers ->
		(try 
	   let pd = getelt(cur_pd_index,diag_array) in
	   let newpd = erase_unused_markers(pd) in
	   let new_da = replace_nth_elt(diag_array,cur_pd_index,[newpd]) in
	     (new_da,cur_pd_index) 
	 with  Undefined -> raise BadRequest)
	| EraseCircle(index) ->
		(try 
			let pd = getelt(cur_pd_index,diag_array) in
			let seg = getseg(rlookup_dn(index)) in
			let circle = 
				(match (pd.member)(seg) with 
					Circ(circ2) -> circ2
					| _ -> raise BadRequest) in
	   let newpd = erase_circle(circle,pd)in
	   let new_da = replace_nth_elt(diag_array,cur_pd_index,[newpd]) in
	     (new_da,cur_pd_index) 
	 with  Undefined -> raise BadRequest) 
	| EraseLineEnds(index, dotindex1, dotindex2) ->
		(try 
			let pd = getelt(cur_pd_index,diag_array) in
			let seg = getseg(rlookup_dn(index)) in
			let line = 
				(match (pd.member)(seg) with 
					Line(line2) -> line2
					| _ -> raise BadRequest) in
			let dot1 = getdot(rlookup_dn(dotindex1)) in
			let dot2 = getdot(rlookup_dn(dotindex2)) in
			let newpd = erase_line_ends(line,dot1, dot2 ,pd)in
			let new_da = replace_nth_elt(diag_array,cur_pd_index,[newpd]) in
			(new_da,cur_pd_index) 
	 with  Undefined -> raise BadRequest) 
	| EraseLine(index) ->
		(try 
			let pd = getelt(cur_pd_index,diag_array) in
			let seg = getseg(rlookup_dn(index)) in
			let line = 
				(match (pd.member)(seg) with 
					Line(line2) -> line2
					| _ -> raise BadRequest) in
	   let newpd = erase_line(line,pd)in
	   let new_da = replace_nth_elt(diag_array,cur_pd_index,[newpd]) in
	     (new_da,cur_pd_index) 
	 with  Undefined -> raise BadRequest) 
    | WarrantyDisclaimer ->
	print_string(" \n");
	print_string("THERE IS NO WARRANTY FOR CDEG, \n");
	print_string("TO THE EXTENT PERMITTED BY APPLICABLE LAW. \n");
	print_string("EXCEPT WHEN OTHERWISE STATED IN WRITING THE \n");
	print_string("COPYRIGHT HOLDERS AND/OR OTHER PARTIES PROVIDE \n");
	print_string("THE PROGRAM “AS IS” WITHOUT WARRANTY OF ANY KIND, \n");
	print_string("EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT \n");
	print_string("LIMITED TO, THE IMPLIED WARRANTIES OF \n");
	print_string("MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. \n");
	print_string("THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE \n");
	print_string("PROGRAM IS WITH YOU. SHOULD THE PROGRAM PROVE DEFECTIVE, \n");
	print_string("YOU ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR \n");
	print_string("OR CORRECTION. \n");	
	print_string(" \n");
	(diag_array,cur_pd_index)
	| PrintLicenseInfo ->
	print_string(" \n");
	print_string("CDEG is free software, and is distributed \n");
	print_string("under the terms of the Gnu General Public  \n");
	print_string("License, version 3.  This license permits you \n");
	print_string("to modify and/or redistribute CDEG under \n");
	print_string("certain conditions, but does not \n");
	print_string("allow you to restrict further redistribution. \n");
	print_string("In particular, any modified versions must also be \n");
	print_string("released under the Gnu General Public License,  \n");
	print_string("Version 3. For details, please see \n");
	print_string("the file `LICENSE_GPL_v3.txt' distributed \n");
	print_string("with the CDEG source code, or see \n");
	print_string("http://www.gnu.org/licenses/gpl-3.0.html. \n");
	print_string(" \n");
	print_string("The CDEG source code can be downloaded from \n");
	print_string("http://www.unco.edu/NHS/mathsci/facstaff/Miller/personal/CDEG/. \n");
	print_string(" \n");	
	print_string("If you do modify CDEG, I (Nathaniel Miller) \n");
	print_string("would of course be very interested in hearing \n");
	print_string("about it.  I can be contacted via email at \n");
	print_string("<nat@alumni.princeton.edu>.  \n");
	print_string(" \n");
	print_string("CDEG is linked with OGDF, the Open Graph Drawing \n");
	print_string("Framework, and includes OGDF in its source code \n");
	print_string("distribution.  OGDF is Copyright 2005--2010 by the \n");
	print_string("OGDF Team, and is also released under the Gnu General \n");
	print_string("Public License, version 3.  See http://www.ogdf.net \n");
	print_string("for further details. \n");
	print_string(" \n");	

	(diag_array,cur_pd_index)
    | _ -> raise BadInput;;



let get_di_angle(dotindex, ccw_index, cw_index, pd) =
	let pointA = getdot(dotindex) in		
    let seg1 = getseg(ccw_index) in
	let seg2 = getseg(cw_index) in
	get_angle(pd, pointA, Plain(seg1), Plain(seg2));;

let rec input_di_angle_adv() =
  print_string("\n");
  rec_input_dangle([])
and rec_input_dangle(dang) =
  print_string("Enter next pangle: enter dot, or 0 to quit:");
  let index = read_int() in
    if index = 0 
    then List.fast_sort di_angle_compare dang
    else
      (print_string("enter seg:");
       let index2 = read_int() in
       let dot = getdot(rlookup_dn(index)) in
       let seg = getseg(rlookup_dn(index2)) in
	 rec_input_dangle((dot,seg)::dang));;

let input_di_angle(pd) =
	print_string("<s>imple entry, or <a>dvanced entry?");
	let input_string2 = read_line() in
	    let input_char2 = String.get input_string2 0 in      
	       match input_char2 with
			  c when c = 's' or c ='S' ->
				print_string("Enter the angle's vertex #: "); 
				let dotindex = rlookup_dn(read_int()) in	
				print_string("Enter the seg on the counter-clockwise side of the angle: "); 
				let ccw_index = rlookup_dn(read_int()) in	
				print_string("Enter the seg on the clockwise side of the angle: "); 
				let cw_index = rlookup_dn(read_int()) in
				get_di_angle(dotindex, ccw_index, cw_index, pd)
		    | c when c = 'a' or c = 'A' -> 
				input_di_angle_adv()
			| _ -> raise BadInput;;
	




(* we sort segments so that the order they are input doesn't matter*)
let rec input_dseg() =
  rec_input_dseg([])
and rec_input_dseg(dseg) =
  print_string("Enter next seg index, or 0 to quit:");
  let index = read_int() in
    if index = 0 
    then
		(print_string("\n");
		List.fast_sort seg_compare dseg)
    else
      let seg = getseg(rlookup_dn(index)) in
	  rec_input_dseg(seg::dseg);;
	  
let rec input_regs() =
  rec_input_regs([])
and rec_input_regs(regs) =
  print_string("Enter next region index, or 0 to quit:");
  let index = read_int() in
    if index = 0 
    then
		(print_string("\n");
		List.fast_sort reg_compare regs)
    else
      let reg = getreg(rlookup_dn(index)) in
	  rec_input_regs(reg::regs);;
	
let input_triangle(pd) =
	print_string("Enter first corner: \n");
	let index1 = read_int() in
	let dot1 = getdot(rlookup_dn(index1)) in 
	print_string("Enter second corner: \n");
	let index2 = read_int() in
	let dot2 = getdot(rlookup_dn(index2)) in
	print_string("Enter third corner: \n");
	let index3 = read_int() in
	let dot3 = getdot(rlookup_dn(index3)) in 
	let dseg1 = dseg_from_endpoints(dot1,dot2,pd) in
	let dseg2 = dseg_from_endpoints(dot2,dot3,pd) in	
	let dseg3 = dseg_from_endpoints(dot3,dot1,pd) in	
	(dot1,dseg1,dot2, dseg2, dot3, dseg3);;
  

let  get_action(c_pd,pd_len, pd) =
  print_string("CDEG(");
  print_int(c_pd);
  print_string("/");
  print_int(pd_len);
  print_string(")% ");
 try 
    let input_string = read_line() in
    let input_char = String.get input_string 0 in      
      match input_char with
	  c when c = 'a' or c = 'A' -> (* <a>dd dot to segment*)
	    print_string("Enter segment number: ");
	    let index = read_int() in
	      AddDotToSeg(rlookup_dn(index))
	| c when c = 'c' or c = 'C' -> (* draw <c>ircle*)
	    print_string("Enter center dot's number: ");
	    let index1 = read_int() in
	      print_string("Enter radius dot's number: ");
	      let index2 = read_int() in
		DrawCirc(rlookup_dn(index1),rlookup_dn(index2))
	| c when c = 'd' or c = 'D' -> (* <d>elete object *)
		print_string("Type of object to erase: \n ");
	    print_string("(choices are <p>oint, <c>ircle, <l>ine, \n");
		print_string("line <e>nds, <m>arker, or all <u>nused markers.) \n");
	    let input_string2 = read_line() in
	    let input_char2 = String.get input_string2 0 in      
	      (match input_char2 with
			c when c ='p' or c = 'P' ->
				print_string("Enter dot to erase: \n");
				let dot = getdot(rlookup_dn(read_int())) in
				EraseDot(dot)
		   |c when c = 'L' or c = 'l' -> 
				print_string("Enter the number of one seg on the line: ");
				let index1= read_int()in
				EraseLine(index1)
		   |c when c = 'M' or c = 'm' -> 
				print_string("Enter the number of the marker to erase: ");
				let index1= read_int()in
				EraseMarker(index1)
		   |c when c = 'U' or c = 'u' -> 
				EraseUnusedMarkers
		   |c when c = 'E' or c = 'e' -> 
				print_string("Enter the number of one seg on the line: ");
				let index1= read_int() in
				print_string("Keep line between these dots: ");
				print_string("Enter the number of first dot on the line: ");
				let dotindex1= read_int() in
				print_string("Enter the number of second dot on the line: ");
				let dotindex2= read_int() in
				EraseLineEnds(index1,dotindex1,dotindex2)
		   |c when c = 'c' or c = 'C' ->
				print_string("Enter the number of one seg on the circle: ");
				let index1 = read_int() in
				EraseCircle(index1)
		   |_ -> Error)
	| c when c = 'e' or c = 'E' -> (* <e>rase diagram *)
	    print_string("Rule to erase pd: \n");
	    print_string("(choices are <s>eg c.,<a>ng c., <r>egion c., \n");
		print_string("<E>uclid's fifth postulate, or <f>ree) ");
	    let input_string2 = read_line() in
	    let input_char2 = String.get input_string2 0 in      
	      (match input_char2 with
		   c when c = 's' or c = 'S' -> 
			 print_string("Enter 2 dsegs that are marked equal, \n");
			 print_string("such that one is contained in the other. \n");
		     print_string("Enter first dseg: \n");
		     let dseg1 = input_dseg() in
		       print_string("Enter second dseg: \n");
		       let dseg2 = input_dseg() in
			 ApplyCS(dseg1,dseg2);
		 | c when c = 'a' or c = 'A' -> 
			 print_string("Enter 2 di-angles that are marked equal, \n");
			 print_string("such that one is contained in the other. \n");
			 		     print_string("Enter first di-angle: \n");
		     let dang1 = input_di_angle(pd) in
		       print_string("Enter second di-angle: \n");
		       let dang2 = input_di_angle(pd) in
			 ApplyCA(dang1,dang2);
		 | c when c = 'r' or c = 'R' -> 
			 print_string("Enter 2 region sets that are marked equal, \n");
			 print_string("such that one is contained in the other. \n");
		     print_string("Enter first region set: \n");
		     let regs1 = input_regs() in
		       print_string("Enter second region set: \n");
		       let regs2 = input_regs() in
			 ApplyCR(regs1,regs2);
		 | c when c = 'e' or c = 'E' -> 			 
			 print_string("Enter two lines crossed by a transversal, such that \n");
			 print_string("the interior angles on one side of the transversal \n");
			 print_string("are properly contained in an angle marked equal to  \n");
			 print_string("a straight angle, but the lines don't cross on that side. \n");			 
			 print_string("Enter the number of one seg on the transversal: ");
			 let tindex= read_int() in
			 print_string("Enter the number of the segment of the first line coming from \n");
			 print_string("the transversal on the side of the 2 interior angles: ");
			 let sindex1= read_int() in
			 print_string("Enter the number of the segment of the second line coming from \n");
			 print_string("the transversal on the side of the 2 interior angles: ");
			 let sindex2= read_int() in
			 print_string("Enter a di-angle containing the 2 interior angles that \n");
			 print_string("is marked equal to a straight angle: \n");
			 let dang= input_di_angle(pd) in
			 print_string("Enter the number of the dot that is the vertex of \n");
			 print_string("the straight angle it is marked equal to: ");
			 let stadindex= read_int() in
			 print_string("Enter the number of the segment on the counterclockwise \n");
			 print_string("side of the straight angle: ");
			 let stasindex= read_int() in			 
			 ApplyEFP(tindex,sindex1,sindex2,dang,stadindex,stasindex);
		 | c when c = 'f' or c = 'F' ->
		       EraseFree
		 | _ -> Error)
	| c when c = 'h' or c = 'H' -> (* get <h>elp*)
	    Help
	| c when c = 'l' or c = 'L' -> (* get <h>elp*)
	    PrintLicenseInfo
	| c when c = 'm' or c = 'M' -> (* apply <m>arker inference rules *)
		print_string("Marker inference rule to apply: \n");
		print_string(" (choices are: \n");	
		print_string("<a>ddition of marked objects, ");
		print_string("<c>ombine markers, \n");
		print_string("<d>ifference of marked objects, ");
		print_string("<f>ree marking, \n"); 
		print_string("mark <o>ne single object, ");
		print_string("mark <r>adii, \n");
		print_string("apply <S>AS, or ");
		print_string("appl<y> SSS) ");
	    let input_stringB = read_line() in
	    let input_charB = String.get input_stringB 0 in      
	      (match input_charB with	
				  c when c = 'a' or c = 'A' -> (* <a>dd marked objects together *)
				    print_string("Enter two objects to add, then two corresponding objects to add. \n");
					print_string("Type of marker to add: ");
					print_string("(choices are <s>eg, <a>ng, or <r>egion) ");
					let input_string2 = read_line() in
					let input_char2 = String.get input_string2 0 in      
						(match input_char2 with
							  c when c = 's' or c = 'S' -> 
								print_string("Enter dseg A1: \n");
								let dsega1 = input_dseg() in
								print_string("Enter dseg A2: \n");
								let dsega2 = input_dseg() in
								print_string("Enter dseg B1: \n");
								let dsegb1 = input_dseg() in
								print_string("Enter dseg B2: \n");
								let dsegb2 = input_dseg() in
								SegAdd(dsega1,dsega2,dsegb1,dsegb2);
							| c when c = 'a' or c = 'A' -> 
								print_string("Enter di-angle A1: \n");
								let danga1 = input_di_angle(pd) in
								print_string("Enter di-angle A2: \n");
								let danga2 = input_di_angle(pd) in
								print_string("Enter di-angle B1: \n");
								let dangb1 = input_di_angle(pd) in
								print_string("Enter di-angle B2: \n");
								let dangb2 = input_di_angle(pd) in
								AngAdd(danga1,danga2,dangb1,dangb2)
							| c when c = 'r' or c = 'R' -> 
								print_string("Enter region set A1: \n");
								let regsa1 = input_regs() in
								print_string("Enter region set A2: \n");
								let regsa2 = input_regs() in
								print_string("Enter region set B1: \n");
								let regsb1 = input_regs() in
								print_string("Enter region set B2: \n");
								let regsb2 = input_regs() in
								RegAdd(regsa1,regsa2,regsb1,regsb2)
							| _ -> Error)	
				| c when c = 'c' or c = 'C' -> (* <c>ombine markers *)
					print_string("Type of marker to combine: ");
					print_string("(choices are <s>eg, <a>ng, or <r>egion) ");
					let input_string2 = read_line() in
					let input_char2 = String.get input_string2 0 in      
					(match input_char2 with
						  c when c = 's' or c = 'S' -> 
							print_string("Enter dseg: \n");
							let dseg1 = input_dseg() in
							MarkCombine(Dseg(dseg1));
						| c when c = 'a' or c = 'A' -> 
							print_string("Enter di-angle: \n");
							let dang1 = input_di_angle(pd) in
							MarkCombine(Angle(dang1));
						| c when c = 'r' or c = 'R' -> 
							print_string("Enter region set: \n");
							let regs = input_regs() in
							MarkCombine(RegionSet(regs));							
						| _ -> Error)	
				| c when c = 'd' or c = 'D' -> (*<d>ifference of marked objects *)
				    print_string("Enter two objects to subtract, then \n"); 
					print_string("two corresponding objects to subtract. \n");
					print_string("(Enter smaller objects first in each pair.)");
					print_string("Type of marked objects to subtract: ");
					print_string("(choices are <s>eg, <a>ng, or <r>egion.) ");
					let input_string2 = read_line() in
					let input_char2 = String.get input_string2 0 in      
						(match input_char2 with
							  c when c = 's' or c = 'S' -> 
								print_string("Enter dseg A1: \n");
								let dsega1 = input_dseg() in
								print_string("Enter dseg A2: \n");
								let dsega2 = input_dseg() in
								print_string("Enter dseg B1: \n");
								let dsegb1 = input_dseg() in
								print_string("Enter dseg B2: \n");
								let dsegb2 = input_dseg() in
								SegSubtract(dsega1,dsega2,dsegb1,dsegb2);
							| c when c = 'a' or c = 'A' -> 
								print_string("Enter di-angle A1: \n");
								let danga1 = input_di_angle(pd) in
								print_string("Enter di-angle A2: \n");
								let danga2 = input_di_angle(pd) in
								print_string("Enter di-angle B1: \n");
								let dangb1 = input_di_angle(pd) in
								print_string("Enter di-angle B2: \n");
								let dangb2 = input_di_angle(pd) in
								AngSubtract(danga1,danga2,dangb1,dangb2)
							| c when c = 'r' or c = 'R' -> 
								print_string("Enter region set A1: \n");
								let regsa1 = input_regs() in
								print_string("Enter region set A2: \n");
								let regsa2 = input_regs() in
								print_string("Enter region set B1: \n");
								let regsb1 = input_regs() in
								print_string("Enter region set B2: \n");
								let regsb2 = input_regs() in
								RegSubtract(regsa1,regsa2,regsb1,regsb2)
							| _ -> Error)	
				| c when c = 'f' or c = 'F' -> (* <f>ree marking *)
					print_string("Type of objects to mark: ");
					print_string("(choices are <s>eg, <a>ng, or <r>egion.) ");
					let input_string2 = read_line() in
					let input_char2 = String.get input_string2 0 in      
						(match input_char2 with
							  c when c = 's' or c = 'S' -> 
								print_string("Enter first dseg to mark: \n");
								let dseg1 = input_dseg() in
								print_string("Enter second dseg to mark: \n");
								let dseg2 = input_dseg() in
								FreeMarkSeg(dseg1,dseg2)
							| c when c = 'a' or c = 'A' -> 
								print_string("Enter di-angle 1: \n");
								let dang1 = input_di_angle(pd) in
								print_string("Enter di-angle 2: \n");
								let dang2 = input_di_angle(pd) in
								FreeMarkAng(dang1,dang2)
							| c when c = 'r' or c = 'R' -> 
								print_string("Enter first region set to mark: \n");
								let rset1 = input_regs() in
								print_string("Enter second region set to mark: \n");
								let rset2 = input_regs() in
								FreeMarkReg(rset1,rset2)
							| _ -> Error)	
				| c when c = 'o' or c = 'O' -> (* mark <o>ne single object *)
					print_string("Type of object to mark with new marker: ");
					print_string("(choices are <s>eg, <a>ng, or <r>egion.) ");
					let input_string2 = read_line() in
					let input_char2 = String.get input_string2 0 in      
						(match input_char2 with
							  c when c = 's' or c = 'S' -> 
								print_string("Enter dseg: \n");
								let dseg1 = input_dseg() in
								MarkOne(Dseg(dseg1));
							| c when c = 'a' or c = 'A' -> 
								print_string("Enter di-angle: \n");
								let dang1 = input_di_angle(pd) in
								MarkOne(Angle(dang1));
							| c when c = 'r' or c = 'R' -> 
								print_string("Enter region set to mark: \n");
								let rset = input_regs() in
								MarkOne(RegionSet(rset)); 
							| _ -> Error)
				| c when c = 'r' or c = 'R' -> (* mark <r>adii *)
					print_string("Enter the number of one seg on the circle: ");
					let index1 = read_int() in
					MarkRadii(rlookup_dn(index1))
				| c when c = 's' or c = 'S' -> (* Apply <S>AS *)
					print_string("Input corners of first triangle in SAS order: \n");
					let trianglesides1 = input_triangle(pd) in
					print_string("Input corners of second triangle in SAS order: \n");
					let trianglesides2 = input_triangle(pd) in
					ApplySAS(trianglesides1,trianglesides2)
				| c when c = 'y' or c = 'Y' -> (* Apply <S>AS *)
					print_string("Input sides of first triangle in SSS order: \n");
					let trianglesides1 = input_triangle(pd) in
					print_string("Input sides of second triangle in SSS order: \n");
					let trianglesides2 = input_triangle(pd) in
					ApplySSS(trianglesides1,trianglesides2)
				| _ -> Error)
	| c when c = 'n' or c = 'N' -> (* con<n>ect dots *)
	    print_string("Enter first dot's number: ");
	    let index1 = read_int() in
		print_string("Enter second dot's number: ");
		let index2 = read_int() in
		ConnectDots(rlookup_dn(index1),rlookup_dn(index2))	
	| c when c = 'o' or c = 'O' -> (* extend segment in <o>ne direction *)
	    print_string("Enter segment number: ");
	    let segindex = read_int() in
		print_string("Enter number of end dot on side to extend: ");
	    let dotindex = read_int() in
	      ExtendtoRay(rlookup_dn(segindex), rlookup_dn(dotindex))	
	| c when c = 'p' or c = 'P' -> (* <p>rint diagram as text *)
		print_string("Print <a>rray, or print <s>ingle diagram? ");
		let input_string2 = read_line() in
		let input_char2 = String.get input_string2 0 in      
			(match input_char2 with
					  c when c = 's' or c = 'S' -> 
						PrintSingDiag
					| c when c= 'a' or c='A' ->
						PrintDiag
					| _ -> Error)
	| c when c = 'q' or c = 'Q' -> (* <q>uit *)
	    Quit		
	| c when c = 'r' or c = 'R' -> (* add dot to <r>egion *)
	    print_string("Enter region number: ");
	    let index = read_int() in
	      AddDotToReg(rlookup_dn(index))		
	|  c when c = 's' or c = 'S' ->  (* <s>ave/load diagrams *)
		print_string("Save/load Diagram option: \n");
		print_string(" (choices are: <s>ave diagram, save <g>ml format, \n");
		print_string("  or <l>oad diagram ) \n");
	    let input_stringB = read_line() in
	    let input_charB = String.get input_stringB 0 in      
	      (match input_charB with		
			  c when c = 's' or c = 'S' -> (* <s>ave diagram *)
				print_string("Enter file name: ");
				let fstring = read_line() in
				SaveState(fstring)
			| c when c = 'g' or c = 'G' -> (* save <g>ml format *)
				print_string("Enter file name: ");
				let fstring = read_line() in
				SaveGML(fstring)
			| c when c = 'l' or c = 'L' -> (* <l>oad diagram *)
				print_string("Enter file name: ");
				let fstring = read_line() in
				Load(fstring)
			| _ -> Error)
	| c when c = 't' or c = 'T' -> (* se<t> pd *)
	    print_string("Enter pd number: ");
	    let index = read_int() in
	      SetPD(index)	
	| c when c = 'w' or c = 'W' -> (* se<t> pd *)
	      WarrantyDisclaimer	
	| c when c = 'x' or c = 'X' -> (* e<x>tend segment *)
	    print_string("Enter segment number: ");
	    let index = read_int() in
	      ExtendSeg(rlookup_dn(index))	
	| _ ->
	    Error
  with
      _ -> Error;;



let rec main_loop(diag_array,cur_pd_index) =
  let da_l = List.length(diag_array) in
  if da_l = 0 
  then
	(print_string("No diagrams remain in array. \n");
	print_string("CDEG program ending. \n"))
  else
	let pd = getelt(cur_pd_index,diag_array) in
	printmarkings(pd);
	output_pd(pd);
  let action = get_action(cur_pd_index,da_l, pd) in
    match action with
	Error ->
	  (print_string("That isn't a valid command.");
	   print_string("   Please try again.  Press h for help. \n");
	   main_loop(diag_array, cur_pd_index))
      | Quit ->
	  (print_string("Are you sure you want to quit? ");
	   let ystring = read_line() in
	   let ychar = String.get ystring 0 in
	     if ychar = 'y' or ychar =  'Y' 
	     then print_string(" Bye! \n")
	     else main_loop(diag_array, cur_pd_index))
      | _ ->
	  (try 
	     let (new_da,new_pd_ind) = 
	       perform_act(action,diag_array,cur_pd_index) 
	     in
	      (* garbage_collect(new_da,namearray); *)
		   register_names(new_da);
		   da_assign_dns(new_da);
	       main_loop(new_da,new_pd_ind)
	   with _ -> (* make Dummy to debug *) 
	    (print_string("\nThat isn't a valid command.  ");
	      print_string("Please try again.  Press h for help. \n");
	      main_loop(diag_array,cur_pd_index))) ;;
	  (*   raise Dummy);;*)




let  main() =
  print_string("This is CDEG: Computerized Diagrammatic \n");
  print_string("Euclidean Geometry, v2.0b2.\n");  
  print_string("Copyright 2011 by Nathaniel Miller. \n");
  print_string("Contact: <nat@alumni.princeton.edu>\n");
  print_string("\n");
  print_string("CDEG is distributed under the terms of the \n");
  print_string("Gnu General Public ");
  print_string("License, Version 3, (GPLv3) \n");
  print_string("as published by ");
  print_string("the Free Software Foundation. \n");
  print_string("\n");
  print_string("This program comes with ABSOLUTELY NO WARRANTY; \n");
  print_string("type 'w' for details. \n");
  print_string("\n");
  print_string("This is free software, and you are welcome to \n");
  print_string("redistribute it ");
  print_string("under the conditions \n");
  print_string("of the GPLv3.  Type 'l' for further information. \n");
  print_string("\n");
(*  print_string("The GPLv3 can be viewed at \n");
  print_string("http://www.gnu.org/licenses/gpl-3.0.html. \n");
  print_string("\n");*)
  print_string("\n");

  print_string("Welcome to CDEG! \n");  
  print_string("(Type h for help.) \n");
  main_loop([emptypd],1);;



main();; 


	
(*****************)	
(* Testing code  *)
(*****************)	














let test() = 
	let reg = getreg(4) in
	let (newdot3,newpd2) = add_dot_to_reg(emptypd,reg) in
	let (newdot4,newpd3) = add_dot_to_reg(newpd2,reg) in
	let newpd4 =
		firstelt(possible_extensions(newpd3,newdot3,EmptyLineSeg,
					    DotGoal(newdot4))) in 
	let newpd45 =
		firstelt(possible_extensions(newpd4,newdot4,EmptyLineSeg,
					    DotGoal(newdot3))) in 
	let newpd5 =
		firstelt(possible_extensions(newpd45,newdot3,
				EmptyCircleSeg(CDot(newdot4)),
				StartDot(newdot3))) in
	    register_names([newpd5]);
	let newpd6 =
		firstelt(possible_extensions(newpd5,newdot4,
				EmptyCircleSeg(CDot(newdot3)),
				StartDot(newdot4))) in
    register_names([newpd6]);
	printpd(newpd6);
    let newdot12 = getdot(rlookup_dn(10)) in
	let newpd7 =
		firstelt(possible_extensions(newpd6,newdot3,EmptyLineSeg,
					    DotGoal(newdot12))) in	
(*	let seg = getseg(19) in
	let circle = 
				(match (newpd6.member)(seg) with 
					Circ(circ2) -> circ2
					| _ -> raise BadRequest) in
	let newpd7 = erase_circle(circle,newpd6) in *)
		(* erase_seg(getseg(19),newpd6) in *)
(*	register_names([newpd7]);
	pd_assign_dns(newpd7);
	printpdlist([newpd7]);*)
	output_pd(newpd7);	
	Graphics.read_key();;

(*	let newdot12 = getdot(rlookup_dn(12)) in
	let newpd7 =
		firstelt(possible_extensions(newpd6,newdot3,EmptyLineSeg,
					    DotGoal(newdot12))) in	
	let newpd8 =
		firstelt(possible_extensions(newpd7,newdot4,EmptyLineSeg,
					    DotGoal(newdot12))) in	
	  register_names([newpd8]);
	let seg = getseg(rlookup_dn(13)) in
	let circle = 
	     (match (newpd8.member)(seg) with 
		  Circ(circ) -> circ
		| _ -> raise BadRequest)
	in
	let seg2 = getseg(rlookup_dn(5)) in
	let seg3 = getseg(rlookup_dn(25)) in
	let seg4 = getseg(rlookup_dn(29)) in 

	let newpd9 = mark_radii(newpd8,circle,
							[getseg(rlookup_dn(5))],
							[getseg(rlookup_dn(25))]) in 
	let diang = get_di_angle(rlookup_dn(4),rlookup_dn(25),rlookup_dn(5), newpd9) in 
	
	


	let newpd10 = add_single_marker(newpd9, Angle(diang)) in
	let newpd11 = sas_triangleupdate(newpd10,([seg2],[seg3],[seg4]),([seg3],[seg2],[seg4])) in
	printmarkings(newpd11);
	output_pd(newpd11);		
	Graphics.read_key();;*)




(*	print_string("\n 4=");
	print_int(rlookup_dn(4));
	print_string("\n 12=");
	print_int(rlookup_dn(12));
	print_string("\n 13=");
	print_int(rlookup_dn(13));
	print_string("\n 5=");
	print_int(rlookup_dn(5));
	print_string("\n 25=");
	print_int(rlookup_dn(25));
	print_string("\n 29=");
	print_int(rlookup_dn(29));
	print_string("\n");*)

	
	(*let newdot12 = getdot(264) in
	let newpd7 =
		firstelt(possible_extensions(newpd6,newdot3,EmptyLineSeg,
					    DotGoal(newdot12))) in	
	let newpd8 =
		firstelt(possible_extensions(newpd7,newdot4,EmptyLineSeg,
					    DotGoal(newdot12))) in	
	  register_names([newpd8]);
	let seg = getseg(443) in
	let circle = 
	     (match (newpd8.member)(seg) with 
		  Circ(circ) -> circ
		| _ -> raise BadRequest)
	in
	let seg2 = getseg(9) in
	let seg3 = getseg(1422) in
	let seg4 = getseg(2308) in 
	let newpd9 = mark_radii(newpd8,circle,
							[getseg(9)],
							[getseg(1422)]) in 
	let diang = get_di_angle(6,1422,9, newpd9) in 
	
	
	
	
	printmarkings(newpd9);
	printpdlist([newpd9]);
	output_pd(newpd9);		
	Graphics.read_key();
	
	print_int(0);;*)

(*
let test() = 
	let reg = getreg(4) in
	let (newdot3,newpd2) = add_dot_to_reg(emptypd,reg) in
	let (newdot4,newpd3) = add_dot_to_reg(newpd2,reg) in
	let newpd4 = firstelt(possible_extensions(newpd3,newdot3,EmptyLineSeg,
							DotGoal(newdot4))) in
	let newpd7 =
		firstelt(possible_extensions(newpd4,newdot4,
					EmptyCircleSeg(CDot(newdot3)),
					StartDot(newdot4))) in
	let (newdot5,newpd5) = add_dot_to_reg(newpd7,getreg(36)) in
	let newpd6 = firstelt(possible_extensions(newpd5,newdot5,EmptyLineSeg,
							DotGoal(newdot4))) in
	let newpd8 =
		firstelt(possible_extensions(newpd6,newdot4,PSeg(getseg(9)),FrameGoal)) in
		output_pd(newpd8);
		Graphics.read_key();; 
				
*)		

 (*test();; 
	*)




