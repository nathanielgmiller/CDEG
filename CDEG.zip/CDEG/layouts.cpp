/*
 *  layouts.cpp
 *  cdeg
 *
 *  Part of CDEG: Computerized Diagrammatic Euclidean Geometry
 *  Copyright 2011 Nathaniel Miller. 
 *
 *  Contact: nat@alumni.princeton.edu
 *
 */

/*

 This file is part of CDEG.
 
 CDEG is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, version 3 of the License.
 
 CDEG is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with CDEG.  If not, see <http://www.gnu.org/licenses/>. 
 
*/

extern "C" {
#include </usr/local/lib/ocaml/caml/mlvalues.h>
#include </usr/local/lib/ocaml/caml/memory.h>
#include </usr/local/lib/ocaml/caml/alloc.h>
#include </usr/local/lib/ocaml/caml/custom.h>
}
#include <ogdf/basic/Graph.h>
#include <ogdf/basic/GraphAttributes.h>
#include <iostream> 
#include <string>
#include <ogdf/planarlayout/MixedModelLayout.h>
#include <sstream>
#include <fstream>
#include <ogdf/basic/HashArray.h>
#include <stdio.h>


using namespace std;
using namespace ogdf; 

int GetIntVals(string strConvert) {
	int intReturn;
	intReturn = atoi(strConvert.c_str());
	
	return(intReturn);
}

String toStrings(int i)
{
	char buffer [8];
	int n;
	String s;
	n=sprintf (buffer, "%d", i);
	s = String(buffer);
	return s;
}

adjEntry nodeEdgeAEs(node nds, edge edg)
{
	adjEntry ae = nds->firstAdj();
	while (ae->theEdge() != edg) {
		ae = ae->cyclicSucc();
	}
	
	return ae;
}

adjEntry blagInputs(Graph *Gp ,int extnodeid, int extedgeid, char * inputstring)
{
	string inputstringcpp (inputstring);
	istringstream blagin (inputstringcpp,istringstream::in);
	string nextword;
	int nodeid;
	int edgeid;
	node nnd;
	edge ne;
	nextword.reserve(1000);
	node dummynode = Gp->newNode(0);
	node dummynode2 = Gp->newNode(-1);
	edge dummyedge = Gp->newEdge(dummynode, dummynode2,0);
	HashArray<int, node, DefHashFunc<int> > NL(dummynode2) ;
	HashArray<int, edge, DefHashFunc<int> > EL (dummyedge);
	adjEntry pae;
	
		while (! blagin.eof() )
		{
			blagin >> nextword;
			if (nextword == "<NODE>")
			{
				blagin >> nextword;
				nodeid = GetIntVals(nextword);
				nnd = Gp->newNode(nodeid);
				NL[nodeid] = nnd;
				bool firstedge = true;
				
				blagin >> nextword;
				while (nextword != "</NODE>") {
					blagin >> nextword;
					edgeid = GetIntVals(nextword);
					if (EL.isDefined(edgeid))
					{
						ne = EL[edgeid];
						if (firstedge)
						{
							Gp->moveTarget(ne,nnd);
							firstedge = false;
							pae = nodeEdgeAEs(nnd, ne);
						}
						else {
							Gp->moveTarget(ne, pae, after);
							pae = pae->succ();
						}
						
					}
					else {
						ne = Gp->newEdge(nnd, dummynode, edgeid);
						EL[edgeid] = ne;
						if (firstedge)
						{
							pae = nodeEdgeAEs(nnd, ne);
							firstedge = false;
						}
						else {
							Gp->moveSource(ne,pae,after);
							pae = pae->succ();
						}
					}
					blagin >> nextword;
					blagin >> nextword;
					// G.writeGML(std::cout);
					
				}
				
			}
		}
		Gp->delEdge(dummyedge);
		Gp->delNode(dummynode);
		Gp->delNode(dummynode2);
		
		//Gp->writeGML(std::cout);
		pae = nodeEdgeAEs(NL[extnodeid], EL[extedgeid]);
		return pae;
}

const char * clayouts(int nodeid, int segid, char * inputstring )
{
	Graph G;
	GraphAttributes GA(G, GraphAttributes::nodeGraphics |	
					   GraphAttributes::edgeGraphics |
					   GraphAttributes::nodeLabel|
					   GraphAttributes::edgeArrow |
					   GraphAttributes::edgeColor |
					   GraphAttributes::edgeType |
					   GraphAttributes::edgeLabel |
					   GraphAttributes::edgeStyle);
	
	
	adjEntry n2ae = blagInputs(&G, nodeid, segid, inputstring);
	//G.writeGML(std::cout);
	
	node v;
	forall_nodes(v,G)
	{
		GA.width(v) = GA.height(v) = 20.0;
		int ids = v->index();
		String st = toStrings(ids);
		GA.labelNode(v) = st;		
	}
	
	GraphAttributes::EdgeArrow ea;
	ea = GraphAttributes::none;
	
	edge e;
	forall_edges(e,G)
	{
		GA.arrowEdge(e) = GraphAttributes::none;
		GA.type(e) = Graph::association;
		int ids = e->index();
		String st = toStrings(ids);
		GA.labelEdge(e) = st;
	}
	
	/*GA.styleEdge(edget1i) = GraphAttributes::esDot;
	 GA.colorEdge(edget1i) = String("#0000FF");
	 */
	
	MixedModelLayout mml;
	mml.callFixEmbed(GA, n2ae);
	
	ostringstream oss (ostringstream::out);
	GA.writeGML(oss);
	//	GA.writeGML(std::cout); 
	
	return (oss.str()).c_str();
}





extern "C" value layouts_stub(value input1, value input2, value input3)
{
	CAMLparam3(input1, input2, input3);
	char const * s = clayouts(Int_val(input1),Int_val(input2), String_val(input3));
	CAMLreturn (caml_copy_string(s));
}
/*
 int main()
 {
 clayout(27, 29);
 return 0;
 }*/

